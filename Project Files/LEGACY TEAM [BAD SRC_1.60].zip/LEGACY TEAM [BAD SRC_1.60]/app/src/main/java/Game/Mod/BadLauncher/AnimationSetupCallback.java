package Game.Mod.BadLauncher;

import Game.Mod.LauncherActivity;

public interface AnimationSetupCallback {
    public void onSetupAnimation(TitanicTextView titanicTextView);
    public void onSetupAnimation(TitanicButton Button);
}

