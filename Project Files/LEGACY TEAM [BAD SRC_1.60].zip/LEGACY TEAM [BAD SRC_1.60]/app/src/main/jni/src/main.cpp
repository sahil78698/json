#include <pthread.h>
#include <jni.h>
#include <stdio.h>
#include <wchar.h>
#include <src/Substrate/SubstrateHook.h>
#include "src/Unity/Quaternion.hpp"
#include "src/Unity/Vector3.hpp"
#include "src/Unity/Vector3.hpp"
#include "src/Unity/Unity.h"
#include "src/Unity/Hook.h"
#include "src/Unity/Global.h"
#include "src/CANVAS/Bools.h"
#include "src/CANVAS/ESP.h"
#include "KittyMemory/MemoryPatch.h"
#include "Includes/Logger.h"
#include "Boolean.h"
#include "Icon.h"
#include "EspFire.h"

# define getRealOffset(offset) AgetAbsoluteAddress("libil2cpp.so",offset)

# define HOOK(offset, ptr, orig) MSHookFunction((void *)getRealOffset(offset), (void *)ptr, (void **)&orig)

using namespace std;

ESP espOverlay;
Vector3 InimigoLocation = Vector3(0, 0, 0);



extern "C" {
JNIEXPORT jboolean JNICALL
Java_Game_Mod_LauncherActivity_EnableSounds(
        JNIEnv *env,
        jobject activityObject) {
    return true;
}

JNIEXPORT jstring JNICALL
Java_Game_Mod_LauncherActivity_Title(
        JNIEnv *env,
        jobject activityObject) {
        	
    jstring str = env->NewStringUTF("");
    return str;
}

JNIEXPORT jstring JNICALL
Java_Game_Mod_LauncherActivity_Heading(
        JNIEnv *env,
        jobject activityObject) {
        	
    return env->NewStringUTF("");
}


JNIEXPORT jstring JNICALL
Java_Game_Mod_LauncherActivity_Icon(
        JNIEnv *env,
        jobject activityObject) {
    return env->NewStringUTF(
""   );         }

JNIEXPORT jint JNICALL
Java_Game_Mod_LauncherActivity_IconSize(
        JNIEnv *env,
        jobject activityObject) {
    return 80;
}

JNIEXPORT jstring JNICALL
Java_Game_Mod_LauncherActivity_Icon2(JNIEnv *env,jobject activityObject) {
    return env->NewStringUTF("");
    }
    
JNIEXPORT jint JNICALL
Java_Game_Mod_LauncherActivity_IconSize2(
        JNIEnv *env,
        jobject activityObject) {
    return 80;
}

JNIEXPORT jstring JNICALL
Java_Game_Mod_LauncherActivity_Toast(
        JNIEnv *env,
        jclass clazz) {
    return env->NewStringUTF("");
}

JNIEXPORT jobjectArray JNICALL
Java_Game_Mod_LauncherActivity_getFeatureList(JNIEnv *env, jobject activityObject) {
    jobjectArray ret;

    const char *features[] = {
		  
		    		    /*===============================*/
			
	        "Category_ MENU AIMBOT ",//0
		    "TG_ AIMBOT", // 1
            "TG_ AIMBOT LEGIT", // 2
            "TG_ AIMBOT VISIBLE", // 3
            "TG_ AIMBOT GRANADE", // 4
			"SeekBar_Chernobyl Spot_0_3", // 5
            "SeekBar_Chernobyl Speed_0_360", // 6
			"Category_ MENU ESP's ", //7
            "TG_Esp Fire",//8
            "TG_ESP ALERTA",//9
	        "TG_ESP GRANADA",//10
			"SeekBar_Granada_0_6",//11
  			"Category_ MENU TELEKILL ",//12
			"TG_TELEKILL",//13
			"TG_DRIVE SKILL",//14
			"TG_GHOST HACK",//15
			"Category_ MENU OTHERS  ",//16
		    "TG_ZE PEDRINHA",//17
			"TG_UNDER CARRO",//18
			"SeekBar_Velocidade_0_9",//19
            "TG_WALLHACK",//20
            "TG_Super Damage ",//21
            "SeekBar_Fly Altura_0_2",//22
            "SeekBar_Fly Position_0_5",//23
            "SeekBar_Fly Speed_0_20",//24
            "TG_HIGH JUMP",
          //  "ButtonHide_ICONE INVISIVEL",//
			
			
			
  
			
			
    };

    int Total_Feature = (sizeof features /
                         sizeof features[0]); //Now you dont have to manually update the number everytime;

    ret = (jobjectArray) env->NewObjectArray(Total_Feature, env->FindClass("java/lang/String"),
                                             env->NewStringUTF(""));
    int i;
    for (i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));
    return (ret);
}

struct My_Patches {
/*====================================================================*/
     
        MemoryPatch Conta;
	MemoryPatch ModoFantasma;
    MemoryPatch WallStoneX;
	MemoryPatch WallStoneA;
	MemoryPatch WallStoneW;
	MemoryPatch SpeedTime;
	MemoryPatch SpeedTime2x;
    MemoryPatch SpeedTime3x;
	MemoryPatch SpeedTime4x;
	MemoryPatch SpeedTime5x;
	MemoryPatch SpeedTime6x;
	MemoryPatch SpeedTime7x;
	MemoryPatch SpeedTime8x;
	MemoryPatch WallCar;
	MemoryPatch WallCar2;
	MemoryPatch Damage;
	MemoryPatch MoveBoard;
    MemoryPatch MoveBoard1;
	MemoryPatch UndergroundCarro;
    MemoryPatch WallHack;
	MemoryPatch TeleCarro;
	MemoryPatch DesactiveFunctions;
	MemoryPatch FlyMovePS;
	MemoryPatch UnlockerBoard;
    MemoryPatch CarFly80;
MemoryPatch CarFly90;
MemoryPatch CarFly100;
MemoryPatch Speed;
MemoryPatch Speed2;
MemoryPatch TakeDamege;
  MemoryPatch TakeSkill;
/*====================================================================*/
     } KW;
	
bool KMHack1 = false,
KMHack2 = false,
KMHack3 = false,
KMHack4 = false,
KMHack5 = false,
KMHack6 = false,
KMHack7 = false,
KMHack8 = false,
KMHack9 = false,
KMHack10 = false,
KMHack11 = false,
KMHack12 = false,
KMHack13 = false,
KMHack14 = false,
KMHack15 = false,
KMHack16 = false;

/*====================================================================*/
     

struct {
	bool teleKill = false;
	bool Speed = false;
	bool Speed2 = false;
	bool SpeedTime = true;
	bool SpeedTime2x = false;
	bool SpeedTime3x = false;
	bool SpeedTime4x = false;
	bool SpeedTime5x = false;
	bool SpeedTime6x = false;
	bool SpeedTime7x = false;
	bool WallCar = false;
	bool WallCar2 = false;
	bool SpeedTime8x = false;
	bool SpeedTime9x = false;
	bool MoveBoard = false;
	bool TpCarro1 = false;
	bool TeleCarro = false;
	bool CarFly80 = false;
    bool CarFly90 = false;
	bool CarFly100 = false;

	bool UndergroundCarro = false;
	bool ModoFantasma = false;
	bool WallStoneX = false;
	bool WallStoneA = false;
	bool TeleportPlayer = false;
	bool WallStoneW = false;
    bool aimAuto = false;
    bool aimScope = false;
    bool aimFire = false;
    bool aimSquat = false;
    bool aimLegit = false;
	bool aimCaido = false;
    bool FOV = true;
	bool Desactive = false;
    bool aimbotauto = true;
    bool TpCarro = false;
    bool AlertAround = false; 
	bool espIndetificar = false;
    bool espFPS = false;
    bool configLine = false;
    bool espDistance = false;
    bool espNames = false;
    bool espBox = false;
    bool espSkeleton = false;
    bool espFire = false;
	bool espGranada = false;
    bool aimVisible = false;
	bool espName = false;
	
	bool aimCabeca = true;
	bool aimPeito = false;
	bool aimPe = false;
	bool EspHp = false;
	bool espNewConfig = false;
	bool espNew1 = false;
	bool espNew2 = false;
	bool espNew3 = false;
	bool EspVida = false;
	bool espNew4 = false;
    bool Conta = false;
	bool espLineEncima = false;
	bool espLineEmbaixo = false;
    bool espLineMeio = false;
	bool DesactiveFunctions = false;
	bool espFireCeu = false;
	bool espFireConfig = false;
	
	bool espAlert = false;
	bool ghost = false;
	bool trandom = false;
	bool random = false;
	bool espGranade = false;
    bool FlyCar30X = false;
	bool FlyCar50X = false;
	bool FlyCar100X = false;
	
    bool espCout = false;
	bool AlvoEnemyPos = false;

	
int udercar = 0;
	int semihs = 0;
    int FramePerS;
    int enemyCountAround = 0;
    int botCountAround = 0;
    Color GrandaColor = Color::White();
    
	
	Color Changecolor = Color::White();
    Color LineColor = Color::White();
    Color TextColor = Color::White();
    bool EspAlvoUnico = false;
	Color Espcoloralvo = Color::DarkGolden();
	bool SpeedTimeAkahari = false;
	bool MoveBoardAkahari = false;
	float Fov_Aim = 0.0f;
    float TextSize = 17.0f;
    float Linesize = 1.5f;
	
/*====================================================================*/
     

} HP;

std::string indetifiq;
bool isTakeDemageBool = false;
bool verify = false;
bool active = true;
bool launched = false;
bool MoveBoardAkahari = false;
MemoryPatch Jump;
MemoryPatch NoElimine;
bool Jumplayer = false;
struct {
bool AimKillWeapons = false;
bool aimkill = false;
} Levi;
bool ActiveFeature = false;
JNIEXPORT void JNICALL
Java_Game_Mod_LauncherActivity_Changes(JNIEnv *env, jobject activityObject, jint feature, jint value) {
    
    switch (feature) {
		
			
case 0:
        break;
		
		
        
        case 1:
            HP.aimAuto = !HP.aimAuto;
        break;
            
        case 2:
            HP.aimFire = !HP.aimFire;
        break;
            
        case 3:
            HP.aimScope = !HP.aimScope;
        break;
            
        case 4:
            HP.aimSquat = !HP.aimSquat;
        break;

        
			
		case 5:
            if (value == 0) {
            //Dezativado
			} else
			if (value == 1) {
                HP.aimCabeca = !HP.aimCabeca;
                HP.aimCabeca = true;
                HP.aimPeito = false;
                HP.aimPe = false;
            } else if (value == 2) {
                HP.aimPeito = !HP.aimPeito;
                HP.aimPeito = true;
                HP.aimCabeca = false;
                HP.aimPe = false;
            } else if (value == 3) {
                HP.aimPe = !HP.aimPe;
                HP.aimPe = true;
                HP.aimPeito = false;
                HP.aimCabeca = false;
            }
			break;
        
        case 6:
			HP.Fov_Aim = (float)value;
			if(value == 0) {
				HP.Fov_Aim = 0.0099f;
			}
        break;
		
		/*===============================*/
			
			case 7:
            break;
	
        	case 8:
            HP.espFire = !HP.espFire;
            HP.espNames = !HP.espNames;
          //  HP.espFireCeu = HP.espFireCeu;
            break;
            
            case 9:
            HP.AlertAround = !HP.AlertAround;
            break;
			
			case 10:
			HP.espGranade = !HP.espGranade;
			break;
			
	
			case 11:
			if (value == 0) {
				HP.GrandaColor = Color::White();
				
			} else if (value == 1) {
				HP.GrandaColor = Color::Green();
				
			} else if (value == 2) {
				HP.GrandaColor = Color::Blue();
				
			} else if (value == 3) {
				HP.GrandaColor = Color::Red();
				
			} else if (value == 4) {
				HP.GrandaColor = Color::Yellow();
				
			} else if (value == 5) {
				HP.GrandaColor = Color::Cyan();
				
			} else if (value == 6) {
				HP.GrandaColor = Color::Magenta();
	          }
            break;
			
            
			
			
			
			/*===============================*/

			case 12:
				//extras
			break;
			
			case 13:
			HP.TeleportPlayer = !HP.TeleportPlayer;
			break;
			
			case 14:
			HP.TpCarro = !HP.TpCarro;
           
            break;
			
		 	case 15:
            HP.ghost = !HP.ghost;
	    	break;
			case 16:
			//MAPA
			break;
			
			case 17:
			KMHack1 = !KMHack1;
            if (KMHack1) {
            KW.WallStoneX.Modify();
			KW.WallStoneA.Modify();
			KW.WallStoneW.Modify();
            } else {
            KW.WallStoneX.Restore();
			KW.WallStoneA.Restore();
			KW.WallStoneW.Restore();
			}
            break;
		    

			case 18:
			KMHack7 = !KMHack7;
            if (KMHack7) {
            KW.UndergroundCarro.Modify();
            } else {
            KW.UndergroundCarro.Restore();
			}
            break;
			
			
			case 19:     
              if (value == 0) {
                KW.SpeedTime.Restore();
            } else if (value == 1) {
                KW.SpeedTime2x.Modify();
            } else if (value == 2) {
                KW.SpeedTime3x.Modify();
            } else if (value == 3) {
                KW.SpeedTime4x.Modify();
			 } else if (value == 4) {
                KW.SpeedTime5x.Modify();
            } else if (value == 5) {
                KW.SpeedTime6x.Modify();
            } else if (value == 6) {
                KW.SpeedTime7x.Modify();
			} else if (value == 7) {
                KW.SpeedTime8x.Modify();
            } else if (value == 8) {
	        }
			break;
			
			
			case 20:
                KMHack8 = !KMHack8;
            if (KMHack8) {
            KW.WallHack.Modify();
            } else {
            KW.WallHack.Restore();
            }
            break;
            
            
            case 21:
                isTakeDemageBool = !isTakeDemageBool;
                break;
                
            case 22:
            if (value > 0) { 
            FlyAltura = true; 
            ALFA.velocidade =  (int) value; 
            MoveBoardAkahari = true;
            } else { 
            FlyAltura = false; 
            ALFA.velocidade = 10; 
            MoveBoardAkahari = true;
            }
            break;
            
           case 23:
             Conect.posi = (int) value;
					break;
            
            case 24:
                Conect.FlySpeed = value;
				break;
			case 25:
         Jumplayer = !Jumplayer;
         if (Jumplayer) {
        
        Jump.Modify();
        NoElimine.Modify();
        } else {
        
        Jump.Restore();
        NoElimine.Restore();
        }
  break;    
  
          
        case 26:
            ActiveFeature = !ActiveFeature;
            isPlayerLine = !isPlayerLine;
            break;
			
			
    }
}
}
float EspAtas = 0;
float EspBawah = 0;
float EspKanan = 0;
float EspKiri = 0;

Vector3 GetHeadPosition(void* player) {
    return Transform_INTERNAL_GetPosition(*(void**) ((uint64_t) player + Global.HeadTF));
}

Vector3 GetHipPosition(void* player) {
    return Transform_INTERNAL_GetPosition(*(void**) ((uint64_t) player + Global.HipTF));
}

Vector3 GetToePosition(void* player) {
    return Transform_INTERNAL_GetPosition(*(void**) ((uint64_t) player + Global.ToeTF));
}

Vector3 CameraMain(void* player){
    return Transform_INTERNAL_GetPosition(*(void**) ((uint64_t) player + Global.MainCameraTransform));
}


static int GetWeaponType(void* player) {
    int (*_GetWeaponType)(void* p) = (int (*)(void* ))getRealOffset(Global.GetWeaponType);
    return _GetWeaponType(player);
}
static void *GetVehicleIAmIn(void *Vehicle) {
    void *(*_GetVehicleIAmIn)(void *Vehicles) = (void *(*)(void *))getRealOffset(0xABF5B4);
    return _GetVehicleIAmIn(Vehicle);
}
char get_Chars(monoString *str, int index){
    char (*_get_Chars)(monoString *str, int index) = (char (*)(monoString *, int))getRealOffset(0x33C3F10);
    return _get_Chars(str, index);
}

void *GetClosestEnemy(void *match) {
    if(!match) {
        return NULL;
    }
	
    float shortestDistance = 99999;
    float maxAngle = HP.Fov_Aim;
	
    void* closestEnemy = NULL;
    void* LocalPlayer = GetLocalPlayer(match);
	
    if(LocalPlayer != NULL && !get_IsDieing(LocalPlayer)) {
       
		monoDictionary<uint8_t *, void **> *players = *(monoDictionary<uint8_t*, void **> **)((long)match + Global.Dictionary);
		for(int u = 0; u < players->getNumValues(); u++) {
            void* Player = players->getValues()[u];
           
			if(Player != NULL && !get_isLocalTeam(Player) && !get_IsDieing(Player) && get_isVisible(Player) && get_MaxHP(Player)) {
			  
                Vector3 PlayerPos = GetHipPosition(Player);
                Vector3 LocalPlayerPos = GetHeadPosition(LocalPlayer);
				
                if(HP.FOV) {
                    Vector3 targetDir = Vector3::Normalized(PlayerPos - LocalPlayerPos);
                    float angle = Vector3::Angle(targetDir, GetForward(Component_GetTransform(Camera_main()))) * 100.0;
                   
					if(angle <= maxAngle) {
                        if(angle < shortestDistance) {
                            shortestDistance = angle;
                            closestEnemy = Player;
                        }
                    }
                } else {
                    if(maxAngle < shortestDistance) {
                        shortestDistance = maxAngle;
                        closestEnemy = Player;
                    }
                }
            }
        }
    }
	return closestEnemy;
}


void (*Update)(void* gamestartup);


void _Update(void* gamestartup) {
    if(Update) {
		if (HP.DesactiveFunctions) {}
        void* Match = Curent_Match();
        if((HP.aimAuto || HP.aimScope || HP.aimSquat || HP.aimFire) && Match) {
            void* LocalPlayer = GetLocalPlayer(Match);
            
            if(LocalPlayer) {
				void* closestEnemy = GetClosestEnemy(Match);
				
				if(closestEnemy) {
                    
                    Vector3 EnemyHeadLocation = GetHeadPosition(closestEnemy);
					Vector3 EnemyLocation = GetHeadPosition(closestEnemy);
					Vector3 PlayerLocation = CameraMain(LocalPlayer);
					Vector3 CenterWS = GetAttackableCenterWS(LocalPlayer);
					
					Quaternion PlayerLook = GetRotationToLocation(GetHeadPosition(closestEnemy), 0.1f, PlayerLocation);
					Quaternion PlayerLook2 = GetRotationToLocation(GetHipPosition(closestEnemy), 0.1f, PlayerLocation);
					Quaternion PlayerLook3 = GetRotationToLocation(GetToePosition(closestEnemy), 0.1f, PlayerLocation);
					
					float distance = Vector3::Distance(CenterWS, EnemyLocation);
					
					Vector3 LocalPlayerPos = GetHeadPosition(LocalPlayer);
					Vector3 PlayerPos = GetHeadPosition(closestEnemy);
					
					bool scope = get_IsSighting(LocalPlayer);
					bool agachado = get_IsCrouching(LocalPlayer);
					bool firing = get_IsFiring(LocalPlayer);
					bool caido = get_IsDieing(closestEnemy);

					
                    
					if (HP.TpCarro) {
	                void* LocalCar = VehicleIAmIn(LocalPlayer);
                    if (LocalCar) {
                   Transform_INTERNAL_SetPosition(Component_GetTransform(LocalCar), Vvector3(EnemyLocation.X, EnemyLocation.Y + 0.26f, EnemyLocation.Z));
                    }
                    }
					
					if (HP.espNames) {
						void *ui = CurrentUIScene();
						if (ui != NULL) {
							monoString *nick = get_NickName(closestEnemy);
							monoString *distances = U3DStrFormat(distance);
							ShowAssistantText(ui, nick, distances);
						}
					}
                    
                    
					  if (HP.espFire) {
                                    void *imo = get_imo(LocalPlayer);
                                    if (imo != NULL) {
                                        set_esp(imo, CenterWS, EnemyLocation);
                                    }
                                }
                                
                    if(HP.espFireCeu) {
                                    void* CenterWS = get_imo(LocalPlayer);
                                    Vector3 From = Transform_INTERNAL_GetPosition(Component_GetTransform(Camera_main())) + Vector3(2,4,2);
                                    Vector3 To = GetHeadPosition(closestEnemy);
                                    set_esp(CenterWS,From,To);
                                }
                            
                        
                    
					
						
if(HP.espGranade) {
GrenadeLine_DrawLine(Grenade2, LocalPlayerPos, LocalPlayerPos, Vector3(0,1,0) * 0.1);
((void (*)(void *, Color))getRealOffset(0x3589E08))(Render2,HP.GrandaColor);
((void (*)(void *, Color))getRealOffset(0x3589EAC))(Render2, HP.GrandaColor);
      
if (Render2) {
LineRenderer_Set_PositionCount(Render2, 0x2); 
LineRenderer_SetPosition(Render2, 0, LocalPlayerPos);
LineRenderer_SetPosition(Render2, 1, PlayerPos);
}
}
   

   
                   if(HP.TeleportPlayer) {
                       set_aim(LocalPlayer, PlayerLook);
            void *_MountTF = Component_GetTransform(closestEnemy);
            if (_MountTF != NULL) {
                Vector3 MountTF =
                        Transform_INTERNAL_GetPosition(_MountTF) - (GetForward(_MountTF) *  0.6f);
                        Transform_INTERNAL_SetPosition(Component_GetTransform(LocalPlayer), Vvector3(MountTF.X, MountTF.Y, MountTF.Z));
            }
        }
			
if(Levi.AimKillWeapons){
    Levi.aimkill = true;
    KW.TakeDamege.Modify();
    KW.TakeSkill.Modify();
        } else {
    Levi.aimkill = false;
    KW.TakeDamege.Restore();
    KW.TakeSkill.Restore();
}
		            			
					if (HP.aimAuto) {
						if(HP.aimCabeca) {
							set_aim(LocalPlayer, PlayerLook);
						}
							
						if(HP.aimPeito) {
							set_aim(LocalPlayer, PlayerLook2);
						}
							
						if(HP.aimPe) {
							set_aim(LocalPlayer, PlayerLook3);
						}
					}
               
					if (scope && HP.aimScope) {
						if(HP.aimCabeca) {
							set_aim(LocalPlayer, PlayerLook);
						}
							
						if(HP.aimPeito) {
							set_aim(LocalPlayer, PlayerLook2);
						}
							
						if(HP.aimPe) {
							set_aim(LocalPlayer, PlayerLook3);
						}
					}
					
					if (agachado && HP.aimSquat) {
						if(HP.aimCabeca) {
							set_aim(LocalPlayer, PlayerLook);
						}
							
						if(HP.aimPeito) {
							set_aim(LocalPlayer, PlayerLook2);
						}
							
						if(HP.aimPe) {
							set_aim(LocalPlayer, PlayerLook3);
						}
					}
						
					if (firing && HP.aimFire) {
						if(HP.aimCabeca) {
							set_aim(LocalPlayer, PlayerLook);
						}
							
						if(HP.aimPeito) {
							set_aim(LocalPlayer, PlayerLook2);
						}
							
						if(HP.aimPe) {
							set_aim(LocalPlayer, PlayerLook3);
						}
					}
					
					if (firing && HP.aimLegit) {
						if (HP.aimbotauto)
						{
							set_aim(LocalPlayer, PlayerLook2);
							++HP.semihs;
						} else {
							set_aim(LocalPlayer, PlayerLook);
							--HP.semihs;
						}
               
						if (HP.semihs == 6)
						{
							HP.aimbotauto = false;
						} else if (HP.semihs == 0) {
							HP.aimbotauto = true;
						}
               
						if (HP.semihs > 6 || HP.semihs < 0)
						{
							HP.semihs = 3;
							HP.aimbotauto = true;
						}
					}
                }
            }
        }
    }
	Update(gamestartup);
}


        
void (*UpdateFly)(void* updatedoflyfds); 
void _UpdateFly(void* updatedoflyfds) { 
    if(UpdateFly) { 
        void *Match = Curent_Match(); 
 
        if((FlyAltura) && Match) {  
         void* LocalPlayer = GetLocalPlayer(Match); 
            if(FlyAltura && LocalPlayer){ 
                ALFA.Gravidade = true; 
                ALFA.conttelekill = 0; 
                 
                void *_MountTF = Component_GetTransform(LocalPlayer); 
                if (_MountTF != NULL) { 
                    Vector3 MountTF = 
                            Transform_INTERNAL_GetPosition(_MountTF); 
 
                    if(ALFA.velocidade == 1 || (ALFA.TFPosX == 0.0f || ALFA.TFPosY == 0.0f || ALFA.TFPosZ == 0.0f || ALFA.TFPos == nullptr)){ 
 
                        if(ALFA.TFPosX == 0.0f || ALFA.TFPosZ == 0.0f || ALFA.TFPos == nullptr){ 
 
                            ALFA.TFPosX = MountTF.X; 
                            ALFA.TFPosZ = MountTF.Z; 
                            ALFA.TFPos = LocalPlayer; 
 
                        } 
                        ALFA.TFPosY = MountTF.Y; 
 
                    } 
 
                    if(ALFA.velocidade > 0 && ALFA.velocidade < 2){ 
 
                        ALFA.verificacao = true; 
                        Transform_INTERNAL_SetPosition(Component_GetTransform(LocalPlayer), Vvector3(MountTF.X, MountTF.Y + 000.1f, MountTF.Z));
                    }else if(get_IsFiring(LocalPlayer)){
                        Set_Position(Component_GetTransform(LocalPlayer), Vvector3(MountTF.X, ALFA.TFPosY, MountTF.Z));
                  } else if(get_IsSighting(LocalPlayer)){
                        Set_Position(Component_GetTransform(LocalPlayer), Vvector3(MountTF.X, ALFA.TFPosY, MountTF.Z));
                   } else if(Conect.posi == 1) {
                        Conect.verificacao = true;
                        Set_Position(Component_GetTransform(LocalPlayer), Vvector3(MountTF.X + Conect.FlySpeed, MountTF.Y, MountTF.Z));
                            } else if(Conect.posi == 2) {
                        Conect.verificacao = true;
                        Set_Position(Component_GetTransform(LocalPlayer), Vvector3(MountTF.X - Conect.FlySpeed, MountTF.Y, MountTF.Z));
                        } else if(Conect.posi == 3) {
                        Conect.verificacao = true;
                        Set_Position(Component_GetTransform(LocalPlayer), Vvector3(MountTF.X,+MountTF.Y, MountTF.Z + Conect.FlySpeed));
                        } else if(Conect.posi == 4) {
                        Conect.verificacao = true;
                        Set_Position(Component_GetTransform(LocalPlayer), Vvector3(MountTF.X, MountTF.Y, MountTF.Z - Conect.FlySpeed));
                    }else if(Conect.velocidade == 5){
                        Conect.verificacao = false;
                        Set_Position(Component_GetTransform(LocalPlayer), Vvector3(MountTF.X, Conect.TFPosY, MountTF.Z));
                    }
                }
                        
            }else{ 
 
                ALFA.verificacao = false; 
 
                ++ALFA.conttelekill; 
                if(ALFA.conttelekill > 3000){ 
                    ALFA.Gravidade = false; 
                } 
                ALFA.TFPosX = 0.0f; 
                ALFA.TFPosY = 0.0f; 
                ALFA.TFPosZ = 0.0f; 
                ALFA.TFPos = nullptr; 
 
} 
}

if(ALFA.MoveBoard){
KW.MoveBoard.Modify();
} else {
KW.MoveBoard.Restore();
}

if(ALFA.UnlockerBoard){
KW.UnlockerBoard.Modify();
} else {
KW.UnlockerBoard.Restore();
}

 if (MoveBoardAkahari) {
KW.MoveBoard1.Modify();
} else {
KW.MoveBoard1.Restore();  
}
} 
UpdateFly(updatedoflyfds); 
}




void (*LateUpdate)(void *componentPlayer);

void *playerlate = NULL;
void *get_Player(void *player){
    playerlate = player;
    return playerlate;
}

void *fakeEnemy;
void _LateUpdate(void *player){
    if (player != NULL) {
		if (HP.DesactiveFunctions) {}
        void *local_player = Current_Local_Player();
       
        if (local_player == NULL){
            local_player = GetLocalPlayerOrObServer();
        }
      
        if (local_player != NULL){
            void *current_match = Curent_Match();
         
            if (current_match != NULL) {
                
                if (HP.AlertAround) {
                    ShowDynamicPopupMessage(FormatCount(HP.enemyCountAround, HP.botCountAround));
                }
                
                int tmpEnemyCountAround = 0;
                int tmpBotCountAround = 0;
            
                monoDictionary<uint8_t *, void **> *players = *(monoDictionary<uint8_t *, void **> **) ((long) current_match + 0x48);
                for (int u = 0; u < players->getNumValues(); u++) {
                    void *closestEnemy = players->getValues()[u];
                    
                    HP.enemyCountAround = tmpEnemyCountAround;
                    HP.botCountAround = tmpBotCountAround;
                    
                    if(closestEnemy != NULL && closestEnemy != player && !get_isLocalTeam(closestEnemy) && get_isVisible(closestEnemy) && get_MaxHP(closestEnemy)) {
                    
                        if (closestEnemy != NULL) {
                            bool isBot = *(bool*)((uintptr_t)closestEnemy + Global.IsClientBot);
                            if (isBot) {
                                ++tmpBotCountAround;
                            } else {
                                ++tmpEnemyCountAround;
                            }
                        }
                        
                        if(closestEnemy != local_player) {
                            Vector3 EnemyLocation = GetHeadPosition(closestEnemy);
                            Vector3 CenterWS = GetAttackableCenterWS(local_player);
                       
                            
                                
        /*                        if (HP.espFire) {
                                    void *imo = get_imo(local_player);
                                    if (imo != NULL) {
                                        set_esp(imo, CenterWS, EnemyLocation);
                                    }
                                }
            
                                if(HP.espFireCeu) {
                                    void* CenterWS = get_imo(local_player);
                                    Vector3 From = Transform_INTERNAL_GetPosition(Component_GetTransform(Camera_main())) + Vector3(2,4,2);
                                    Vector3 To = GetHeadPosition(closestEnemy);
                                    set_esp(CenterWS,From,To);
                                }
                            }
                        }
                    }
                }*/
            
					
                void *fakeCamPlayer = get_MyFollowCamera(local_player);
                void *fakeCamEnemy = get_MyFollowCamera(player);
             
                if (fakeCamPlayer != NULL && fakeCamEnemy != NULL){
                    void *fakeCamPlayerTF = Component_GetTransform(fakeCamPlayer);
                    void *fakeCamEnemyTF = Component_GetTransform(player);
                
                    if (fakeCamPlayerTF != NULL && fakeCamEnemyTF != NULL) {
                        Vector3 fakeCamPlayerPos = Transform_INTERNAL_GetPosition(fakeCamPlayerTF);
                        Vector3 fakeCamEnemyPos = Transform_INTERNAL_GetPosition(fakeCamEnemyTF);
                        float distance = Vector3::Distance(fakeCamPlayerPos, fakeCamEnemyPos);
                     
                        if (player != local_player) {
                          
                            if (distance < 1.6f) {
                                fakeEnemy = player;
                            }
                        }

                    }
                }
	        }
        }
    }
	}
	}
	}
    get_Player(player);
    LateUpdate(player);
}

void *get_DarkSideC = nullptr;
void *get_DarkSideE(void *DarkSideX69) {
      get_DarkSideC = DarkSideX69;
      return get_DarkSideC;
}
static bool isEspReady() {
	return false;
}

void DrawESP(ESP esp, int screenWidth, int screenHeight) {
    if(ActiveFeature) {
    float maxTexto = Tamano;
            void *player = playerlate;
     
        if (player != NULL) {
        void *current_match = Curent_Match();    
        if (current_match != NULL) {
            void *local_player = Current_Local_Player();          
            if (local_player == NULL) {
                local_player = GetLocalPlayerOrObServer();
            }     
            if (local_player != NULL) {
                void *fakeCamPlayer = get_MyFollowCamera(local_player);
                void *fakeCamEnemy = get_MyFollowCamera(player);
                if (fakeCamPlayer != NULL && fakeCamEnemy != NULL) {         
                    if (!isEspReady()) {    
                        monoDictionary<uint8_t *, void **> *players = *(monoDictionary<uint8_t*, void **> **)((long)current_match + Global.Dictionary);
                        void *camera = Camera_main();
                        if (players != NULL && camera != NULL && players->getNumValues() >= 1) {         
                            for(int u = 0; u < players->getNumValues(); u++) {
                                void* closestEnemy = players->getValues()[u];                   
                                if (closestEnemy != NULL && closestEnemy != fakeEnemy) {        
                                    bool alive = get_isAlive(closestEnemy);                               
                                    bool visible = get_isVisible(closestEnemy);                           
                                    bool sameteam = get_isLocalTeam(closestEnemy);                                 
                                    if (closestEnemy != local_player && alive && visible && !sameteam) {                              
                                        Vector3 PositionHead = WorldToScreenPoint(camera, GetHeadPosition(closestEnemy));
                                        Vector3 GetHead = Vector3((screenWidth - (screenWidth - PositionHead.X - EspKanan + EspKiri)), screenHeight - PositionHead.Y - EspAtas + EspBawah);
                                        if (PositionHead.Z < -0) continue;
                                        
                                        Vector3 PositionToe = WorldToScreenPoint(camera, GetToePosition(closestEnemy));
                                        Vector3 GetToe = Vector3((screenWidth - (screenWidth - PositionToe.X - EspKanan + EspKiri)), screenHeight - PositionToe.Y - EspAtas + EspBawah);
                                        if (PositionToe.Z < -0) continue;       
                
                                        Vector3 PositionHip = WorldToScreenPoint(camera, GetHipPosition(closestEnemy));                                
                                        Vector3 GetHip = Vector3((screenWidth - (screenWidth - PositionHip.X - EspKanan + EspKiri)), screenHeight - PositionHip.Y - EspAtas + EspBawah);
                                        if (PositionHip.Z < -0) continue;

                            float boxHeight = (PositionHead.Y - PositionToe.Y);                                            
                            float boxWidth = boxHeight * 0.65;  
                
                            Rect PlayerRect(screenWidth - (screenWidth - (PositionHead.X - (boxWidth / 2) - EspKiri + EspKanan)), (screenHeight - PositionHead.Y - EspAtas + EspBawah), boxWidth, boxHeight);
                                    
                            Vector3 EnemyLocation = GetHeadPosition(closestEnemy);
                            Vector3 CenterWS = GetAttackableCenterWS(local_player); 
                            float distance = Vector3::Distance(CenterWS, EnemyLocation);
                            bool caido = get_IsDieing(closestEnemy);
                    
                                          if(isPlayerLine) {
                                              if(caido && EspCaidos) {
                                                esp.DrawLine(Color(CaidoColor), 1.5, Vector3((screenWidth / 2), 0), Vector3((screenWidth - (screenWidth - PositionHead.X)), (screenHeight - PositionHead.Y)));
                                              } else {
                                                  esp.DrawLine(EspColor, 1.5, Vector3((screenWidth / 2), 0), Vector3((screenWidth - (screenWidth - PositionHead.X)), (screenHeight - PositionHead.Y)));
                                              }
                                          }
                                          
                                          if(isPlayerBox) {
                                              if(caido && EspCaidos) {
                                                esp.DrawBox(Color(CaidoColor), 1.5, PlayerRect);
                                              } else {
                                                esp.DrawBox(EspColor, 1.5, PlayerRect);
                                              }
                                          }
                    
                    bool ind = *(bool*)((uintptr_t)closestEnemy + Global.IsClientBot);
                                            if (ind) {
                                                indetifiq = "[BOT]";
                                            } else {
                                                indetifiq = "[PLAYER]";
                                            }
                                           monoString* nick = get_NickName(closestEnemy);
                                            
                                            std::string names;
                                            
                                             if(nick != NULL) {
                                                    int nick_Len = nick ->getLength();
                                                      for(int i = 0; i < nick_Len; i++) {
                                                       char data = get_Chars(nick, i);
                                                        names += isascii(data) ? data : '?';
                                                }
                                            }
                                            
                                            std::string dnames;
                                            dnames ="["+ names+"]";
                                            
                                            if(isPlayerIdent && isPlayerName){
                                                if(ind){
                                                    dnames ="[BOT : "+ names+"]";
                                                }else{
                                                    dnames ="[PLAYER : "+ names+"]";
                                                }
                                            }
                                            
                                        if(isPlayerName) {
                                          if(caido && EspCaidos) {
                                            esp.DrawText(Color(CaidoColor), 0.6f,
                                                dnames.c_str(),
                                                Vector3(PlayerRect.x + (PlayerRect.width / 2), PlayerRect.y - 12.0f),
                                                maxTexto);
                                            }else{
                                            esp.DrawText(Color(EspColor), 0.6f,
                                                dnames.c_str(),
                                                Vector3(PlayerRect.x + (PlayerRect.width / 2), PlayerRect.y - 12.0f),
                                                maxTexto);
                                            }
                                        }
                                        
                                        if(isPlayerIdent) {
                                                if(caido && EspCaidos) {
                                                    if(isPlayerName){
                                                        esp.DrawText(Color(CaidoColor), 0.6f,
                                                        dnames.c_str(),
                                                        Vector3(PlayerRect.x + (PlayerRect.width / 2), PlayerRect.y - 12.0f),
                                                        maxTexto);
                                                    }else{
                                                        esp.DrawText(Color(CaidoColor), 0.6f,
                                                        indetifiq.c_str(),
                                                        Vector3(PlayerRect.x + (PlayerRect.width / 2), PlayerRect.y - 12.0f),
                                                        maxTexto);
                                                    }
                                                    
                                                } else {
                                                    if(isPlayerName){
                                                        esp.DrawText(Color(EspColor), 0.6f,
                                                        dnames.c_str(),
                                                        Vector3(PlayerRect.x + (PlayerRect.width / 2), PlayerRect.y - 12.0f),
                                                        maxTexto);
                                                    }else{
                                                       esp.DrawText(Color(EspColor), 0.6f,
                                                        indetifiq.c_str(),
                                                        Vector3(PlayerRect.x + (PlayerRect.width / 2), PlayerRect.y - 12.0f),
                                                        maxTexto);
                                                    }
                                                }
                                            }
                                            
                                            char dstc[50];   
                                            sprintf(dstc, "[%.2fm]", distance);
                                            std::string dist; 
                                            dist = dstc;
                                            
                                    
                                            if(isPlayerDist) {
                                              if(caido && EspCaidos) {
                                                esp.DrawText(Color(CaidoColor), 0.6, dist.c_str(),
                                                    Vector3(PlayerRect.x + (PlayerRect.width / 2),
                                                    PlayerRect.y + PlayerRect.height + 12.5f), maxTexto);
                                                }else{
                                                esp.DrawText(Color(EspColor), 0.6, dist.c_str(),
                                                    Vector3(PlayerRect.x + (PlayerRect.width / 2),
                                                    PlayerRect.y + PlayerRect.height + 12.5f), maxTexto);
                                                }
                                            }
                                                
                         
           }
          }
         }
        }
       }
      }
      }
      }
      }
      }
	 }

bool (*orig_ghost)(void* _this);
bool _ghost(void* _this){
    if (_this != NULL){
          if (HP.ghost || HP.teleKill){
            return false;
        }
    }
  return orig_ghost(_this);
}

bool (*TrocarArma)(void* _this); 
bool _TrocarArma(void* _this) { 
    if(FlyAltura){ 
        return true; 
    } 
    return TrocarArma(_this); 
} 
 
float (*GravidadeOn)(void* player); 
float _GravidadeOn(void* player) { 
    if (FlyAltura) { 
        return -599999.0f -599999.0f -599999.0f; 
    } 
    return GravidadeOn(player); 
}

bool (*IsIgnoreHighFalling)(void* player);
bool _IsIgnoreHighFalling(void* player) {
    if (ALFA.Gravidade || ALFA.MoveOnAir) {
        return true;
    }
    return IsIgnoreHighFalling(player);
}

int (*GetPhysXState)(void* player);
int _GetPhysXState(void* player) {
    if (ALFA.verificacao) {
        return 0;
    }
    return GetPhysXState(player);
}

bool (*FlyMove)(void* _this); 
bool _FlyMove(void* _this) { 
    if(ALFA.MoveOnAir){ 
        return true; 
    } 
    return TrocarArma(_this); 
} 
 
bool(*Prancha)(void* _this);
bool _Prancha(void* _this){
      if(ALFA.MoveOnAir){
      return true ;
      }
      return Prancha(_this);
   }
bool (*IsOnBoard)(void* _this); 
bool _IsOnBoard(void* _this) { 
if (IsOnBoard) { 
return true; 
} 
return IsOnBoard(_this); 
} 
float (*FlySpeed)(int* _this);
float _FlySpeed(int* _this) {
    if (FlySpeed != NULL) {
        if (Conect.FlySpeed == 1) {
            return 000.2f;
        } else if (Conect.FlySpeed == 2) {
            return 000.3f;
        } else if (Conect.FlySpeed == 3) {
            return 000.4f;
        } else if (Conect.FlySpeed == 4) {
            return 000.5f;
        } else if (Conect.FlySpeed == 5) {
            return 000.6f;
        } else if (Conect.FlySpeed == 6) {
            return 000.7f;
        } else if (Conect.FlySpeed == 7) {
            return 000.8f;
        } else if (Conect.FlySpeed == 8) {
            return 1.08f;
        } else if (Conect.FlySpeed == 9) {
            return 1.09f;
        } else if (Conect.FlySpeed == 10) {
            return 1.10f;
        } else if (Conect.FlySpeed == 11) {
            return 1.11f;
        } else if (Conect.FlySpeed == 12) {
            return 1.12f;
        } else if (Conect.FlySpeed == 13) {
            return 1.13f;
        } else if (Conect.FlySpeed == 14) {
            return 1.14f;
        } else if (Conect.FlySpeed == 15) {
            return 1.15f;
        } else if (Conect.FlySpeed == 16) {
            return 1.16f;
        } else if (Conect.FlySpeed == 17) {
            return 1.17f;
        } else if (Conect.FlySpeed == 18) {
            return 1.18f;
        } else if (Conect.FlySpeed == 19) {
            return 1.19f;
        } else if (Conect.FlySpeed == 20) {
            return 1.20f;
        
        }
    }
    return FlySpeed(_this);
}
bool (*Ammo)(void* _this);
bool _Ammo(void* _this) {
    if (_this != NULL) {
        if (Levi.aimkill) {
            return true;
        }
    }
    return Ammo(_this);
}



float (*Recoil)(void* _this);
float _Recoil(void* _this) {
    if (_this != NULL) {
     if (Levi.aimkill) {
           return -15.0f;
    }
    return Recoil(_this);
}
}
    


void (*AimKill)(void *_this, int32_t pFireStatus, int32_t pFireMode);
void _AimKill(void *_this, int32_t pFireStatus, int32_t pFireMode) {
    if (_this != NULL) {
        if (Levi.aimkill) {
            pFireStatus = FireStatus::FIRING;
            pFireMode = FireMode::AUTO;
        }
    }
    return AimKill(_this, pFireStatus, pFireMode);
}

bool (*Anim)(void* _this);
bool _Anim(void* _this) {
    if (_this != NULL) {

            return true;
        }
    
    return Anim(_this);
}
bool (*Camera)(void* _this, Quaternion Rotate);
bool _Camera(void* _this, Quaternion Rotate) {
    if (_this != NULL) {
        if (Levi.aimkill) {
            return false;
        }
    }
    return Camera(_this, Rotate);
}
int (*IsAmmoFree)(void* player);
int _IsAmmoFree(void* player) {
    if (Levi.aimkill) {
        return true;
    }
    return IsAmmoFree(player);
}

int (*Dano)(void* player);
int _Dano(void* player) {
    if (Levi.aimkill) {
        return false;
    }
    return Dano(player);
}

float (*GetSkillDamageScale)(void *kill);
float _GetSkillDamageScale(void *kill){
    if (isTakeDemageBool) {
        return 19.0f; // <== Value
    }
    return GetSkillDamageScale(kill);
}

float (*get_HeadShotDamageDecreaseScale)(void *damage);
float _get_HeadShotDamageDecreaseScale(void *damage){
    if (isTakeDemageBool) {
        return -9999999999999999; // <== Value
    }
    return get_HeadShotDamageDecreaseScale(damage);
}
void (*TakeDamage)(void* _this, int32_t LocalTiro);
void _TakeDamage(void* _this, int32_t LocalTiro) {
    if (_this != NULL) {
       if (isTakeDemageBool) {
          return 99999999999999999;
       }
    }
    return TakeDamage(_this, LocalTiro);
}
bool(*Catapult)(void* _this);
bool _Catapult(void* _this){
  if(Conect.FlyLan){
      return true;
      }
      return Catapult(_this);
	  }
void *hack_thread(void *) {
    ProcMap il2cppMap;
    do {
        il2cppMap = KittyMemory::getLibraryMap("libil2cpp.so");
        sleep(1);
    } while (!il2cppMap.isValid());
    

	HOOK(0x182D0C0, _ghost, orig_ghost);
    
 /*====================================================================*/
          //BYPASS

HOOK(0x36BEB24, _Serverbypass, Serverbypass); //ok
HOOK(0x27F2698, _Serverbypass, Serverbypass); //ok
HOOK(0x23F9850, _Serverbypass, Serverbypass); //ok
HOOK(0x23F9850, _Serverbypass, Serverbypass); //ok
HOOK(0xEE629C, _Serverbypass, Serverbypass); //ok
HOOK(0x1DF0920, _Serverbypass, Serverbypass); //ok
HOOK(0x1DFC2A0, _Serverbypass, Serverbypass); //ok
HOOK(0x1E00160, _Serverbypass, Serverbypass); //ok
HOOK(0x1E0025C, _Serverbypass, Serverbypass); //ok
HOOK(0x1E00888, _Serverbypass, Serverbypass); //ok
HOOK(0x1E0062C, _Serverbypass, Serverbypass); //ok
HOOK(0x1E00974, _Serverbypass, Serverbypass); //ok
HOOK(0x1E00BE4, _Serverbypass, Serverbypass); //ok
HOOK(0x1DF81A4, _Serverbypass, Serverbypass); //ok
HOOK(0x1DF9D6C, _Serverbypass, Serverbypass); //ok
HOOK(0x1DFA1A8, _Serverbypass, Serverbypass); //ok
HOOK(0xEDD078, _Serverbypass, Serverbypass); //ok
HOOK(0x1DFA588, _Serverbypass, Serverbypass); //ok
HOOK(0x1DFB04C, _Serverbypass, Serverbypass); //ok
HOOK(0x1DFBA90, _Serverbypass, Serverbypass); //ok
HOOK(0x1DFF288, _Serverbypass, Serverbypass); //ok
HOOK(0x1DFF430, _Serverbypass, Serverbypass); //ok
HOOK(0x3142F64, _Serverbypass, Serverbypass); //ok
HOOK(0x1DFF804, _Serverbypass, Serverbypass); //ok
HOOK(0x1DFF950, _Serverbypass, Serverbypass); //ok
HOOK(0x1DFFB68, _Serverbypass, Serverbypass); //ok
HOOK(0x1DFFC54, _Serverbypass, Serverbypass); //ok
HOOK(0x1DFFDA0, _Serverbypass, Serverbypass); //ok
HOOK(0x1DFFEE0, _Serverbypass, Serverbypass); //ok
HOOK(0x1E00020, _Serverbypass, Serverbypass); //ok
HOOK(0x1E01268, _Serverbypass, Serverbypass); //ok
HOOK(0x1E0147C, _Serverbypass, Serverbypass); //ok
HOOK(0x1E01B2C, _Serverbypass, Serverbypass); //ok
HOOK(0x1E01D98, _Serverbypass, Serverbypass); //ok
HOOK(0x1E01F04, _Serverbypass, Serverbypass); //ok
HOOK(0x1DFBCC0, _Serverbypass, Serverbypass); //ok
HOOK(0x1DFBFAC, _Serverbypass, Serverbypass); //ok
HOOK(0x1DFC3D0, _Serverbypass, Serverbypass); //ok
HOOK(0x1DFC564, _Serverbypass, Serverbypass); //ok
HOOK(0x1DFC7F8, _Serverbypass, Serverbypass); //ok
HOOK(0x1DFC90C, _Serverbypass, Serverbypass); //ok
HOOK(0x1DFCA9C, _Serverbypass, Serverbypass); //ok
HOOK(0x1DFCE90, _Serverbypass, Serverbypass); //ok
HOOK(0x1DFD2D4, _Serverbypass, Serverbypass); //ok

//Take Damage
   // HOOK(0xb914b8, TakeDamage, Take_Damage);

//NEW OFFSETS
HOOK(0xb7b48c, _UpdateFly, UpdateFly);
HOOK(0x210e0d0,_GravidadeOn, GravidadeOn);
HOOK(0xb584e8, _TrocarArma, TrocarArma);
HOOK(0xb584e8, _Prancha, Prancha);
HOOK(0xbce758, _Prancha, Prancha);
HOOK(0xb5edf0, _GetPhysXState, GetPhysXState); //
KW.FlyMovePS = MemoryPatch::createWithHex("libil2cpp.so", 0x13dccc0, "FF 00 A0 E3 1E FF 2F E1"); //1.68
KW.MoveBoard1 = MemoryPatch::createWithHex("libil2cpp.so", 0xB428AC, "01 00 00 1A 00 00 A0 E3 4A 30 F6 EB 04 00 A0 E1 00 10 A0 E3 93 CB 2B EB 28 D0 4B E2 02 8B BD EC 04 D0 8D E2 F0 8F BD E8 D9 CB 3E 04 BC 5B 2E 04 B1 CB 3E 04 C8 42 2E 04 9C 42 2E 04 90 45 2E 04 28 FA 2D 04 D0 F8 2D 04 70 F8 2D 04 10 F8 2D 04 D8 3E 2E 04 3C F6 2D 04 E4 3D 2E 04 54 F5 2D 04 E4 F4 2D 04 8C 3C 2E 04 FC F3 2D 04 8C F3 2D 04 34 3B 2E 04 A0 F2 2D 04 30 F2 2D 04 B8 F1 2D 04 01 00 A0 E3 1E FF 2F E1 00 40 A0 E1 58 04 02 E3 00 10 A0 E3 5E ED 73 EB 01 00 50 E3 00 00 A0 13 30 88 BD 18 58 04 02 E3 00 10 A0 E3 27 ED 73 EB"); //1.68
KW.MoveBoard = MemoryPatch::createWithHex("libil2cpp.so", 0xbce758, "01 00 00 1A 00 00 A0 E3 4A 30 F6 EB 04 00 A0 E1 00 10 A0 E3 93 CB 2B EB 28 D0 4B E2 02 8B BD EC 04 D0 8D E2 F0 8F BD E8 D9 CB 3E 04 BC 5B 2E 04 B1 CB 3E 04 C8 42 2E 04 9C 42 2E 04 90 45 2E 04 28 FA 2D 04 D0 F8 2D 04 70 F8 2D 04 10 F8 2D 04 D8 3E 2E 04 3C F6 2D 04 E4 3D 2E 04 54 F5 2D 04 E4 F4 2D 04 8C 3C 2E 04 FC F3 2D 04 8C F3 2D 04 34 3B 2E 04 A0 F2 2D 04 30 F2 2D 04 B8 F1 2D 04 01 00 A0 E3 1E FF 2F E1 00 40 A0 E1 58 04 02 E3 00 10 A0 E3 5E ED 73 EB 01 00 50 E3 00 00 A0 13 30 88 BD 18 58 04 02 E3 00 10 A0 E3 27 ED 73 EB"); //1.68
KW.UnlockerBoard = MemoryPatch::createWithHex("libil2cpp.so", 0x13dbb8c, "00 00 B4 43 F0 23 74 C9 F0 23 74 C9 00 C0 79 44"); //1.68
 //END

 HOOK(0xca95dc, _TakeDamage, TakeDamage);
HOOK(0x2122380, _GetSkillDamageScale, GetSkillDamageScale);
HOOK(0x21217e0, _get_HeadShotDamageDecreaseScale, get_HeadShotDamageDecreaseScale);
 
 //Aimkill
 /*
HOOK(0x35a0d4c, _Camera, Camera);
HOOK(0xdb1388, _Skill, Skill); //
HOOK(0x2116888, _Anim, Anim);
HOOK(0x177c3e4, _Anim, Anim);
HOOK(0xbcd964, _Run, Run);
HOOK(0x21207e0, _Ammo, Ammo);
HOOK(0x13cf37c, _Ammo, Ammo);
HOOK(0x2120a8c, _Fire3, Fire3);

*/
 /*
    HOOK(0x177c3e4, _Anim, Anim); //PlayFireAnim //1.64
    HOOK(0x2120a8c, _Fire3, Fire3); //GetScatterRate //1.64
    HOOK(0xdb1388, _Skill, Skill); //public void [N}qLT(cq{GR.quyAmHy TQqdf, cq{GR.z^{]TSJ qAyffSb = 0) { } 1.64
    HOOK(0x1b57764, _HitPart, HitPart); //LOCAL DO DANO //1.64
    HOOK(0x1b578bc, _ViewPart, ViewPart); //LOCAL DO DANO //1.64
    HOOK(0xbcd964, _Run, Run); //public virtual bool RequestStopFastRun() { } 1.64
*/
 
KW.TakeDamege = MemoryPatch::createWithHex("libil2cpp.so", 0xCCBE04, "05 01 A0 E3 1E FF 2F E1");
KW.TakeSkill = MemoryPatch("libil2cpp.so", 0x1635934, "\x00\x00\xA0\xE3\x1E\xFF\x2F\xE1", 8);//1.54
 
 
 
       //ANTI CRASH

HOOK(0x6CF58C, _AntiCrash, AntiCrash); //ATUALIZADO BY PLAY MODDER
HOOK(0x6CF788, _AntiCrash, AntiCrash); //ATUALIZADO BY PLAY MODDER
HOOK(0x8FCBA0, _AntiCrash, AntiCrash); //ATUALIZADO BY PLAY MODDDER
HOOK(0x8FCBA8, _AntiCrash, AntiCrash); //ATUALIZADO BY PLAY MODDER
HOOK(0x8FCBB0, _AntiCrash, AntiCrash); //ATUALIZADO BY PLAU MODDER
/*====================================================================*/

HOOK(0x27F2698, _RankWork, RankWork); // public static bool IsPackageInstalled(string bundleIdentifier) { }
HOOK(0x27F547C, _RankWork, RankWork); // public static bool CheckFileExists(string fileName)
HOOK(0x27F547C, _RankWork, RankWork); // public static bool CheckFileExists(string fileName)
HOOK(0x29B1FDC, _AntiBan, AntiBan); //public void set_emulator_score(uint value) { }
HOOK(0x455B6A0, _AntiBan, AntiBan);//public void set_hacker_cdt_id(uint value) { }
HOOK(0x1DF1AF4, _AntiBan, AntiBan);//public static void LogSplashBannerGoto(uint id, string goto_url, uint goto_pos) { }
HOOK(0x455B698, _AntiBan, AntiBan); //public uint get_hacker_cdt_id() { }


HOOK(0x22F6074, _GrenadeUpdate, GrenadeUpdate);
HOOK(0x22F64A0, _GrenadeUpdate, GrenadeUpdate);

/*====================================================================*/

   HOOK(0xBA93FC, _Dano, Dano);
HOOK(0x21207E0, _IsAmmoFree, IsAmmoFree);//1.54
HOOK(0x2120A8C, _Recoil, Recoil);

HOOK(0x35a0d4c, _Camera, Camera);
HOOK(0xdb1388, _AimKill, AimKill); //
HOOK(0x2116888, _Anim, Anim);
HOOK(0x177c3e4, _Anim, Anim);
HOOK(0x13cf37c, _Ammo, Ammo);
    
    HOOK(0xB8AFA8, _Update, Update);//(1.69)
	HOOK(0xB868F4,_LateUpdate,LateUpdate); //(1.69.)
	
KW.WallStoneX = MemoryPatch::createWithHex("libunity.so", 0xae46e8, "00 00 00 00");//(1.69)
KW.WallStoneA = MemoryPatch::createWithHex("libunity.so", 0xae46e8, "00 00 00 00");//(1.69)
KW.WallStoneW = MemoryPatch::createWithHex("libunity.so", 0xae46e8, "00 00 00 00");//(1.69)
KW.WallCar = MemoryPatch("libil2cpp.so", 0x270BE34, "\x00\x00\xA0\xE3\x1E\xFF\x2F\xE1", 8);//1.69 Teste
KW.WallCar2 = MemoryPatch("libil2cpp.so", 0x270AA10, "\x00\x00\xA0\xE3\x1E\xFF\x2F\xE1", 8);//1.69 Teste
/*====================================================================*/
KW.WallHack = MemoryPatch("libunity.so", 0xAEDCA4, "\x1E\xFF\x2F\xE1\x7F\x45\x4C\x46", 8);//Update by hofra ff 1.69

/*====================================================================*/

KW.ModoFantasma = MemoryPatch("libil2cpp.so", 0x182CEC4, "\x00\x00\xA0\xE3\x1E\xFF\x2F\xE1", 8);//(1.69)
//KW.Conta = MemoryPatch("libil2cpp.so", 24125332, "\x01\x00\xA0\xE3\x1E\xFF\x2F\xE1", 8);

/*==============================1.69======================================*/

KW.SpeedTime = MemoryPatch("libunity.so", 0x34A11C, "\x5D\xE6\x2F\x3E", 4);//
KW.SpeedTime2x = MemoryPatch("libunity.so", 0x34A11C, "\x5D\xE6\x2F\x3E", 4);//
KW.SpeedTime3x = MemoryPatch("libunity.so", 0x34A11C, "\x5D\xE6\x2F\x3E", 4);//
KW.SpeedTime4x = MemoryPatch("libunity.so", 0x34A11C, "\x5D\xE6\x2F\x3E", 4);//
KW.SpeedTime5x = MemoryPatch("libunity.so", 0x34A11C, "\x5D\xE6\x2F\x3E", 4);//
KW.SpeedTime6x = MemoryPatch("libunity.so", 0x34A11C, "\x5D\xE6\x2F\x3E", 4);//
KW.SpeedTime7x = MemoryPatch("libunity.so", 0x34A11C, "\x5D\xE6\x2F\x3E", 4);//
KW.SpeedTime8x = MemoryPatch("libunity.so", 0x34A11C, "\x5D\xE6\x2F\x3E", 4);//
KW.UndergroundCarro = MemoryPatch("libil2cpp.so", 0x2C199C4, "\x00\x00\x00\xC0", 4);//1.68

Jump = MemoryPatch::createWithHex("libil2cpp.so", 0x27E4404, "30 00 44 E3");// BY HOFRA FF 
NoElimine = MemoryPatch::createWithHex("libil2cpp.so", 0x270BE34, "00 00 A0 E3 1E FF 2F E1"); //1.69 TEST

 
KW.Speed = MemoryPatch("libil2cpp.so", 0x211E3C0, "\x83\x0F\x43\xE3\x1E\xFF\x2F\xE1", 8);//1.69.5
KW.Speed2 = MemoryPatch("libil2cpp.so", 0x270AA10, "\x83\x0F\x43\xE3\x1E\xFF\x2F\xE1", 8);//1.69.5
			 
	return NULL;
}

extern "C" 
JNIEXPORT void JNICALL
Java_Game_Mod_LauncherActivity_DrawOn(JNIEnv *env, jclass type, jobject espView, jobject canvas) {
    espOverlay = ESP(env, espView, canvas);
    
    if (espOverlay.isValid()){
        DrawESP(espOverlay, espOverlay.getWidth(), espOverlay.getHeight());
    }
}


JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *globalEnv;
    vm->GetEnv((void **) &globalEnv, JNI_VERSION_1_6);
    
    
    pthread_t ptid;
    pthread_create(&ptid, NULL, hack_thread, NULL);

    
    return JNI_VERSION_1_6;
}




