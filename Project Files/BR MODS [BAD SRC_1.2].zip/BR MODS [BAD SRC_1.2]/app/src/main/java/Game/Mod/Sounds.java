/*
 * Credit:
 *
 * Google - Android UI sounds
 * Material.io - https://material.io/design/sound/sound-resources.html#
 *
 * */

package  Game.Mod;

public class Sounds {

    //Use https://www.base64encode.org/ to encode your files to base64

    //Note to myself xd: Click View -> Active Editor -> Soft warp

    //system/media/audio/ui/NFCFailure.ogg
    public static String Back() {
        return "";
    }

    //system/media/audio/ui/NFCInitiated.ogg
    public static String OpenMenu() {
        return "";
    }

    //system/media/audio/ui/NFCTransferComplete.ogg
    public static String Select() {
        return "";
    }

    //Material sounds - state-change_confirm-up.ogg
    public static String On() {
        return "";
    }

    //Material sounds - state-change_confirm-down.ogg
    public static String Off() {
        return "";
    }

    //Material sounds - navigation_forward-selection-minimal.ogg
    public static String SliderIncrease() {
        return "";
    }

    //Material sounds - navigation_forward-selection-minimal.ogg
    public static String SliderDecrease() {
        return "";
    }
}
