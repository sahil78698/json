package Game.Mod;

import android.content.Context; 
import android.content.res.Resources; 
import android.graphics.Bitmap; 
import android.graphics.BitmapFactory; 
import android.graphics.Color; 
import android.graphics.drawable.BitmapDrawable; 
import android.graphics.drawable.Drawable; 
import android.graphics.drawable.GradientDrawable; 
import android.graphics.drawable.StateListDrawable; 
import android.util.Base64; 
import android.util.DisplayMetrics; 
import android.util.TypedValue; 

public class BadModder {
    
	public static GradientDrawable botoes(Context context) {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setShape(0);
        gradientDrawable.setStroke(5, Color.parseColor("#a020f0"));
        gradientDrawable.setCornerRadius(TypedValue.applyDimension(1, 0.0f, context.getResources().getDisplayMetrics()));
        return gradientDrawable;
    }

    public static GradientDrawable botoes_ativados(Context context) {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setShape(0);
        gradientDrawable.setStroke(5, Color.parseColor("#a020f0"));
        gradientDrawable.setColor(Color.parseColor("#a020f0"));
        gradientDrawable.setCornerRadius(TypedValue.applyDimension(1, 0.0f, context.getResources().getDisplayMetrics()));
        return gradientDrawable;
    }

    public static StateListDrawable botoes_hover(Context context) {
        StateListDrawable stateListDrawable = new StateListDrawable();
        stateListDrawable.addState(new int[]{16842919}, botoes_ativados(context));
        stateListDrawable.addState(new int[]{16842908}, botoes_ativados(context));
        stateListDrawable.addState(new int[]{-16842908, -16842919}, botoes(context));
        return stateListDrawable;
    }
	}
	
