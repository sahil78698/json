package Game.Mod;

import android.content.Context; 
import android.content.res.Resources; 
import android.graphics.Bitmap; 
import android.graphics.BitmapFactory; 
import android.graphics.Color; 
import android.graphics.drawable.BitmapDrawable; 
import android.graphics.drawable.Drawable; 
import android.graphics.drawable.GradientDrawable; 
import android.graphics.drawable.StateListDrawable; 
import android.util.Base64; 
import android.util.DisplayMetrics; 
import android.util.TypedValue; 

public class BadLayout {
	
public static GradientDrawable botoes(Context context) { 
    GradientDrawable buttonOff = new GradientDrawable();
	buttonOff.setShape(0);
	buttonOff.setStroke(3, -16776961);
	buttonOff.setCornerRadius(TypedValue.applyDimension(1, 0.0f, context.getResources().getDisplayMetrics()));
	return buttonOff;
}
public static GradientDrawable botoes2(Context context) {
	GradientDrawable butoeson = new GradientDrawable();
	butoeson.setShape(0);
	butoeson.setStroke(3, -16776961);
	butoeson.setColor(-16776961);
	butoeson.setCornerRadius(TypedValue.applyDimension(1, 0.0f, context.getResources().getDisplayMetrics()));
	return butoeson;
}
}
	
