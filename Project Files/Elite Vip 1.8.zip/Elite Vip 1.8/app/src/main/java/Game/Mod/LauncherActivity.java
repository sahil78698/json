package Game.Mod;
import android.annotation.TargetApi;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.app.AlertDialog;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.GradientDrawable;
import android.graphics.PixelFormat;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import java.io.IOException;
import android.text.Html;
import android.text.InputFilter;
import android.text.InputType;
import android.text.method.DigitsKeyListener;
import android.util.Base64;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import Game.Mod.ESPView;
import java.io.File;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import java.io.IOException;
import android.content.res.AssetManager;
import static android.widget.RelativeLayout.ALIGN_PARENT_RIGHT;
import static android.view.ViewGroup.LayoutParams.WRAP_CONTENT;
import static android.view.ViewGroup.LayoutParams.MATCH_PARENT;
import static android.widget.RelativeLayout.ALIGN_PARENT_LEFT;
import android.net.ConnectivityManager;
import java.net.HttpURLConnection;
import java.io.BufferedReader;
import java.io.InputStream;
import java.net.URL;
import android.os.AsyncTask;
import android.annotation.SuppressLint;
import java.io.InputStreamReader;

import Game.Mod.BadLauncher.Titanic;
import Game.Mod.BadLauncher.TitanicTextView;
public class LauncherActivity extends Service {
	final int TEXT_COLOR = Color.parseColor("#000000");
    final int TEXT_COLOR_2 = Color.parseColor("#FFFFFF");
    final int BTN_COLOR = Color.parseColor("#000000");
    final int MENU_BG_COLOR = Color.parseColor("#000000"); //#AARRGGBB
    final int MENU_FEATURE_BG_COLOR = Color.parseColor("#000000"); //#AARRGGBB
    final int MENU_WIDTH = 290;
    final int MENU_HEIGHT = 210;
    final float MENU_CORNER = 20f;
    final int ICON_SIZE = 50;
    final float ICON_ALPHA = 0.7f; //Transparent
    public View mFloatingView;
	private Button kill;
    private Button close;
    private LinearLayout mButtonPanel;
    public RelativeLayout mCollapsed;
    public LinearLayout mExpanded;
    private RelativeLayout mRootContainer;
    public WindowManager mWindowManager;
    public WindowManager.LayoutParams params;
    private LinearLayout patches;
    private FrameLayout rootFrame;
    private ImageView startimage;
    private LinearLayout view1;
    private LinearLayout view2;
	private LinearLayout Btns;
    private LinearLayout Btns2;
    private AlertDialog alert;
    private EditText edittextvalue;
    private LinearLayout mLinearLayout2;
    private ImageView ffid;
    private ImageView ffidXX;
    private ImageView phs;
    private LinearLayout patches2;
	private ESPView overlayView;
	public static native void DrawOn(ESPView espView, Canvas canvas);
	private WindowManager.LayoutParams espParams;
    private static final String TAG = "Mod Menu";
    public static native String Toast();
    private native String Icon();
    private native String Title();
    private native String Heading();
    private native boolean EnableSounds();
    private native String Iconps();
    private native int IconSize();
    public native void Changes(int feature, int value);
    private native String[] getFeatureList();
    private TextView addText(String string) {
        TextView textView = new TextView(this);
        textView.setText((CharSequence)string);
        textView.setTextColor(Color.WHITE);
        textView.setTextSize(13.0f);
        textView.setTypeface(null, Typeface.BOLD);
        textView.setPadding(5, 0, 0, 5);
        textView.setGravity(Gravity.LEFT);
        return textView;
	}
    private static String getArch(String string) {
        if (string.contains((CharSequence)"lib/arm64")) {
            return "arm64";
        }
        if (string.contains((CharSequence)"lib/arm")) {
            return "armv7";
        }
        if (string.contains((CharSequence)"lib/x86")) {
            return "x86";
        }
        return "";
    }
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    public int onStartCommand(Intent intent, int i, int i2) {
        return Service.START_NOT_STICKY;
    }
	private int getLayoutType() {
        if (Build.VERSION.SDK_INT >= 26) {
            return 2038;
        }
        if (Build.VERSION.SDK_INT >= 24) {
            return 2002;
        }
        if (Build.VERSION.SDK_INT >= 23) {
            return 2005;
        }
        return 2003;
    }
	private void DrawCanvas() {
        WindowManager.LayoutParams layoutParams;
        this.espParams = layoutParams = new WindowManager.LayoutParams(-1, -1, this.getLayoutType(), 56, -3);
        layoutParams.gravity = 8388659;
        this.espParams.x = 0;
        this.espParams.y = 0;
        this.mWindowManager.addView((View)this.overlayView, (ViewGroup.LayoutParams)this.espParams);
    }

	//When this Class is called the code in this function will be executed
	@Override
    public void onCreate() {
		super.onCreate();
        //A little message for the user when he opens the app
        //Toast.makeText(this, Toast(), Toast.LENGTH_LONG).show();
        //Init Lib

        // When you change the lib name, change also on Android.mk file
        // Both must have same name
        System.loadLibrary("hook");
		this.overlayView = new ESPView((Context)this);
        try {
            this.initFloating();
		} catch (IOException e) {}
        DrawCanvas();
		CreateMenuList();
        final Handler handler = new Handler();
        handler.post(new Runnable() {
                public void run() {
                    handler.postDelayed(this, 1000);
                }
            });
    }

    //Here we write the code for our Menu

    private void initFloating() throws IOException {
        ImageView imageView;
        rootFrame = new FrameLayout(getBaseContext()); // Global markup
        mRootContainer = new RelativeLayout(getBaseContext()); // Markup on which two markups of the icon and the menu itself will be placed
        mCollapsed = new RelativeLayout(getBaseContext()); // Markup of the icon (when the menu is minimized)
        mExpanded = new LinearLayout(getBaseContext()); // Menu markup (when the menu is expanded)
        view1 = new LinearLayout(getBaseContext());
        patches = new LinearLayout(getBaseContext());
        view2 = new LinearLayout(getBaseContext());
		Btns = new LinearLayout(getBaseContext());
        Btns2 = new LinearLayout(getBaseContext());
		mButtonPanel = new LinearLayout(getBaseContext()); // Layout of option buttons (when the menu is expanded)
		AssetManager assetManager = getAssets();
        patches2 = new LinearLayout(getBaseContext());
		
		rootFrame.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        mCollapsed.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        mCollapsed.setVisibility(View.VISIBLE);
        rootFrame.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        mRootContainer.setLayoutParams(new FrameLayout.LayoutParams(-2, -2));
        mCollapsed.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        mCollapsed.setVisibility(View.VISIBLE);
		
		view1.setLayoutParams(new LinearLayout.LayoutParams(-1, 2));
		view1.setBackgroundColor(-1);
		
		view2.setLayoutParams(new LinearLayout.LayoutParams(-1, 2));
		view2.setBackgroundColor(-1);
		
        startimage = new ImageView(getBaseContext());
        startimage.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        int applyDimension = (int) TypedValue.applyDimension(1, (float) IconSize(), getResources().getDisplayMetrics());
        startimage.getLayoutParams().height = applyDimension;
        startimage.getLayoutParams().width = applyDimension;
        startimage.requestLayout();
        startimage.setScaleType(ImageView.ScaleType.FIT_XY);
        byte[] decode = Base64.decode(Icon(), 0);
        startimage.setImageBitmap(BitmapFactory.decodeByteArray(decode, 0, decode.length));
        ((ViewGroup.MarginLayoutParams) startimage.getLayoutParams()).topMargin = convertDipToPixels(10);
		
        
        
        this.ffid = new ImageView(getBaseContext());
        RelativeLayout.LayoutParams ffid_LayoutParams = new RelativeLayout.LayoutParams(-0, -2);
        this.ffid.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        ffid_LayoutParams.addRule(0, -0);
        ffid_LayoutParams.setMarginEnd((int) ((0.0f) + 0.0f));
        this.ffid.getLayoutParams().height = dp(55);
        this.ffid.getLayoutParams().width = dp(55);
        this.ffid.requestLayout();
        this.ffid.setPadding(0, 0, 0, 0);
        this.ffid.setTranslationX(0);
        this.ffid.setTranslationY(0);
        InputStream inputStream_close2 = null;
        try {
            inputStream_close2 = assetManager.open("icon.png");
        } catch (IOException e) {
            e.printStackTrace();
        }
        Drawable ic_close2 = Drawable.createFromStream(inputStream_close2, null);
        ffid.setImageDrawable(ic_close2);
        ((ViewGroup.MarginLayoutParams) this.ffid.getLayoutParams()).leftMargin = convertDipToPixels(0);
        
        this.ffidXX = new ImageView(getBaseContext());
        RelativeLayout.LayoutParams ffidXX_LayoutParams = new RelativeLayout.LayoutParams(-0, -2);
        this.ffidXX.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        ffidXX_LayoutParams.addRule(0, -0);
        ffidXX_LayoutParams.setMarginEnd((int) ((0.0f) + 0.0f));
        this.ffidXX.getLayoutParams().height = dp(40);
        this.ffidXX.getLayoutParams().width = dp(40);
        this.ffidXX.requestLayout();
        this.ffidXX.setPadding(0, 0, 0, 0);
        this.ffidXX.setTranslationX(0);
        this.ffidXX.setTranslationY(0);
        InputStream inputStream_close20 = null;
        try {
            inputStream_close20 = assetManager.open("icon.png");
        } catch (IOException e) {
            e.printStackTrace();
        }
        Drawable ic_close20 = Drawable.createFromStream(inputStream_close20, null);
        ffidXX.setImageDrawable(ic_close20);
        ((ViewGroup.MarginLayoutParams) this.ffidXX.getLayoutParams()).leftMargin = convertDipToPixels(0);
        
	//_____Main Layout	
        mExpanded.setVisibility(View.GONE); 
        mExpanded.setGravity(17);
        mExpanded.setOrientation(LinearLayout.VERTICAL);
        android.graphics.drawable.GradientDrawable BJGEDBC = new android.graphics.drawable.GradientDrawable();
        int BJGEDBCADD[] = new int[]{ Color.parseColor("#918B0000"), Color.parseColor("#918B0000") };
        BJGEDBC.setColors(BJGEDBCADD);
        BJGEDBC.setOrientation(android.graphics.drawable.GradientDrawable.Orientation.RIGHT_LEFT);
        BJGEDBC.setCornerRadii(new float[] { 10, 10, 10, 10, 10, 10, 10, 10 });
		BJGEDBC.setStroke(2,-1);
        mExpanded.setBackground(BJGEDBC);	
        mExpanded.setPadding(3, 3, 3, 0);
        mExpanded.setLayoutParams(new LinearLayout.LayoutParams(dp(220), dp(310)));
   
//______Scroll layout
        final ScrollView scrollView = new ScrollView(getBaseContext());
        scrollView.setPadding(0, 0, 0, 0);
        scrollView.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(220)));
     
        patches.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        patches.setOrientation(LinearLayout.VERTICAL);
        patches2 = new LinearLayout(this);
        patches2.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        patches2.setOrientation(1);
		patches2.setVisibility(View.GONE);
        mButtonPanel.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));

        
        RelativeLayout relativeLayout = new RelativeLayout(this);
		relativeLayout.setPadding(5,0,5,5);
		
        kill = new Button(this);
        kill.setBackgroundColor(Color.parseColor("#ff0000"));
		kill.setTextSize(15.0f);
		kill.setTypeface((Typeface) null, 1);
        kill.setText("HIDE");
        kill.setTextColor(Color.WHITE);
		
		kill.setShadowLayer(2.0f,0.0f,0.0f,Color.BLUE);
        android.graphics.drawable.GradientDrawable CDGAEAH = new android.graphics.drawable.GradientDrawable();CDGAEAH.setColor(Color.parseColor("#ff0000"));
        CDGAEAH.setCornerRadii(new float[] { 0, 0, 0, 0, 0, 0, 0, 0 });
		kill.setBackground(CDGAEAH);
		CDGAEAH.setColor(Color.TRANSPARENT);
		CDGAEAH.setStroke(2,-1);
		kill.setBackground(CDGAEAH);

        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams.addRule(11);
        close = new Button(this);
        close.setBackgroundColor(Color.parseColor("#FF0000"));
		close.setTextSize(15.0f);
		close.setTypeface((Typeface) null, 1);
        close.setText("CLOSE");
		close.setShadowLayer(2.0f,0.0f,0.0f,Color.BLUE);
        close.setTextColor(Color.WHITE);
        close.setLayoutParams(layoutParams);
		//layoutParams.bottomMargin = dp(3);
		//layoutParams.rightMargin = dp(3);
		android.graphics.drawable.GradientDrawable 
		CDGAEAHH = new android.graphics.drawable.GradientDrawable();
		CDGAEAHH.setColor(Color.parseColor("#ff0000"));
        CDGAEAHH.setCornerRadii(new float[] { 10, 10, 10, 10, 10, 10, 10, 10 });
		CDGAEAHH.setColor(Color.TRANSPARENT);
		CDGAEAHH.setStroke(2,-1);
		close.setBackground(CDGAEAHH);
		
        relativeLayout.addView(close);
		relativeLayout.addView(kill);
        
        phs = new ImageView(this);
        RelativeLayout.LayoutParams phs_LayoutParams = new RelativeLayout.LayoutParams(-2, -2);
        phs.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        phs_LayoutParams.addRule(21, -1);
        phs_LayoutParams.setMarginEnd((int) ((275.0f) + 0.0f));
        phs.getLayoutParams().height = dp(48);
        phs.getLayoutParams().width = dp(48);
        phs.requestLayout();
        phs.setScaleType(ImageView.ScaleType.FIT_START);
        byte[] decode3 = Base64.decode(Iconps(), 4);
        phs.setImageBitmap(BitmapFactory.decodeByteArray(decode3, 0, decode3.length));
        ((ViewGroup.MarginLayoutParams) this.phs.getLayoutParams()).leftMargin = convertDipToPixels(5);
		
//______TITLE [BY BAD MODDER]/[MGA-ZG]______\\
		
        RelativeLayout titleText = new RelativeLayout(this);
		titleText.setVerticalGravity(16);
		
        TitanicTextView badmod = new TitanicTextView(this);
		badmod.setText("ELITE VIP V1.8");
        badmod.setTextColor(-1);
		badmod.setTextSize(22.0f);
		badmod.setTypeface((Typeface) null, 1);
		badmod.setGravity(Gravity.CENTER);
        badmod.setPadding(30, 15, 5, 0);
		
		RelativeLayout.LayoutParams rl = new RelativeLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT);
        rl.addRule(RelativeLayout.CENTER_HORIZONTAL);
        badmod.setLayoutParams(rl);	
		new Titanic().start(badmod);
		
        rootFrame.addView(mRootContainer);
        mRootContainer.addView(mCollapsed);
        mRootContainer.addView(mExpanded);
        mCollapsed.addView(ffid);
        mExpanded.addView(titleText);
        titleText.addView(ffidXX);
        titleText.addView(badmod);
        mExpanded.addView(view1);
        mExpanded.addView(scrollView);
        scrollView.addView(patches);
        mExpanded.addView(relativeLayout);
        mFloatingView = rootFrame;
		
		if (Build.VERSION.SDK_INT >= 26) {
            params = new WindowManager.LayoutParams(-2, -2, 2038, 8, -3);
        } else {
            params = new WindowManager.LayoutParams(-2, -2, 2002, 8, -3);
        }
        WindowManager.LayoutParams layoutParams4 = params;
        layoutParams4.gravity = 51;
        layoutParams4.x = 0;
        layoutParams4.y = 100;
        mWindowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        mWindowManager.addView(mFloatingView, params);

        RelativeLayout relativeLayout2 = mCollapsed;
        LinearLayout linearLayout = mExpanded;
        mFloatingView.setOnTouchListener(onTouchListener());
        startimage.setOnTouchListener(onTouchListener());
        initMenuButton(relativeLayout2, linearLayout);

    }

    private View.OnTouchListener onTouchListener() {
        return new View.OnTouchListener() {
            final View collapsedView = mCollapsed;
            final View expandedView = mExpanded;
            private float initialTouchX;
            private float initialTouchY;
            private int initialX;
            private int initialY;

            public boolean onTouch(View view, MotionEvent motionEvent) {
                switch (motionEvent.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = motionEvent.getRawX();
                        initialTouchY = motionEvent.getRawY();
                        return true;
                    case MotionEvent.ACTION_UP:
                        int rawX = (int) (motionEvent.getRawX() - initialTouchX);
                        int rawY = (int) (motionEvent.getRawY() - initialTouchY);

                        //The check for Xdiff <10 && YDiff< 10 because sometime elements moves a little while clicking.
                        //So that is click event.
                        if (rawX < 10 && rawY < 10 && isViewCollapsed()) {                     
                            collapsedView.setVisibility(View.GONE);
                            expandedView.setVisibility(View.VISIBLE);

                            //Toast.makeText(FloatingModMenuService.this, Html.fromHtml(Toast()), Toast.LENGTH_SHORT).show();
                        }
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        //Calculate the X and Y coordinates of the view.
                        params.x = initialX + ((int) (motionEvent.getRawX() - initialTouchX));
                        params.y = initialY + ((int) (motionEvent.getRawY() - initialTouchY));

                        //Update the layout with new X & Y coordinate
                        mWindowManager.updateViewLayout(mFloatingView, params);
                        return true;
                    default:
                        return false;
                }
            }
        };
    }


	private boolean hide = false;

	//Initialize event handlers for buttons, etc.
    private void initMenuButton(final View view2, final View view3) {
        startimage.setOnClickListener(new View.OnClickListener() {
				public void onClick(View view) {
					view2.setVisibility(View.GONE);
					view3.setVisibility(View.VISIBLE);
				}
			});
		close.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {

                    mCollapsed.setVisibility(0);
                    mCollapsed.setAlpha(0.95f);
                    mExpanded.setVisibility(8);
                }
            });
    }


    private void CreateMenuList() {
        String[] listFT = getFeatureList();
        for (int i = 0; i < listFT.length; i++) {
            final int feature = i;
            String str = listFT[i];
            if (str.contains("TG_")) {

                addSwitch(str.replace("TG_", ""), new InterfaceBool() {
                        public void OnWrite(boolean z) {
                            Changes(feature, 0);
                        }
                    });
            } else if (str.contains("SeekBar_")) {
                String[] split = str.split("_");
                addSeekBar(split[1], Integer.parseInt(split[2]), Integer.parseInt(split[3]), new InterfaceInt() {
                        public void OnWrite(int i) {
                            Changes(feature, i);
                        }
                    });
            } else if (str.contains("SeekBarSpot_")) {
                String[] split = str.split("_");
                addSeekBarSpot(split[1], Integer.parseInt(split[2]), Integer.parseInt(split[3]), new InterfaceInt() {
                        public void OnWrite(int i) {
                            Changes(feature, i);
                        }
                    });
			} else if (str.contains("Color_")) {
                String[] split = str.split("_");
                addEsp(split[1], Integer.parseInt(split[2]), Integer.parseInt(split[3]), new InterfaceInt() {
                        public void OnWrite(int i) {
                            Changes(feature, i);
                        }
                    });
                  }
                }
              }
    private TextView textView2;
    private String featureNameExt;
    private int featureNum;
    private EditTextValue txtValue;

    public class EditTextValue {
        private int val;

        public void setValue(int i) {
            val = i;
        }

        public int getValue() {
            return val;
        }
    }

    private void addTextField(final String featureName, final int feature, final InterfaceInt interInt) {
        RelativeLayout relativeLayout2 = new RelativeLayout(this);
        relativeLayout2.setLayoutParams(new RelativeLayout.LayoutParams(-2, -1));
        relativeLayout2.setPadding(10, 5, 10, 5);
        relativeLayout2.setVerticalGravity(16);

        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams.topMargin = 10;

        final TextView textView = new TextView(this);
        textView.setText(Html.fromHtml("<font face='roboto'>" + featureName + ": <font color='#fdd835'>Not set</font></font>"));
        textView.setTextColor(Color.parseColor("#DEEDF6"));
        textView.setLayoutParams(layoutParams);

        final TextView textViewRem = new TextView(this);
        textViewRem.setText("");

        final EditTextValue edittextval = new EditTextValue();

        RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams2.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);

        Button button2 = new Button(this);
        button2.setLayoutParams(layoutParams2);
        button2.setBackgroundColor(Color.parseColor("#1C262D"));
        button2.setText("SET");
        button2.setTextColor(Color.parseColor("#D5E3EB"));
        button2.setGravity(17);
        button2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    alert.show();
                    textView2 = textView;
                    featureNum = feature;
                    featureNameExt = featureName;
                    txtValue = edittextval;

                    edittextvalue.setText(String.valueOf(edittextval.getValue()));
                }
            });

        relativeLayout2.addView(textView);
        relativeLayout2.addView(button2);
        patches.addView(relativeLayout2);
    }

    private void initAlertDiag() {
        LinearLayout linearLayout1 = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        linearLayout1.setPadding(10, 5, 0, 5);
        linearLayout1.setOrientation(LinearLayout.VERTICAL);
        linearLayout1.setGravity(17);
        linearLayout1.setLayoutParams(layoutParams);
        linearLayout1.setBackgroundColor(Color.parseColor("Navy"));

        int i = Build.VERSION.SDK_INT >= 26 ? 2038 : 2002;
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        linearLayout.setBackgroundColor(Color.parseColor("#00ff00"));
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        FrameLayout frameLayout = new FrameLayout(this);
        frameLayout.setLayoutParams(new FrameLayout.LayoutParams(-2, -2));
        frameLayout.addView(linearLayout);

        final TextView textView = new TextView(this);
        textView.setText(Html.fromHtml("<font face='roboto'>Tap OK to apply changes. Tap outside to cancel</font>"));
        textView.setTextColor(Color.parseColor("#DEEDF6"));
        textView.setLayoutParams(layoutParams);

        edittextvalue = new EditText(this);
        edittextvalue.setLayoutParams(layoutParams);
        edittextvalue.setMaxLines(1);
        edittextvalue.setWidth(convertDipToPixels(300));
        edittextvalue.setTextColor(Color.parseColor("#93a6ae"));
        edittextvalue.setTextSize(13.0f);
        edittextvalue.setHintTextColor(Color.parseColor("#434d52"));
        edittextvalue.setInputType(InputType.TYPE_CLASS_NUMBER);
        edittextvalue.setKeyListener(DigitsKeyListener.getInstance("0123456789-"));

        InputFilter[] FilterArray = new InputFilter[1];
        FilterArray[0] = new InputFilter.LengthFilter(10);
        edittextvalue.setFilters(FilterArray);

        Button button = new Button(this);
        button.setBackgroundColor(Color.parseColor("Navy"));
        button.setTextColor(Color.parseColor("#D5E3EB"));
        button.setText("OK");
        button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Changes(featureNum, Integer.parseInt(edittextvalue.getText().toString()));
                    txtValue.setValue(Integer.parseInt(edittextvalue.getText().toString()));
                    textView2.setText(Html.fromHtml("<font face='roboto'>" + featureNameExt + ": <font color='#41c300'>" + edittextvalue.getText().toString() + "</font></font>"));
                    alert.dismiss();

                    //interStr.OnWrite(editText.getText().toString());
                }
            });

        alert = new AlertDialog.Builder(this, 2).create();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            Objects.requireNonNull(alert.getWindow()).setType(i);
        }
        linearLayout1.addView(textView);
        linearLayout1.addView(edittextvalue);
        linearLayout1.addView(button);
        alert.setView(linearLayout1);
    }

    private void addSpinner(String feature, final InterfaceInt interInt) {
        List<String> list = new LinkedList<>(Arrays.asList(feature.split("_")));

        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        linearLayout.setPadding(10, 5, 10, 5);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.setGravity(17);
        linearLayout.setLayoutParams(layoutParams);
        linearLayout.setBackgroundColor(Color.parseColor("#FF3F51B5"));

        final TextView textView = new TextView(this);
        textView.setText(Html.fromHtml("<font face='roboto'>" + list.get(0) + ": <font color='#FF3F51B5'></font>"));
        textView.setTextColor(Color.parseColor("#FF3F51B5"));

        // Create another LinearLayout as a workaround to use it as a background
        // and to keep the 'down' arrow symbol
        // If spinner had the setBackgroundColor set, there would be no arrow symbol
        LinearLayout linearLayout2 = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -1);
        layoutParams2.setMargins(10, 2, 10, 5);
        linearLayout2.setOrientation(LinearLayout.VERTICAL);
        linearLayout2.setGravity(17);
        linearLayout2.setBackgroundColor(Color.parseColor("#1C262D"));
        linearLayout2.setLayoutParams(layoutParams2);

        Spinner spinner = new Spinner(this);
        spinner.setPadding(5, 10, 5, 8);
        spinner.setLayoutParams(layoutParams2);
        spinner.getBackground().setColorFilter(1, PorterDuff.Mode.SRC_ATOP); //trick to show white down arrow color
        //Creating the ArrayAdapter instance having the list
        list.remove(0);
        ArrayAdapter aa = new ArrayAdapter(this, android.R.layout.simple_spinner_item, list);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //Setting the ArrayAdapter data on the Spinner
        spinner.setAdapter(aa);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                    ((TextView) parentView.getChildAt(0)).setTextColor(Color.parseColor("#f5f5f5"));
                    interInt.OnWrite(position);

                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });
        linearLayout.addView(textView);
        linearLayout2.addView(spinner);
        patches.addView(linearLayout);
        patches.addView(linearLayout2);
    }

    
    
	private void addSwitch(String str, final InterfaceBool sw) {
        final Switch switchR = new Switch(this);
        switchR.setBackgroundColor(Color.parseColor("#00000000"));
        switchR.setText(Html.fromHtml("<font face=>" + str + "</font>"));
        switchR.setTextColor(-1);
        switchR.setPadding(10, 5, 0, 5);
		switchR.getTrackDrawable().setColorFilter(Color.parseColor("#000000"), PorterDuff.Mode.SRC_IN);
        switchR.getThumbDrawable().setColorFilter(Color.parseColor("WHITE"), PorterDuff.Mode.SRC_IN);
        Typeface typefaceR = Typeface.createFromAsset(getAssets(), "Badmodd/mod.ttf"); 
		switchR.setTypeface(typefaceR);
        switchR.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                    if (z) {
						switchR.getTrackDrawable().setColorFilter(Color.parseColor("#FF0000"), PorterDuff.Mode.SRC_IN);
						switchR.getThumbDrawable().setColorFilter(Color.parseColor("#FF0000"), PorterDuff.Mode.SRC_IN);
                    } else {
                        switchR.getTrackDrawable().setColorFilter(Color.parseColor("#000000"), PorterDuff.Mode.SRC_IN);
						switchR.getThumbDrawable().setColorFilter(Color.parseColor("WHITE"), PorterDuff.Mode.SRC_IN);
                    }
                    if (z) {

                    } else {

                    }
                    sw.OnWrite(z);
                }
            });
        patches.addView(switchR);
    }
	
	private void addSeekBar(final String feature, final int prog, int max, final InterfaceInt interInt) {
        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        linearLayout.setPadding(5, 5, 0, 5);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.setGravity(Gravity.CENTER_HORIZONTAL);
        linearLayout.setLayoutParams(layoutParams);
        final TextView textView = new TextView(this);
        textView.setText(Html.fromHtml(feature + " : <font color='RED'>" + " OFF" + "</font>"));
        Typeface Type7 = Typeface.createFromAsset(getAssets(),"Badmodd/mod.ttf"); 
		textView.setTypeface(Type7);
        textView.setTextColor(Color.WHITE);
        SeekBar seekBar = new SeekBar(this);
		
		GradientDrawable seekbar = new GradientDrawable();
        seekbar.setShape(0);
        seekbar.setColor(Color.WHITE);
        seekbar.setColor(Color.parseColor("#ff0000"));
        seekbar.setStroke(dp(2), Color.parseColor("#ffffff"));
        seekbar.setCornerRadius(300.0f);
        seekbar.setSize(dp(17), dp(17));
        seekBar.setThumb(seekbar);
        seekBar.setPadding(25, 10, 35, 10);
        seekBar.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        seekBar.setMax(max);
        seekBar.setProgress(prog);
		seekBar.getProgressDrawable().setColorFilter(Color.GREEN, PorterDuff.Mode.SRC_IN);
		//seekBar.getThumb().setColorFilter(Color.LTGRAY, PorterDuff.Mode.SRC_ATOP);
		final TextView textView2 = textView;
		seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                public void onStartTrackingTouch(SeekBar seekBar) {
				}
				public void onStopTrackingTouch(SeekBar seekBar) {
				}

                int l;

                public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                    if (i == 0) {
                        seekBar.setProgress(i);
                        interInt.OnWrite(i);
                        TextView textView = textView2;
						textView.setText(Html.fromHtml("<font face=><b>" + feature + " : <font color='RED'>" + "Desativado" + "</font>"));

                        return;
                    }
                    interInt.OnWrite(i);
					textView.setText(Html.fromHtml("<font face=><b>" + feature + " : <font color='LTGRAY'>" + i + "</font>"));

                }
            });

        linearLayout.addView(textView);
        linearLayout.addView(seekBar);
       
        patches.addView(linearLayout);
    }

	
		
	private void addEsp(final String feature, final int prog, int max, final InterfaceInt interInt) {
        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        linearLayout.setPadding(5, 5, 0, 5);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.setGravity(Gravity.CENTER_HORIZONTAL);
        linearLayout.setLayoutParams(layoutParams);
        final TextView textView = new TextView(this);
        textView.setText(Html.fromHtml(feature + " : <font color='RED'>" + " OFF" + "</font>"));
        Typeface Type7 = Typeface.createFromAsset(getAssets(),"Badmodd/mod.ttf"); 
		textView.setTypeface(Type7);
        textView.setTextColor(Color.WHITE);
        SeekBar seekBar = new SeekBar(this);
		GradientDrawable seekbar = new GradientDrawable();
        seekbar.setShape(0);
        seekbar.setColor(Color.WHITE);
        seekbar.setColor(Color.parseColor("#ff0000"));
        seekbar.setStroke(dp(2), Color.parseColor("#ffffff"));
        seekbar.setCornerRadius(300.0f);
        seekbar.setSize(dp(17), dp(17));
        seekBar.setThumb(seekbar);
        seekBar.setPadding(25, 10, 35, 10);
        seekBar.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
		seekBar.getProgressDrawable().setColorFilter(Color.GREEN, PorterDuff.Mode.SRC_IN);
		seekBar.setMax(max);
		seekBar.setProgress(prog);
		final TextView textView4 = textView;
		seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                public void onStartTrackingTouch(SeekBar seekBar) {
				}
				public void onStopTrackingTouch(SeekBar seekBar) {
				}

                int l;
                public void onProgressChanged(SeekBar seekBar2, int i, boolean z) {
                    if (i == 0) {
                        seekBar2.setProgress(i);
                        interInt.OnWrite(i);
                        TextView textView = textView4;
						textView.setText(Html.fromHtml("<font face=><b>" + feature + " : <font color='WHITE'>" + "Branco" + "</font>"));
                    } else if (i == 1) {
                        seekBar2.setProgress(i);
                        interInt.OnWrite(i);
                        TextView textView = textView4;
						textView.setText(Html.fromHtml("<font face=><b>" + feature + " : <font color='GREEN'>" + "Verde" + "</font>"));
                    } else if (i == 2) {
                        seekBar2.setProgress(i);
                        interInt.OnWrite(i);
                        TextView textView = textView4;
                        textView.setText(Html.fromHtml("<font face=><b>" + feature + ": <font color='Blue'>" + "Azul" + "</b></font>"));
                    } else if (i == 3) {
                        seekBar2.setProgress(i);
                        interInt.OnWrite(i);
                        TextView textView = textView4;
                        textView.setText(Html.fromHtml("<font face=><b>" + feature + ": <font color='Red'>" + "Vermelho" + "</b></font>"));
                        //(Html.fromHtml("<font face='monospace'><b>" + feature + ": <font color='#ffffff15'>" + "6m (Ghost)" + "</b></font>"));
					} else if (i == 4) {
                        seekBar2.setProgress(i);
                        interInt.OnWrite(i);
                        TextView textView = textView4;
                        textView.setText(Html.fromHtml("<font face=><b>" + feature + ": <font color='Yellow'>" + "Amarelo" + "</b></font>"));

					} else if (i == 5) {
                        seekBar2.setProgress(i);
                        interInt.OnWrite(i);
                        TextView textView = textView4;
                        textView.setText(Html.fromHtml("<font face=><b>" + feature + ": <font color='Cyan'>" + "Ciano" + "</b></font>"));

					} else if (i == 6) {
                        seekBar2.setProgress(i);
                        interInt.OnWrite(i);
                        TextView textView = textView4;
                        textView.setText(Html.fromHtml("<font face=><b>" + feature + ": <font color='Magenta'>" + "Rosa" + "</b></font>"));


                    }
                    interInt.OnWrite(i);
                }
            });

        this.patches.addView(textView);
        this.patches.addView(seekBar);
    }
	
	private void addSeekBarSpot(final String feature, final int prog, int max, final InterfaceInt interInt) {
        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        linearLayout.setPadding(5, 5, 0, 5);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.setGravity(Gravity.CENTER_HORIZONTAL);
        linearLayout.setLayoutParams(layoutParams);
        final TextView textView = new TextView(this);
        textView.setText(Html.fromHtml(feature + " : <font color='RED'>" + " OFF" + "</font>"));
        Typeface Type9 = Typeface.createFromAsset(getAssets(),"Badmodd/mod.ttf"); 
		textView.setTypeface(Type9);
        textView.setTextColor(Color.WHITE);
        SeekBar seekBar = new SeekBar(this);
		GradientDrawable seekbar = new GradientDrawable();
        seekbar.setShape(0);
        seekbar.setColor(Color.WHITE);
        seekbar.setColor(Color.parseColor("#ff0000"));
        seekbar.setStroke(dp(2), Color.parseColor("#ffffff"));
        seekbar.setCornerRadius(300.0f);
        seekbar.setSize(dp(17), dp(17));
        seekBar.setThumb(seekbar);
        seekBar.setPadding(25, 10, 35, 10);
        seekBar.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        seekBar.setMax(max);
        seekBar.setProgress(prog);
		seekBar.getProgressDrawable().setColorFilter(Color.GREEN, PorterDuff.Mode.SRC_IN);
		final TextView textView2 = textView;
		seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                public void onStartTrackingTouch(SeekBar seekBar) {
				}
				public void onStopTrackingTouch(SeekBar seekBar) {
				}

                int l;

                public void onProgressChanged(SeekBar seekBar2, int i, boolean z) {
                    if (i == 0) {
                        seekBar2.setProgress(i);
                        interInt.OnWrite(i);
                        TextView textView = textView2;
						textView.setText(Html.fromHtml("<font face=><b>" + feature + " : <font color='WHITE'>" + "Off" + "</font>"));
                    } else if (i == 1) {
                        seekBar2.setProgress(i);
                        interInt.OnWrite(i);
                        TextView textView = textView2;
						textView.setText(Html.fromHtml("<font face=><b>" + feature + " : <font color='#FF0000'>" + "Cabeça" + "</font>"));
                    } else if (i == 2) {
                        seekBar2.setProgress(i);
                        interInt.OnWrite(i);
                        TextView textView = textView2;
						textView.setText(Html.fromHtml("<font face=><b>" + feature + " : <font color='WHITE'>" + "Quadril" + "</b></font>"));
                    } else if (i == 3) {
                        seekBar2.setProgress(i);
                        interInt.OnWrite(i);
                        TextView textView = textView2;
                        textView.setText(Html.fromHtml("<font face=><b>" + feature + " : <font color='WHITE'>" + "Pé" + "</b></font>"));
                    }
                    interInt.OnWrite(i);
                }
            });

        linearLayout.addView(textView);
        linearLayout.addView(seekBar);
        patches.addView(linearLayout);
    }
    boolean delayed;



    public boolean isViewCollapsed() {
        return mFloatingView == null || mCollapsed.getVisibility() == View.VISIBLE;
    }

    //For our image a little converter
    private int convertDipToPixels(int i) {
        return (int) ((((float) i) * getResources().getDisplayMetrics().density) + 0.5f);
    }

    private int dp(int i) {
        return (int) TypedValue.applyDimension(1, (float) i, getResources().getDisplayMetrics());
    }

    //Destroy our View
    public void onDestroy() {
        super.onDestroy();

        if (view2 != null) {
            this.mWindowManager.removeView(view2);
        }
        View view = mFloatingView;
        if (view != null) {
            mWindowManager.removeView(view);
        }
    }

    // checking if any network connection / internet available

    // calling our AsyncTask Function that will do thee thing on fetching data from out host file

    // this is the checking one, this will draw our menu if it's license still valid or active

    //Check if we are still in the game. If now our Menu and Menu button will dissapear
    private boolean isNotInGame() {
        RunningAppProcessInfo runningAppProcessInfo = new RunningAppProcessInfo();
        ActivityManager.getMyMemoryState(runningAppProcessInfo);
        return runningAppProcessInfo.importance != 100;
    }

    //Same as above so it wont crash in the background and therefore use alot of Battery life


    private interface InterfaceBtn {
        void OnWrite();
    }

    private interface InterfaceInt {
        void OnWrite(int i);
    }

    private interface InterfaceBool {
        void OnWrite(boolean z);
    }

    private interface InterfaceStr {
        void OnWrite(String s);
    }
}
