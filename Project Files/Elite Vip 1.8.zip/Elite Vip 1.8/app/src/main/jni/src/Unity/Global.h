#ifndef ANDROID_MOD_MENU_GLOBAL_H
#define ANDROID_MOD_MENU_GLOBAL_H

struct {

 uintptr_t HeadTF = 0x220;//1.69 By MrViniRX
   uintptr_t Get_PosisiKepala = 0x220;
  uintptr_t Get_PosisiBadan = 0x224;
       uintptr_t Get_SpofNick = 0xb4e2dc;
uintptr_t  Get_PhysXPose = 0xb5ef3c;
    uintptr_t HipTF = 0x224;//1.69 By MrViniRX
    uintptr_t HandTF = 0x21C;//1.69 By MrViniRX
 uintptr_t HandTFF = 0x21C;//1.69 By MrViniRX
    uintptr_t ToeTF = 0x234;//1.69 By MrViniRX
 uintptr_t DedoTF = 0x24C;//1.69 By MrViniRX
    uintptr_t PeS = 0x244;//1.69 By MrViniRX
    uintptr_t PeD = 0x248;//1.69 By MrViniRX
    uintptr_t LShoulder = 0x250;//1.69 By MrViniRX
    uintptr_t RShoulder = 0x254;//1.69 By MrViniRX
 uintptr_t PeEsquerdo = 0x1D8;//NÃO ATT
 uintptr_t OmbroD = 0x248; // 1.69 By MrViniRX
    uintptr_t OmbroE = 0x24C; // 1.69 By MrViniRX
    uintptr_t PernaD = 0x23C; // 1.69 By MrViniRX
    uintptr_t PernaE = 0x240; // 1.69 By MrViniRX
    uintptr_t BracoD = 0x244; // 1.69 By MrViniRX
    uintptr_t BracoE = 0x21C; // 1.69 By MrViniRX
 
    uintptr_t IsClientBot = 0x110;//1.69 By MrViniRX

 uintptr_t U3DStr = 0x3772CE4; //  1.69 By MrViniRX
    uintptr_t Component_GetTransform = 0x36D38DC; //  1.69 By MrViniRX
    uintptr_t Transform_INTERNAL_GetPosition = 0x34B3E10; // ATUALIZADO 1.69 By MrViniRX
    uintptr_t Transform_INTERNAL_SetPosition = 0x34B3EB0; // ATUALIZADO 1.69 By MrViniRX
    
    uintptr_t GetForward = 0x34B4970;//1.69 By MrViniRX
 uintptr_t GetLocalPlayer = 0x1D6D4D0;//1.69 By MrViniRX

 uintptr_t GetLocalPlayerOrObServer = 0x1517548; //1.69 By MrViniRX
 uintptr_t Camera_main = 0x36D19DC;// public static Camera get_main() { }
uintptr_t AddTeammateHud = 0xCC8328; //public void ShowAssistantText(string playerName, string line) { }

    uintptr_t get_isAlive = 0xBB394C; //1.69 By MrViniRX
 uintptr_t get_isVisible = 0xB5465C; //1.69 By MrViniRX
 uintptr_t get_IsDieing = 0xB4FC2C; //1.69 By MrViniRX
 uintptr_t get_IsSighting = 0xBE315C; //1.69 By MrViniRX
    uintptr_t get_IsCrouching = 0xB5EFB4; //1.69 By MrViniRX
    uintptr_t get_isLocalTeam = 0xB5CD48; //1.69 By MrViniRX
    
    uintptr_t get_imo = 0xB49EE4;//1.69 By MrViniRX
    uintptr_t get_main = 0x36D19DC; //1.69 By MrViniRX
 uintptr_t get_IsFiring = 0xBA93FC;//1.69 By MrViniRX
 uintptr_t get_CurHp = 0x1CCA530; //1.69 By MrViniRX
    uintptr_t get_MaxHP = 0xB93090; //1.69 By MrViniRX
    uintptr_t get_NickName = 0xB4E284; //1.69 By MrViniRX
    uintptr_t get_MyFollowCamera = 0xB4FDDC; //1.69 By MrViniRX
 
    uintptr_t GetWeaponType = 0xBA95C8; // public ytMNhlw.Utan}] GetWeaponType() { }
    
 uintptr_t set_aim = 0xB5108C; //1.69 By MrViniRX
    
 uintptr_t Curent_Match = 0x1515568; //1.69 By MrViniRX
    uintptr_t CurrentUIScene = 0x15144D8; //1.69 By MrViniRX
    uintptr_t Current_Local_Player = 0x1515958; //1.69 By MrViniRX
 uintptr_t ObterVeiculo = 0xB520AC;//1.68
			
    uintptr_t EstaDirigindo = 0xB51D84;//1.68
       uintptr_t MyCar = 0xB536F4;//1.68
    uintptr_t ShowDynamicPopupMessage = 0xCAC844; //1.69 By MrViniRX
    uintptr_t ShowPopupMessage = 0xCAC9DC; //1.69 By MrViniRX
 uintptr_t ShowAssistantText = 0xCC8328; //1.69 By MrViniRX
    uintptr_t CurrentMatch = 0x1515568;//1.69 By MrViniRX
 
 uintptr_t Dictionary = 0x48; //1.69 By MrViniRX
    uintptr_t MainCameraTransform = 0x88;//1.69 By MrViniRX
    uintptr_t WorldToScreenPoint = 0x36D1068; //1.69 By MrViniRX
 
 uintptr_t GetHeadCollider = 0xB4FF7C; //1.69 By MrViniRX public virtual Collider get_HeadCollider() { }
    uintptr_t Visible_Ray = 0x1C08298; //1.69 By MrViniRX public static bool PLDCHDBCOBF(Vector3
   
	//ESP GRANADA
	uintptr_t LineRenderer_Set_PositionCount = 0x3589FE8;//public void set_positionCount(int value) { } 1.69
	uintptr_t LineRenderer_SetPosition = 0x358A094;//public void SetPosition(int index, Vector3 position) { } 1.69
	uintptr_t GrenadeLine_DrawLine = 0x22F6A4C;//private void DrawLine2(Vector3 throwPos, Vector3 throwVel, Vector3 gravity) { } 1.69
    uintptr_t GrenadeLine_Update = 0x22F64A0;//private void Update() { } 1.69
    uintptr_t set_startColor = 0x3589E08;//public void set_startColor(Color value) { } //1.69
    uintptr_t set_endColor = 0x3589EAC;//public void set_endColor(Color value) { } //1.69
	//ESP GRQNADA
	
	//ALMENTA COR DO ESP FIRE
	uintptr_t GetAttackableCenterWS = 0x1D82564;//1.69
	//ALMENTA COR DO ESP FIRE
	
	//TELEPOET CAR
	uintptr_t GetLocalCar = 0xB520AC;
	//TELEPPET CAR 
	
	//ESP FIRE
	uintptr_t set_esp = 0x1E597B8; //1.69 By MrViniRX
	//ESP FIRE
	
} Global;

#endif


