package Game.Mod;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Process;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.text.Html;
import android.util.Base64;
import android.util.Log;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Looper;
import android.os.Bundle;
import android.view.View;
import android.content.DialogInterface;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class  StaticActivity {

    private static final String TAG = "Mod Menu";

	public static String FFMainActivity;
	public static String cacheDir;

    public static void Start (final Context context) {

        String currentTime = new SimpleDateFormat("yyyyMMdd").format(Calendar.getInstance().getTime());
        Log.d("timeStamp", currentTime);
		Calendar date = new GregorianCalendar(20220, Calendar. FEBRUARY , 31); //
        date.add(Calendar.DAY_OF_WEEK, 0);            //Ghi Tháng ở Trên
        String expireTime = new SimpleDateFormat("yyyyMMdd").format(date.getTime());
        int intcurrentTime = Integer.parseInt(currentTime);
        int intexpireTime = Integer.parseInt(expireTime);
        if(intcurrentTime >= intexpireTime) {


            Toast.makeText(context,(Html.fromHtml("<b><font color=#FF0000>Mod Expire </font></b><font color=#FF0000><b>(Hết Hạn)</b></font>")), Toast.LENGTH_SHORT).show();
			Toast.makeText(context,(Html.fromHtml("<b><font color=#FF0000>Please </font></b><font color=#FF0000><b>Update!</b></font>")), Toast.LENGTH_SHORT).show();


            String url = "https://youtube.com/channel/UCk6RO6YBTbIlnuR2mHo79Jw";
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://youtu.be/8qzk81s9fqs"));
            i.setData(Uri.parse(url));
            context.startActivity(i);
            final Handler handler = new Handler(Looper.getMainLooper());
            handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        System.exit(0);
                    }
                }, 2000);;
        }

        if (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(context)) {
            new Handler().postDelayed(new Runnable() {
                    public void run() {
                        AlertDialog.Builder builder = new AlertDialog.Builder(context);
                        builder.setTitle(Html.fromHtml("<font color=BLACK>AVISO!</b></font>"));
                      
                        builder.setCancelable(false);
					    builder.setPositiveButton(Html.fromHtml("<b><font color=BLACK>CONTINUE</font>"), new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog,int which) {
                                    context.startService(new Intent(context, LauncherActivity.class));
                                }
                            });

						builder.setCancelable(false);
                        builder.setNegativeButton(Html.fromHtml("<b><font color=BLACK>TELEGRAM</font>"), new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog,int which) {
                                    Uri uri = Uri.parse("");
									Intent intent = new Intent(
										Intent.ACTION_VIEW, uri);
									startActivity(intent);
									String url = "";
									Intent i = new Intent(Intent.ACTION_VIEW);
									i.setData(Uri.parse(url));
									context.startActivity(i);
                                }
								private void startActivity(Intent intent) {
								}
                            });

						builder.setCancelable(false);
                        builder.setNeutralButton(Html.fromHtml("<b><font color=BLACK>YOUTUBE</font>"), new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog,int which) {
                                    Uri uri = Uri.parse("");
									Intent intent = new Intent(
										Intent.ACTION_VIEW, uri);
									startActivity(intent);
									String url = "";
									Intent i = new Intent(Intent.ACTION_VIEW);
									i.setData(Uri.parse(url));
									context.startActivity(i);
                                }
								private void startActivity(Intent intent) {
								}
                            });


                        builder.create().show();
                    }
                }, 1800);
        } else {
            context.startActivity(new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION", Uri.parse("package:" + context.getPackageName())));
            Process.killProcess(Process.myPid());
        }


		cacheDir = context.getCacheDir().getPath() + "/";

		/*   writeToFile("OpenMenu.ogg", Sounds.OpenMenu());
		 writeToFile("Back.ogg", Sounds.Back());
		 writeToFile("Select.ogg", Sounds.Select());
		 writeToFile("SliderIncrease.ogg", Sounds.SliderIncrease());
		 writeToFile("SliderDecrease.ogg", Sounds.SliderDecrease());
		 writeToFile("On.ogg", Sounds.On());
		 writeToFile("Off.ogg", Sounds.Off());  */

		/* AssetManager assets = context.getAssets();
		 String str2 = cacheDir + "/Slider-Switch.ogg";
		 try {
		 copyFile(assets.open("Slider-Switch.ogg"), new FileOutputStream(str2));
		 } catch (IOException e) {
		 e.printStackTrace();
		 }*/
    }

    private static void writeToFile(String name, String base64) {
        File file = new File(cacheDir + name);
        try {
            if (!file.exists()) {
                file.createNewFile();
            }
            FileOutputStream fos = new FileOutputStream(file);
            byte[] decode = Base64.decode(base64, 0);
            fos.write(decode);
            fos.close();
        } catch (Exception e) {
            Log.e(TAG, e.getMessage());
        }
    }

    /*private static void copyFile(InputStream inputStream, OutputStream outputStream) throws IOException {
	 byte[] bArr = new byte[1024];
	 while (true) {
	 int read = inputStream.read(bArr);
	 if (read != -1) {
	 outputStream.write(bArr, 0, read);
	 } else {
	 return;
	 }
	 }
	 }*/
}






