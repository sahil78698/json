/*
 * Credit:
 *
 * Octowolve - Mod menu: https://github.com/z3r0Sec/Substrate-Template-With-Mod-Menu
 * And hooking: https://github.com/z3r0Sec/Substrate-Hooking-Example
 * VanHoevenTR A.K.A Nixi: https://github.com/LGLTeam/VanHoevenTR_Android_Mod_Menu
 * MrIkso - Mod menu: https://github.com/MrIkso/FloatingModMenu
 * Rprop - https://github.com/Rprop/And64InlineHook
 * MJx0 A.K.A Ruit - KittyMemory: https://github.com/MJx0/KittyMemory
 * */

package Game.Mod;

import android.annotation.TargetApi;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.app.AlertDialog;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.GradientDrawable;
import android.graphics.PixelFormat;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.SystemClock;
import android.os.Handler;
import android.graphics.Canvas;

import android.text.Html;
import android.text.InputFilter;
import android.text.InputType;
import android.text.method.DigitsKeyListener;
import android.util.Base64;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.graphics.Canvas;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;

import java.io.File;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;

import static Game.Mod.StaticActivity.cacheDir;
import android.net.ConnectivityManager;
import java.net.HttpURLConnection;
import java.io.BufferedReader;
import java.io.InputStream;
import java.net.URL;
import android.os.AsyncTask;
import android.annotation.SuppressLint;
import java.io.InputStreamReader;
import java.nio.file.ClosedFileSystemException;
import static android.view.ViewGroup.LayoutParams.WRAP_CONTENT;
import Game.Mod.BadLauncher.AnimationSetupCallback;
import Game.Mod.BadLauncher.Titanic;
import Game.Mod.BadLauncher.TitanicButton;
import Game.Mod.BadLauncher.TitanicTextView;

import android.content.res.AssetManager;
import static android.view.ViewGroup.LayoutParams.WRAP_CONTENT;
import static android.view.ViewGroup.LayoutParams.MATCH_PARENT;
import static android.widget.RelativeLayout.ALIGN_PARENT_RIGHT;

import android.graphics.drawable.Drawable;
import java.io.IOException;
public class LauncherActivity extends Service {
    private MediaPlayer FXPlayer;
    public View mFloatingView;
	public View mFloatingView1;
    private Button close;
    private Button kill,settings;
    private LinearLayout mButtonPanel;
    public RelativeLayout mCollapsed;
	public RelativeLayout mCollapsed1;
    public LinearLayout mExpanded;
    private RelativeLayout mRootContainer;
	private ImageView closeimage;
	private RelativeLayout mRootContainer1;
    public WindowManager mWindowManager;
	public WindowManager mWindowManager2;
    public WindowManager.LayoutParams params;
	public WindowManager.LayoutParams params2;
    private LinearLayout patches;
	private LinearLayout patches2;
	private LinearLayout patches3;
	private LinearLayout patches4;
	private LinearLayout patches5;
	private LinearLayout patches6;
	private LinearLayout patches7;
	private LinearLayout patches8;
    private FrameLayout rootFrame;
	private FrameLayout rootFrame1;
    private ImageView startimage;
    private LinearLayout view1;
    private LinearLayout view2;
    private boolean b;
	private ESPView overlayView;
	private WindowManager.LayoutParams espParams;
	private TextView textView;


    private AlertDialog alert;
    private EditText edittextvalue;

    private static final String TAG = "Mod Menu";

    //initialize methods from the native library
    public static native String Toast();

    private native String Icon();

    private native String Title();

    private native String Heading();

    private native boolean EnableSounds();

    private native int IconSize();

    public native void Changes(int feature, int value);

    private native String[] getFeatureListt();


    public String Color1() {
        return "#FFD600FF";
    }

    private String Color2() {
        return "#ff00b0ff";
    }

    private String Color3() {
        return "#FF131313";
    }


	private native String bapanhide();

    public static native void DrawOn(ESPView espView, Canvas canvas);

    private native String IconWebViewData();



    private int getLayoutType() {
        if (Build.VERSION.SDK_INT >= 26) {
            return 2038;
        }
        if (Build.VERSION.SDK_INT >= 24) {
            return 2002;
        }
        if (Build.VERSION.SDK_INT >= 23) {
            return 2005;
        }
        return 2003;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    //Override our Start Command so the Service doesnt try to recreate itself when the App is closed
    public int onStartCommand(Intent intent, int i, int i2) {
        return Service.START_NOT_STICKY;
    }

    //When this Class is called the code in this function will be executed
    @Override
    public void onCreate() {
		super.onCreate();
        Preferences.context = this;
        this.overlayView = new ESPView((Context)this);
        //A little message for the user when he opens the app
        //Toast.makeText(this, Toast(), Toast.LENGTH_LONG).show();
        //Init Lib

        // When you change the lib name, change also on Android.mk file
        // Both must have same name
        System.loadLibrary("hook");
        initFloating();
        initAlertDiag();
		//  startAnimation();
		DrawCanvas();

        final Handler handler = new Handler();
        handler.post(new Runnable() {
				public void run() {
					Thread();
					handler.postDelayed(this, 1000);
				}
			});
    }

	private void DrawCanvas() {
		
        WindowManager.LayoutParams layoutParams;
        this.espParams = layoutParams = new WindowManager.LayoutParams(
			WindowManager.LayoutParams.MATCH_PARENT,
			WindowManager.LayoutParams.MATCH_PARENT,
			this.getLayoutType(),
			WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL |
			WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
			PixelFormat.TRANSLUCENT);
        layoutParams.gravity = Gravity.TOP | Gravity.START;
        this.espParams.x = 0;
        this.espParams.y = 100;
        this.mWindowManager.addView((View)this.overlayView, (ViewGroup.LayoutParams)this.espParams);
    }





    private void initFloating() {
        rootFrame = new FrameLayout(getBaseContext());
		rootFrame1 = new FrameLayout(getBaseContext());
        mRootContainer = new RelativeLayout(getBaseContext()); // Markup on which two markups of the icon and the menu itself will be placed
        mCollapsed = new RelativeLayout(getBaseContext()); 
		mRootContainer1 = new RelativeLayout(getBaseContext()); // Markup on which two markups of the icon and the menu itself will be placed
        mCollapsed1 = new RelativeLayout(getBaseContext());
        mExpanded = new LinearLayout(getBaseContext()); // Menu markup (when the menu is expanded)
        view1 = new LinearLayout(getBaseContext());
        patches = new LinearLayout(getBaseContext());
		patches3 = new LinearLayout(getBaseContext());
		patches4 = new LinearLayout(getBaseContext());
		patches5 = new LinearLayout(getBaseContext());
		patches6 = new LinearLayout(getBaseContext());
		patches7 = new LinearLayout(getBaseContext());
		patches8 = new LinearLayout(getBaseContext());
		patches2 = new LinearLayout(getBaseContext());
        view2 = new LinearLayout(getBaseContext());
        mButtonPanel = new LinearLayout(getBaseContext()); // Layout of option buttons (when the menu is expanded)
		AssetManager assetManager = getAssets();
		
        RelativeLayout relativeLayout = new RelativeLayout(this);
        relativeLayout.setLayoutParams(new RelativeLayout.LayoutParams(-2, -1));
        relativeLayout.setPadding(3, 0, 3, 3);
        relativeLayout.setVerticalGravity(16);

        kill = new Button(this);
        kill.setBackgroundColor(Color.parseColor("#666666"));
        kill.setText("HIDE");
        kill.setTextColor(Color.parseColor("#FFFFFF"));

        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams.addRule(11);

        close = new Button(this);
        close.setBackgroundColor(Color.parseColor("#666666"));
        close.setText("CLOSE");
        close.setTextColor(Color.parseColor("#FFFFFF"));
        close.setLayoutParams(layoutParams);

		//  relativeLayout.addView(kill);
		// relativeLayout.addView(close);


        rootFrame.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
		rootFrame1.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        mRootContainer.setLayoutParams(new FrameLayout.LayoutParams(-2, -2));
        mCollapsed.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        mCollapsed.setVisibility(View.VISIBLE);
		mRootContainer1.setLayoutParams(new FrameLayout.LayoutParams(-2, -2));
        mCollapsed1.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        mCollapsed1.setVisibility(View.VISIBLE);
        startimage = new ImageView(getBaseContext());
        startimage.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));

        startimage.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        int applyDimension = (int) TypedValue.applyDimension(1, (float) IconSize(), getResources().getDisplayMetrics());
        startimage.getLayoutParams().height = applyDimension;
        startimage.getLayoutParams().width = applyDimension;
        startimage.requestLayout();
        startimage.setScaleType(ImageView.ScaleType.FIT_XY);
        byte[] decode = Base64.decode(Icon(), 0);
        startimage.setImageBitmap(BitmapFactory.decodeByteArray(decode, 0, decode.length));
        ((ViewGroup.MarginLayoutParams) startimage.getLayoutParams()).topMargin = convertDipToPixels(10);




        mExpanded.setVisibility(View.GONE);
        mExpanded.setBackgroundColor(Color.parseColor("#000000"));
        mExpanded.setGravity(17);
		mExpanded.setAlpha(0.70f);
        mExpanded.setOrientation(LinearLayout.VERTICAL);
        mExpanded.setPadding(0, 0, 0, 0);
        mExpanded.setLayoutParams(new LinearLayout.LayoutParams(dp(350), -2));
		mExpanded.setBackgroundColor(Color.parseColor("#000000"));
			

		LinearLayout option = new LinearLayout(this);
        option.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(230)));
        option.setPadding(0, 0, 0, 0);
        option.setOrientation(LinearLayout.HORIZONTAL);
        option.setGravity(17);
		

		LinearLayout outeroption = new LinearLayout(this);
        outeroption.setLayoutParams(new LinearLayout.LayoutParams(dp(130), dp(210)));
        outeroption.setPadding(0, 0, 0, 0);
        outeroption.setOrientation(LinearLayout.VERTICAL);
        outeroption.setGravity(17);
		

		final ScrollView scrollView = new ScrollView(getBaseContext());
        scrollView.setLayoutParams(new LinearLayout.LayoutParams(dp(130), dp(210)));


		LinearLayout outeroption2 = new LinearLayout(this);
        outeroption2.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(210)));
        outeroption2.setPadding(0, 0, 0, 0);
        outeroption2.setOrientation(LinearLayout.VERTICAL);
        outeroption2.setGravity(17);
		

		final   ScrollView scrollView1 = new ScrollView(getBaseContext());
        scrollView1.setLayoutParams(new LinearLayout.LayoutParams(-1,-1));

		final ScrollView scrollView2 = new ScrollView(getBaseContext());
        scrollView2.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));

		final ScrollView scrollView3 = new ScrollView(getBaseContext());
        scrollView3.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));

		final ScrollView scrollView4 = new ScrollView(getBaseContext());
        scrollView4.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));


        view1.setLayoutParams(new LinearLayout.LayoutParams(-1, 5));
        view1.setBackgroundColor(Color.parseColor("#666666"));
        patches.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        patches.setOrientation(LinearLayout.VERTICAL);
		patches2.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        patches2.setOrientation(LinearLayout.VERTICAL);
		patches3.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        patches3.setOrientation(LinearLayout.VERTICAL);
		patches4.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        patches4.setOrientation(LinearLayout.VERTICAL);
		patches5.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        patches5.setOrientation(LinearLayout.VERTICAL);
        view2.setLayoutParams(new LinearLayout.LayoutParams(-1, 5));
        view2.setBackgroundColor(Color.parseColor("#666666"));
        view2.setPadding(0, 0, 0, 10);
        mButtonPanel.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));

		ImageView BadLogo = new ImageView(this);
        RelativeLayout.LayoutParams BadLogo_LayoutParams = new RelativeLayout.LayoutParams(-0, -2);
        BadLogo.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        BadLogo_LayoutParams.addRule(ALIGN_PARENT_RIGHT);
        BadLogo_LayoutParams.setMarginEnd((int) ((0.0f) + 0.0f));
        BadLogo.getLayoutParams().height = dp(50);
        BadLogo.getLayoutParams().width = dp(50);
        BadLogo.requestLayout();
        InputStream inputStream_icone = null;
        try {
            inputStream_icone = assetManager.open("icon.png");
        } catch (IOException e) {
            e.printStackTrace();
        }
        Drawable icone = Drawable.createFromStream(inputStream_icone, null);
        BadLogo.setImageDrawable(icone);
        ((ViewGroup.MarginLayoutParams) 
			BadLogo.getLayoutParams()).leftMargin = convertDipToPixels(0);

        //Title text
        TitanicTextView textView = new TitanicTextView(this);
        textView.setText(Title());
        textView.setText(Html.fromHtml("<font face='roboto'>ModMenu By<font color='WHITE'><font color='YELLOW'><font color='RED'></font>"));
        textView.setTextColor(Color.parseColor("#FFFF9800"));
        textView.setTypeface(Typeface.DEFAULT_BOLD);
        textView.setTextSize(0.0f);
       
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-2, -2);
        new Titanic().start(textView);

		RelativeLayout titleText = new RelativeLayout(this);
		TitanicTextView textView2 = new TitanicTextView(this);
	    textView2.setText(Html.fromHtml("<font face='serif'>Mod Menu Ghinhara Ryuuka</font>"));
        textView2.setTextColor(Color .WHITE);
        textView2.setTextSize(20.0f);
        textView2.setGravity(17);
        textView2.setPadding(0, 0, 0, 0);
        textView2.setGravity(Gravity.CENTER);
		new Titanic().start(textView2);
		
        LinearLayout.LayoutParams layoutParamsF = new LinearLayout.LayoutParams(-1, -2);
        layoutParamsF.gravity = 17;
		textView.setLayoutParams(layoutParamsF);
        RelativeLayout.LayoutParams layoutParamsA = new RelativeLayout.LayoutParams(dp(25), dp(25));
        layoutParamsA.addRule(11);

        settings = new Button(this);
		settings.setLayoutParams(layoutParams);
        settings.setBackgroundColor(Color.parseColor("Red"));
		settings.setTextColor(-1);
        settings.setTextSize(8.0f);
        settings.setGravity(17);
        settings.setLayoutParams(layoutParamsA);
       
		final TitanicButton CATEGORY = new TitanicButton(this);
        final LinearLayout.LayoutParams CATE1 = new LinearLayout.LayoutParams(-1, -1);

        CATEGORY.setLayoutParams(CATE1);
        CATEGORY.setPadding(30, 5, 30, 5);
        CATEGORY.setTextSize(12.0f);
        CATEGORY.setTextColor(Color.parseColor("#FFFFFF"));
		//CATEGORY.setShadowLayer((float)5, (float)5, (float)5, Color.RED);
        CATEGORY.setGravity(17);
		CATEGORY.setTypeface(Typeface.SERIF);
        CATEGORY.setText("MENU AIM");
		//   CATEGORY.setBackgroundColor(Color.parseColor("#000000"));
		final  GradientDrawable CATE2 = new GradientDrawable();
		CATE2.setShape(GradientDrawable.RECTANGLE);
		CATE1.setMargins(5, 5, 5, 5);
		CATE2.setGradientType(GradientDrawable.LINEAR_GRADIENT);
		CATE2.setStroke(3, (Color.parseColor("#FF0000")));
		//CATE2.setColor(Color.parseColor("#000000"));
		CATEGORY.setBackground(CATE2);
		new Titanic().start(CATEGORY);

		final TitanicButton ESP = new TitanicButton(this);
		final    LinearLayout.LayoutParams E = new LinearLayout.LayoutParams(-1, -1);
        E.setMargins(5, 5, 5, 5);
        ESP.setLayoutParams(E);
        ESP.setPadding(30, 5, 30, 5);
        ESP.setTextSize(12.0f);
        ESP.setTextColor(Color.parseColor("#FFFFFF"));
		//ESP.setShadowLayer((float)5, (float)5, (float)5, Color.BLUE);
        ESP.setGravity(17);
		ESP.setTypeface(Typeface.SERIF);
        ESP.setText("MENU ESP");
		//  ESP.setBackgroundColor(Color.parseColor("#000000"));
		final	GradientDrawable E1 = new GradientDrawable();
		E1.setShape(GradientDrawable.RECTANGLE);

		E1.setGradientType(GradientDrawable.LINEAR_GRADIENT);
		E1.setStroke(3, (Color.parseColor("#FF0000")));
		//E1.setColor(Color.parseColor("#000000"));
		ESP.setBackground(E1);
		new Titanic().start(ESP);

		final TitanicButton ALERTA = new TitanicButton(this);
		final    LinearLayout.LayoutParams ALERT2 = new LinearLayout.LayoutParams(-1, -1);
        ALERT2.setMargins(5, 5, 5, 5);
        ALERTA.setLayoutParams(ALERT2);
        ALERTA.setPadding(30, 5, 30, 5);
        ALERTA.setTextSize(12.0f);
        ALERTA.setTextColor(Color.parseColor("#FFFFFF"));
		//ALERTA.setShadowLayer((float)5, (float)5, (float)5, Color.GREEN);
        ALERTA.setGravity(17);
		ALERTA.setTypeface(Typeface.SERIF);
        ALERTA.setText("MENU Other");
		//  ALERTA.setBackgroundColor(Color.parseColor("#000000"));
		final	GradientDrawable ALERT1 = new GradientDrawable();
		ALERT1.setShape(GradientDrawable.RECTANGLE);

		ALERT1.setGradientType(GradientDrawable.LINEAR_GRADIENT);
		ALERT1.setStroke(3, (Color.parseColor("#FF0000")));
		//ALERT1.setColor(Color.parseColor("#000000"));
		ALERTA.setBackground(ALERT1);
		new Titanic().start(ALERTA);
		
		final TitanicButton TELEKILL = new TitanicButton(this);
		final    LinearLayout.LayoutParams TELEKILL2 = new LinearLayout.LayoutParams(-1, -1);
        TELEKILL2.setMargins(5, 5, 5, 5);
        TELEKILL.setLayoutParams(TELEKILL2);
        TELEKILL.setPadding(30, 5, 30, 5);
        TELEKILL.setTextSize(12.0f);
        TELEKILL.setTextColor(Color.parseColor("#FFFFFF"));
		//TELEKILL.setShadowLayer((float)5, (float)5, (float)5, Color.YELLOW);
        TELEKILL.setGravity(17);
		TELEKILL.setTypeface(Typeface.SERIF);
        TELEKILL.setText("MENU EXTRA");
		//  TELEKILL.setBackgroundColor(Color.parseColor("#000000"));
		final	GradientDrawable TELEKILL1 = new GradientDrawable();
		TELEKILL1.setShape(GradientDrawable.RECTANGLE);
		TELEKILL1.setGradientType(GradientDrawable.LINEAR_GRADIENT);
		TELEKILL1.setStroke(3, (Color.parseColor("#FF0000")));
		//TELEKILL1.setColor(Color.parseColor("#000000"));
		TELEKILL.setBackground(TELEKILL1);
		new Titanic().start(TELEKILL);



		CATEGORY.setOnClickListener(new View.OnClickListener() 
			{
				public void onClick(View v){
					//CATEGORY.setBackgroundColor(Color.parseColor("#000000"));
					final	GradientDrawable CATE2 = new GradientDrawable();
					CATE2.setShape(GradientDrawable.RECTANGLE);

					CATE2.setGradientType(GradientDrawable.LINEAR_GRADIENT);
					CATE2.setStroke(3, (Color.parseColor("#FF0000")));
					//CATE2.setColor(Color.parseColor("#000000"));
					CATEGORY.setBackground(CATE2); 
					scrollView2.setVisibility(View.GONE);
					scrollView1.setVisibility(View.VISIBLE);

				}				    
			});

		patches2.addView(CATEGORY);



		ESP.setOnClickListener(new View.OnClickListener() 
			{
				public void onClick(View v){
					//ESP.setBackgroundColor(Color.parseColor("#000000"));
					final		GradientDrawable E2 = new GradientDrawable();
					E2.setShape(GradientDrawable.RECTANGLE);

					E2.setGradientType(GradientDrawable.LINEAR_GRADIENT);
					E2.setStroke(3, (Color.parseColor("#FF0000")));
					//E2.setColor(Color.parseColor("#000000"));
					ESP.setBackground(E2); 
					scrollView1.setVisibility(View.GONE);
					scrollView2.setVisibility(View.VISIBLE);
				}				    
			});

		patches2.addView(ESP);


		ALERTA.setOnClickListener(new View.OnClickListener() 
			{
				public void onClick(View v){
					//ALERTA.setBackgroundColor(Color.parseColor("#000000"));
					final		GradientDrawable ALERT1 = new GradientDrawable();
					ALERT1.setShape(GradientDrawable.RECTANGLE);

					ALERT1.setGradientType(GradientDrawable.LINEAR_GRADIENT);
					ALERT1.setStroke(3, (Color.parseColor("#FF0000")));
					//ALERT1.setColor(Color.parseColor("#000000"));
					ALERTA.setBackground(ALERT1); 
					scrollView1.setVisibility(View.GONE);
					scrollView2.setVisibility(View.GONE);
					scrollView3.setVisibility(View.VISIBLE);
				}				    
			});

		patches2.addView(ALERTA);


		TELEKILL.setOnClickListener(new View.OnClickListener() 
			{
				public void onClick(View v){
					//TELEKILL.setBackgroundColor(Color.parseColor("#000000"));
					final		GradientDrawable TELEKILL1 = new GradientDrawable();
					TELEKILL1.setShape(GradientDrawable.RECTANGLE);

					TELEKILL1.setGradientType(GradientDrawable.LINEAR_GRADIENT);
					TELEKILL1.setStroke(3, (Color.parseColor("#FF0000")));
					//	TELEKILL1.setColor(Color.parseColor("#000000"));
					TELEKILL.setBackground(TELEKILL1);
					scrollView1.setVisibility(View.GONE);
					scrollView2.setVisibility(View.GONE);
					scrollView3.setVisibility(View.GONE);
					scrollView4.setVisibility(View.VISIBLE);
				}				    
			});

		patches2.addView(TELEKILL);




        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams3.gravity = 17;
        textView.setLayoutParams(layoutParams2);
        textView2.setLayoutParams(layoutParams3);
        new LinearLayout.LayoutParams(-1, dp(25)).topMargin = dp(2);
        rootFrame.addView(mRootContainer);



        mRootContainer.addView(mCollapsed);
        mRootContainer.addView(mExpanded);

        mCollapsed.addView(BadLogo);
		mExpanded.addView(titleText);
		titleText.addView(textView2);
        titleText.addView(settings);    
        mExpanded.addView(option);
        option.addView(outeroption);
		option.addView(outeroption2);
		outeroption.addView(scrollView);
		outeroption2.addView(scrollView1);
		outeroption2.addView(scrollView2);
		outeroption2.addView(scrollView3);
		outeroption2.addView(scrollView4);
		scrollView2.addView(patches3);
		scrollView4.addView(patches5);
		scrollView1.addView(patches);
		scrollView3.addView(patches4);
		scrollView.addView(patches2);
		//   mExpanded.addView(view2);
        mExpanded.addView(relativeLayout);
        mFloatingView = rootFrame;

        if (Build.VERSION.SDK_INT >= 26) {
            params = new WindowManager.LayoutParams(-2, -2, 2038, 8, -3);
        } else {
            params = new WindowManager.LayoutParams(-2, -2, 2002, 8, -3);
        }
        WindowManager.LayoutParams layoutParams4 = params;
        layoutParams4.gravity = 51;
        layoutParams4.x = 20;
        layoutParams4.y = 20;
        mWindowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        mWindowManager.addView(mFloatingView, params);

		if (Build.VERSION.SDK_INT >= 26) {
            params2 = new WindowManager.LayoutParams(-2, -2, 2038, 8, -3);
        } else {
            params2 = new WindowManager.LayoutParams(-2, -2, 2002, 8, -3);
        }
        WindowManager.LayoutParams layoutParamss = params2;
        layoutParamss.gravity = 51;
        layoutParamss.x = 60;
        layoutParamss.y = 60;
		//   mWindowManager2 = (WindowManager) getSystemService(Context.WINDOW_SERVICE);

		//mWindowManager2.addView(mRootContainer1, params2);

        RelativeLayout relativeLayout2 = mCollapsed;
        LinearLayout linearLayout = mExpanded;
        mFloatingView.setOnTouchListener(onTouchListener());

        startimage.setOnTouchListener(onTouchListener());
        initMenuButton(relativeLayout2, linearLayout);
        CreateMenuList();
    }





    private View.OnTouchListener onTouchListener() {
        return new View.OnTouchListener() {
            final View collapsedView = mCollapsed;
            final View expandedView = mExpanded;
            private float initialTouchX;
            private float initialTouchY;
            private int initialX;
            private int initialY;

            public boolean onTouch(View view, MotionEvent motionEvent) {
                switch (motionEvent.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = motionEvent.getRawX();
                        initialTouchY = motionEvent.getRawY();
                        return true;
                    case MotionEvent.ACTION_UP:
                        int rawX = (int) (motionEvent.getRawX() - initialTouchX);
                        int rawY = (int) (motionEvent.getRawY() - initialTouchY);

                        //The check for Xdiff <10 && YDiff< 10 because sometime elements moves a little while clicking.
                        //So that is click event.
                        if (rawX < 10 && rawY < 10 && isViewCollapsed()) {
                            //When user clicks on the image view of the collapsed layout,
                            //visibility of the collapsed layout will be changed to "View.GONE"
                            //and expanded view will become visible.
                            collapsedView.setVisibility(View.GONE);
                            expandedView.setVisibility(View.VISIBLE);
                            Toast.makeText(LauncherActivity.this, Html.fromHtml(Toast()), Toast.LENGTH_SHORT).show();
                        }
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        //Calculate the X and Y coordinates of the view.
						params.x = initialX + ((int) (motionEvent.getRawX() - initialTouchX));
                        params.y = initialY + ((int) (motionEvent.getRawY() - initialTouchY));
                        //Update the layout with new X & Y coordinate
                        mWindowManager.updateViewLayout(mFloatingView, params);
                        return true;
                    default:
                        return false;
                }
            }
        };
    }

    //Initialize event handlers for buttons, etc.
    private void initMenuButton(final View view2, final View view3) {
        startimage.setOnClickListener(new View.OnClickListener() {
				public void onClick(View view) {
					view2.setVisibility(View.GONE);
					view3.setVisibility(View.VISIBLE);
				}
			});
		/*   closeimage.setOnClickListener(new View.OnClickListener() {
		 public void onClick(View view) {
		 //FloatingModMenuService.stopSelf();
		 // view2.setVisibility(View.VISIBLE)
		 view2.setVisibility(View.VISIBLE);
		 view2.setAlpha(0);
		 view3.setVisibility(View.GONE);
		 }
		 });*/
        settings.setOnClickListener(new View.OnClickListener() {
				public void onClick(View view) {
					view2.setVisibility(View.VISIBLE);
					view2.setAlpha(0.95f);
					view3.setVisibility(View.GONE);
					//Log.i("LGL", "Close");
				}
			});
    }

    public final void CreateMenuList() {
        String[] listFT = getFeatureListt();
        for (int i = 0; i < listFT.length; i++) {
            final int feature = i;
            String str = listFT[i];
			if (str.contains("TG_")) {
			    addCheckBoxAIM(str.replace("TG_", ""), new InterfaceBool() {
						public void OnWrite(boolean z) {
							Changes(feature, 0);
						}
					});
			
				//CATEGORY ESP\\
			} else if (str.contains("TG2_")) {
			    addCheckBoxAIM2(str.replace("TG2_", ""), new InterfaceBool() {
						public void OnWrite(boolean z) {
							Changes(feature, 0);
						}
					});
				
			} else if (str.contains("TG3_")) {
			    addCheckBoxAIM3(str.replace("TG3_", ""), new InterfaceBool() {
						public void OnWrite(boolean z) {
							Changes(feature, 0);
						}
					});
				
            } else if (str.contains("TG4_")) {
			    addCheckBoxAIM4(str.replace("TG4_", ""), new InterfaceBool() {
						public void OnWrite(boolean z) {
							Changes(feature, 0);
						}
					});
				
            } else if (str.contains("SeekBarccc2__")) {
                String[] split = str.split("_");
                addESPSeekBarSpot(split[1], Integer.parseInt(split[2]), Integer.parseInt(split[3]), new InterfaceInt() {
						public void OnWrite(int i) {
							Changes(feature, i);
						}
					});
				//CATEGORY AIMBOT\\
			
            } else if (str.contains("SeekBar_")) {
                String[] split = str.split("_");
                addSeekBar(split[1], Integer.parseInt(split[2]), Integer.parseInt(split[3]), new InterfaceInt() {
						public void OnWrite(int i) {
							Changes(feature, i);
						}
					});
			} else if (str.contains("SeekBar2_")) {
                String[] split = str.split("_");
                addESPSeekBar(split[1], Integer.parseInt(split[2]), Integer.parseInt(split[3]), new InterfaceInt() {
						public void OnWrite(int i) {
							Changes(feature, i);
						}
					});
			} else if (str.contains("SeekBar4_")) {
                String[] split = str.split("_");
                addEXTRASeekBar(split[1], Integer.parseInt(split[2]), Integer.parseInt(split[3]), new InterfaceInt() {
						public void OnWrite(int i) {
							Changes(feature, i);
						}
					});
            } else if (str.contains("button2_")) {
                addButton2(str.replace("button2_", ""), new InterfaceBtn() {
                        public void OnWrite() {
                            Changes(feature, 0);
                        }
                    });

            } else if (str.contains("SeekBarSpot_")) {
                String[] split = str.split("_");
                addSeekBarSpot(split[1], Integer.parseInt(split[2]), Integer.parseInt(split[3]), new InterfaceInt() {
						public void OnWrite(int i) {
							Changes(feature, i);
						}
					});


            }  
        }
    }

    private TextView textView2;
    private String featureNameExt;
    private int featureNum;
    private EditTextValue txtValue;

    public class EditTextValue {
        private int val;

        public void setValue(int i) {
            val = i;
        }

        public int getValue() {
            return val;
        }
    }

    private void addTextField(final String featureName, final int feature, final InterfaceInt interInt) {
        RelativeLayout relativeLayout2 = new RelativeLayout(this);
        relativeLayout2.setLayoutParams(new RelativeLayout.LayoutParams(-2, -1));
        relativeLayout2.setPadding(10, 5, 10, 0);
        relativeLayout2.setVerticalGravity(16);

        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams.topMargin = 10;

        final TextView textView = new TextView(this);
        textView.setText(Html.fromHtml("<font face='roboto'>" + featureName + ": <font color='#fdd835'>Not set</font></font>"));
        textView.setTextColor(Color.parseColor("#DEEDF6"));
        textView.setLayoutParams(layoutParams);

        final TitanicTextView textViewRem = new TitanicTextView(this);
        textViewRem.setText("");

        final EditTextValue edittextval = new EditTextValue();

        RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams2.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);

        Button button2 = new Button(this);
        button2.setLayoutParams(layoutParams2);
        button2.setBackgroundColor(Color.parseColor("#1C262D"));
        button2.setText("SET");
        button2.setTextColor(Color.parseColor("#D5E3EB"));
        button2.setGravity(17);
        button2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    alert.show();
                    textView2 = textView;
                    featureNum = feature;
                    featureNameExt = featureName;
                    txtValue = edittextval;

                    edittextvalue.setText(String.valueOf(edittextval.getValue()));
                }
            });

        relativeLayout2.addView(textView);
        relativeLayout2.addView(button2);
        patches.addView(relativeLayout2);
    }

    private void initAlertDiag() {
        LinearLayout linearLayout1 = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        linearLayout1.setPadding(10, 5, 0, 0);
        linearLayout1.setOrientation(LinearLayout.VERTICAL);
        linearLayout1.setGravity(17);
        linearLayout1.setLayoutParams(layoutParams);
        linearLayout1.setBackgroundColor(Color.parseColor("#171E24"));

        int i = Build.VERSION.SDK_INT >= 26 ? 2038 : 2002;
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        linearLayout.setBackgroundColor(Color.parseColor("#14171f"));
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        FrameLayout frameLayout = new FrameLayout(this);
        frameLayout.setLayoutParams(new FrameLayout.LayoutParams(-2, -2));
        frameLayout.addView(linearLayout);

        final TextView textView = new TextView(this);
        textView.setText(Html.fromHtml("<font face='roboto'>Tap OK to apply changes. Tap outside to cancel</font>"));
        textView.setTextColor(Color.parseColor("#DEEDF6"));
        textView.setLayoutParams(layoutParams);

        edittextvalue = new EditText(this);
        edittextvalue.setLayoutParams(layoutParams);
        edittextvalue.setMaxLines(1);
        edittextvalue.setWidth(convertDipToPixels(300));
        edittextvalue.setTextColor(Color.parseColor("#93a6ae"));
        edittextvalue.setTextSize(13.0f);
        edittextvalue.setHintTextColor(Color.parseColor("#434d52"));
        edittextvalue.setInputType(InputType.TYPE_CLASS_NUMBER);
        edittextvalue.setKeyListener(DigitsKeyListener.getInstance("0123456789-"));

        InputFilter[] FilterArray = new InputFilter[1];
        FilterArray[0] = new InputFilter.LengthFilter(10);
        edittextvalue.setFilters(FilterArray);

        Button button = new Button(this);
        button.setBackgroundColor(Color.parseColor("#1C262D"));
        button.setTextColor(Color.parseColor("#D5E3EB"));
        button.setText("OK");
        button.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					Changes(featureNum, Integer.parseInt(edittextvalue.getText().toString()));
					txtValue.setValue(Integer.parseInt(edittextvalue.getText().toString()));
					textView2.setText(Html.fromHtml("<font face='roboto'>" + featureNameExt + ": <font color='#41c300'>" + edittextvalue.getText().toString() + "</font></font>"));
					alert.dismiss();

					//interStr.OnWrite(editText.getText().toString());
				}
			});

        alert = new AlertDialog.Builder(this, 2).create();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            Objects.requireNonNull(alert.getWindow()).setType(i);
        }
        linearLayout1.addView(textView);
        linearLayout1.addView(edittextvalue);
        linearLayout1.addView(button);
        alert.setView(linearLayout1);
    }
    public void addButton2(String feature, final InterfaceBtn interfaceBtn) {
        final GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setShape(GradientDrawable.RECTANGLE);
        String str2 = "#ff00d1ff";
        gradientDrawable.setColor(Color.parseColor(str2));
        gradientDrawable.setStroke(3, Color.parseColor(str2));
        gradientDrawable.setCornerRadius(10.0f);
        final GradientDrawable gradientDrawable2 = new GradientDrawable();
        gradientDrawable2.setShape(GradientDrawable.RECTANGLE);
        gradientDrawable2.setColor(0);
        gradientDrawable2.setStroke(3, Color.parseColor(str2));
        gradientDrawable2.setCornerRadius(10.0f);

        final Button button = new Button(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.setMargins(9, 7, 9, 7);
        button.setText(feature + " ");
        button.setTextColor(Color.WHITE);
        button.setTextSize(12.0f);
        button.setAllCaps(false);
        android.graphics.drawable.GradientDrawable JBHGEHF = new android.graphics.drawable.GradientDrawable();
        int JBHGEHFADD[] = new int[]{ Color.parseColor("#FF000000"), Color.parseColor("#FF000000") };
        JBHGEHF.setColors(JBHGEHFADD);
        JBHGEHF.setOrientation(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT);
        JBHGEHF.setCornerRadii(new float[] { 8, 8, 8, 8, 8, 8, 8, 8 });
        JBHGEHF.setStroke(3, Color.parseColor("#FF00E5FF"));
        android.graphics.drawable.RippleDrawable JBHGEHF_RE = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{ Color.parseColor("#FFFFFFFF")}), JBHGEHF, null);
        button.setBackground(JBHGEHF_RE);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, dp(40));
        button.setPadding(3, 3, 3, 3);
        layoutParams2.bottomMargin = 15;
        button.setLayoutParams(layoutParams2);
        final String feature2 = feature;
        button.setOnClickListener(new View.OnClickListener() {
                private boolean isActive = true;

                public void onClick(View v) {
                    interfaceBtn.OnWrite();
                    if (isActive) {

                        button.setText(feature2 + " ");
                        android.graphics.drawable.GradientDrawable JBHGEHF = new android.graphics.drawable.GradientDrawable();
                        int JBHGEHFADD[] = new int[]{ Color.parseColor("#FF000000"), Color.parseColor("#FF000000") };
                        JBHGEHF.setColors(JBHGEHFADD);
                        JBHGEHF.setOrientation(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT);
                        JBHGEHF.setCornerRadii(new float[] { 8, 8, 8, 8, 8, 8, 8, 8 });
                        JBHGEHF.setStroke(3, Color.parseColor("#FF0000"));
                        android.graphics.drawable.RippleDrawable JBHGEHF_RE = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{ Color.parseColor("#FFFFFFFF")}), JBHGEHF, null);
                        button.setBackground(JBHGEHF_RE);
                        button.setVisibility(button.INVISIBLE);
                        button.setAlpha(0);
                        button.setVisibility(button.GONE);
                        isActive = false;
                    }
                }
            });
        patches.addView(button);
    }




	public void addESPButton(String feature, final InterfaceBtn interfaceBtn) {
        final Button button = new Button(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        button.setPadding(10, 5, 10, 5);
        button.setLayoutParams(layoutParams);

        button.setTextSize(13.0f);
        button.setBackgroundColor(Color.parseColor("#FFD600FF"));
        button.setTextColor(-1);
        button.setGravity(17);
        GradientDrawable gradienteOff = new GradientDrawable();
        gradienteOff.setColor(Color.parseColor(Color3()));
        gradienteOff.setCornerRadii(new float[]{(float) dp(5), (float) dp(5), (float) dp(5), (float) dp(5), (float) dp(5), (float) dp(5), (float) dp(5), (float) dp(5)});
        gradienteOff.setStroke(dp(2), Color.parseColor(Color1()));
        if (Build.VERSION.SDK_INT >= 21) {
            button.setElevation(100.0f);
        }
        final GradientDrawable gradientDrawable = gradienteOff;
        button.setBackground(gradienteOff);
        button.setTypeface((Typeface) null, 1);
        if (feature.contains("")) {
            feature = feature.replace("OnOff_", "");
            button.setText(feature + " OFF");
            //  button.setBackgroundColor(Color.parseColor("#7f0000"));
            final String feature2 = feature;

            button.setOnClickListener(new View.OnClickListener() {
                    private boolean isActive = true;

                    public void onClick(View v) {
                        interfaceBtn.OnWrite();
                        if (isActive) {
                            //    playSound(Uri.fromFile(new File(cacheDir + "On.ogg")));
                            button.setText(feature2 + " ON");
                            //button.setBackgroundColor(Color.parseColor("#003300"));
                            isActive = false;
                            GradientDrawable gradienteOn = new GradientDrawable();
                            gradienteOn.setColor(Color.parseColor(Color1()));
                            gradienteOn.setCornerRadii(new float[]{(float) dp(5), (float) dp(5), (float) dp(5), (float) dp(5), (float) dp(5), (float) dp(5), (float) dp(5), (float) dp(5)});
                            gradienteOn.setStroke(dp(2), Color.parseColor(Color1()));
                            if (Build.VERSION.SDK_INT >= 21) {
                                button.setElevation(100.0f);
                            }
                            button.setBackground(gradienteOn);
                            return;
                        }
                        //   playSound(Uri.fromFile(new File(cacheDir + "Off.ogg")));
                        button.setText(feature2 + " OFF");
                        // button.setBackgroundColor(Color.parseColor("#7f0000"));
                        isActive = true;
                        button.setBackground(gradientDrawable);
                    }
                });
        } else {
            button.setText(feature);

            final String feature2 = feature;
            button.setBackground(gradientDrawable);
            button.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        interfaceBtn.OnWrite();

                    }
                });
        }
        patches3.addView(button);
    }


    private void addCheckBoxAIM(String str, final InterfaceBool sw) {//______ESP
        final CheckBox Check = new CheckBox(this);
        Check.setText(Html.fromHtml("<font face='roboto'>" + str + "</font>"));
        Check.setTextColor(Color.parseColor("WHITE"));
		//Check.setShadowLayer(5,0,0, Color.RED);
        Check.setTypeface(null, Typeface.BOLD);
        Check.setTextSize(14.0f);
        Check.setButtonTintList(ColorStateList.valueOf(Color.parseColor("#ffffff")));
        Check.setTextColor(-1);
        Check.setPadding(20, 10, 20, 10);

        Check.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                    if (z) {
                        Check.setBackgroundColor(Color.parseColor("#00000000")); 
						Check.setShadowLayer(5,0,0, Color.parseColor("#00000000")); 
                    } else {
                        Check.setBackgroundColor(Color.parseColor("#00000000"));
						// Check.setShadowLayer(5,0,0, Color.RED);
                    }
                    if (z) {
					} else {
					}
					sw.OnWrite(z);
				}
			});
		patches.addView(Check);
    }



	
	private void addCheckBoxAIM2(String str, final InterfaceBool sw) {
        final CheckBox Check = new CheckBox(this);
        Check.setText(Html.fromHtml("<font face='serif'>" + str + "</font>"));
        Check.setTextSize(15);
        Check.setTextColor(Color.parseColor("WHITE"));
        Check.setTextSize(13.0f);
		//Check.setShadowLayer((float)25, (float)0, (float)0, Color.BLUE);
		Check.getButtonDrawable().setColorFilter(Color.parseColor("WHITE"), PorterDuff.Mode.SRC_IN);
        Check.getBackground().setAlpha(150);
        Check.setPadding(30, 5, 0, 5);
        //Check.setPadding(20, 20, 20, 20);
        Check.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
				public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
					if (z) {
						//    playSound(Uri.fromFile(new File(cacheDir + "On.ogg")));
						Check.setTextColor(Color.parseColor("WHITE"));
						//Check.setShadowLayer((float)25, (float)0, (float)0, Color.WHITE);

					} else {
						//   playSound(Uri.fromFile(new File(cacheDir + "Off.ogg")));
						Check.setTextColor(Color.parseColor("WHITE"));
				//		Check.setShadowLayer((float)40, (float)0, (float)0, Color.BLUE);

					}
					sw.OnWrite(z);
				}
			});
        patches3.addView(Check);
    }

	private void addCheckBoxAIM4(String str, final InterfaceBool sw) {
        final CheckBox Check = new CheckBox(this);
        Check.setText(Html.fromHtml("<font face='serif'>" + str + "</font>"));
        Check.setTextSize(15);
        Check.setTextColor(Color.parseColor("WHITE"));
        Check.setTextSize(13.0f);
		//Check.setShadowLayer((float)25, (float)0, (float)0, Color.BLUE);
		Check.getButtonDrawable().setColorFilter(Color.parseColor("WHITE"), PorterDuff.Mode.SRC_IN);
        Check.getBackground().setAlpha(150);
        Check.setPadding(30, 5, 0, 5);
        //Check.setPadding(20, 20, 20, 20);
        Check.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
				public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
					if (z) {
						//    playSound(Uri.fromFile(new File(cacheDir + "On.ogg")));
						Check.setTextColor(Color.parseColor("WHITE"));
						//Check.setShadowLayer((float)25, (float)0, (float)0, Color.WHITE);

					} else {
						//   playSound(Uri.fromFile(new File(cacheDir + "Off.ogg")));
						Check.setTextColor(Color.parseColor("WHITE"));
						//Check.setShadowLayer((float)40, (float)0, (float)0, Color.BLUE);

					}
					sw.OnWrite(z);
				}
			});
        patches5.addView(Check);
    }

	private void addCheckBoxAIM3(String str, final InterfaceBool sw) {
        final CheckBox Check = new CheckBox(this);
        Check.setText(Html.fromHtml("<font face='serif'>" + str + "</font>"));
        Check.setTextSize(15);
        Check.setTextColor(Color.parseColor("WHITE"));
        Check.setTextSize(13.0f);
		//Check.setShadowLayer((float)25, (float)0, (float)0, Color.BLUE);
		Check.getButtonDrawable().setColorFilter(Color.parseColor("WHITE"), PorterDuff.Mode.SRC_IN);
        Check.getBackground().setAlpha(150);
        Check.setPadding(30, 5, 0, 5);
        //Check.setPadding(20, 20, 20, 20);
        Check.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
				public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
					if (z) {
						//    playSound(Uri.fromFile(new File(cacheDir + "On.ogg")));
						Check.setTextColor(Color.parseColor("WHITE"));
						//Check.setShadowLayer((float)25, (float)0, (float)0, Color.WHITE);

					} else {
						//   playSound(Uri.fromFile(new File(cacheDir + "Off.ogg")));
						Check.setTextColor(Color.parseColor("WHITE"));
						//Check.setShadowLayer((float)40, (float)0, (float)0, Color.BLUE);

					}
					sw.OnWrite(z);
				}
			});
        patches4.addView(Check);
    }



    private void addSeekBar(final String feature, final int prog, int max, final InterfaceInt interInt) {
        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        linearLayout.setPadding(10, 5, 0, 5);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.setGravity(17);
		linearLayout.setBackgroundColor(Color.parseColor("#000000"));
		linearLayout.getBackground().setAlpha(0);
        linearLayout.setLayoutParams(layoutParams);
        final TextView textView = new TextView(this);
		//textView.setShadowLayer((float)25, (float)0, (float)0, Color.BLUE);
        textView.setText(Html.fromHtml("<font face='serif'><b>" + feature + ": <font color='BLUE'>" + "OFF" + "</font>"));
        textView.setTextColor(Color.parseColor("#FFFFFF"));
		textView.setTextSize(12);
        SeekBar seekBar = new SeekBar(this);
        seekBar.setPadding(25, 10, 35, 10);
        seekBar.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        seekBar.setMax(max);
        seekBar.setProgress(prog);
		seekBar.getProgressDrawable().setColorFilter(Color.parseColor("WHITE"), PorterDuff.Mode.MULTIPLY);
        seekBar.getThumb().setColorFilter(Color.parseColor("WHITE"), PorterDuff.Mode.SRC_IN);
        final TextView textView2 = textView;
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
				public void onStartTrackingTouch(SeekBar seekBar) {
				}

				public void onStopTrackingTouch(SeekBar seekBar) {
				}

				int l;

				public void onProgressChanged(SeekBar seekBar, int i, boolean z) {


					if (i == 0) {
						seekBar.setProgress(i);
						interInt.OnWrite(i);
						TextView textView = textView2;
						textView.setText(Html.fromHtml("<font face='serif'><b>" + feature + ": <font color='BLUE'>" + "OFF" + "</font>"));
						return;
					}
					interInt.OnWrite(i);
					textView.setText(Html.fromHtml("<font face='serif'><b>" + feature + ": <font color='BLUE'>" + i + "</font>"));
				}
			});

        linearLayout.addView(textView);
        linearLayout.addView(seekBar);
        patches.addView(linearLayout);
    }

	
	private void addBANSeekBar(final String feature, final int prog, int max, final InterfaceInt interInt) {
		LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        linearLayout.setPadding(10, 5, 0, 5);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.setGravity(17);
		linearLayout.setBackgroundColor(Color.parseColor("#000000"));
		linearLayout.getBackground().setAlpha(0);
        linearLayout.setLayoutParams(layoutParams);
        final TextView textView = new TextView(this);
		textView.setShadowLayer((float)25, (float)0, (float)0, Color.BLUE);
        textView.setText(Html.fromHtml("<font face='serif'><b>" + feature + ": <font color='BLUE'>" + "OFF" + "</font>"));
        textView.setTextColor(Color.parseColor("#FFFFFF"));
		textView.setTextSize(12);
        SeekBar seekBar = new SeekBar(this);
        seekBar.setPadding(25, 10, 35, 10);
        seekBar.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        seekBar.setMax(max);
        seekBar.setProgress(prog);
		seekBar.getProgressDrawable().setColorFilter(Color.parseColor("WHITE"), PorterDuff.Mode.MULTIPLY);
        seekBar.getThumb().setColorFilter(Color.parseColor("WHITE"), PorterDuff.Mode.SRC_IN);
        final TextView textView2 = textView;
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
				public void onStartTrackingTouch(SeekBar seekBar) {
				}

				public void onStopTrackingTouch(SeekBar seekBar) {
				}

				int l;

				public void onProgressChanged(SeekBar seekBar, int i, boolean z) {


					if (i == 0) {
						seekBar.setProgress(i);
						interInt.OnWrite(i);
						TextView textView = textView2;
						textView.setText(Html.fromHtml("<font face='serif'><b>" + feature + ": <font color='BLUE'>" + "OFF" + "</font>"));
						return;
					}
					interInt.OnWrite(i);
					textView.setText(Html.fromHtml("<font face='serif'><b>" + feature + ": <font color='BLUE'>" + i + "</font>"));
				}
			});

        linearLayout.addView(textView);
        linearLayout.addView(seekBar);
        patches4.addView(linearLayout);
    }

	private void addESPSeekBar(final String feature, final int prog, int max, final InterfaceInt interInt) {
		LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        linearLayout.setPadding(10, 5, 0, 5);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.setGravity(17);
		linearLayout.setBackgroundColor(Color.parseColor("#000000"));
		linearLayout.getBackground().setAlpha(0);
        linearLayout.setLayoutParams(layoutParams);
        final TextView textView = new TextView(this);
	//	textView.setShadowLayer((float)25, (float)0, (float)0, Color.BLUE);
        textView.setText(Html.fromHtml("<font face='serif'><b>" + feature + ": <font color='BLUE'>" + "OFF" + "</font>"));
        textView.setTextColor(Color.parseColor("#FFFFFF"));
		textView.setTextSize(12);
        SeekBar seekBar = new SeekBar(this);
        seekBar.setPadding(25, 10, 35, 10);
        seekBar.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        seekBar.setMax(max);
        seekBar.setProgress(prog);
		seekBar.getProgressDrawable().setColorFilter(Color.parseColor("WHITE"), PorterDuff.Mode.MULTIPLY);
        seekBar.getThumb().setColorFilter(Color.parseColor("WHITE"), PorterDuff.Mode.SRC_IN);
        final TextView textView2 = textView;
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
				public void onStartTrackingTouch(SeekBar seekBar) {
				}

				public void onStopTrackingTouch(SeekBar seekBar) {
				}

				int l;

				public void onProgressChanged(SeekBar seekBar, int i, boolean z) {


					if (i == 0) {
						seekBar.setProgress(i);
						interInt.OnWrite(i);
						TextView textView = textView2;
						textView.setText(Html.fromHtml("<font face='serif'><b>" + feature + ": <font color='BLUE'>" + "OFF" + "</font>"));
						return;
					}
					interInt.OnWrite(i);
					textView.setText(Html.fromHtml("<font face='serif'><b>" + feature + ": <font color='BLUE'>" + i + "</font>"));
				}
			});

        linearLayout.addView(textView);
        linearLayout.addView(seekBar);
        patches3.addView(linearLayout);
    }
	
	private void addEXTRASeekBar(final String feature, final int prog, int max, final InterfaceInt interInt) {
		LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        linearLayout.setPadding(10, 5, 0, 5);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.setGravity(17);
		linearLayout.setBackgroundColor(Color.parseColor("#000000"));
		linearLayout.getBackground().setAlpha(0);
        linearLayout.setLayoutParams(layoutParams);
        final TextView textView = new TextView(this);
		//textView.setShadowLayer((float)25, (float)0, (float)0, Color.BLUE);
        textView.setText(Html.fromHtml("<font face='serif'><b>" + feature + ": <font color='BLUE'>" + "OFF" + "</font>"));
        textView.setTextColor(Color.parseColor("#FFFFFF"));
		textView.setTextSize(12);
        SeekBar seekBar = new SeekBar(this);
        seekBar.setPadding(25, 10, 35, 10);
        seekBar.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        seekBar.setMax(max);
        seekBar.setProgress(prog);
		seekBar.getProgressDrawable().setColorFilter(Color.parseColor("WHITE"), PorterDuff.Mode.MULTIPLY);
        seekBar.getThumb().setColorFilter(Color.parseColor("WHITE"), PorterDuff.Mode.SRC_IN);
        final TextView textView2 = textView;
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
				public void onStartTrackingTouch(SeekBar seekBar) {
				}

				public void onStopTrackingTouch(SeekBar seekBar) {
				}

				int l;

				public void onProgressChanged(SeekBar seekBar, int i, boolean z) {


					if (i == 0) {
						seekBar.setProgress(i);
						interInt.OnWrite(i);
						TextView textView = textView2;
						textView.setText(Html.fromHtml("<font face='serif'><b>" + feature + ": <font color='BLUE'>" + "OFF" + "</font>"));
						return;
					}
					interInt.OnWrite(i);
					textView.setText(Html.fromHtml("<font face='serif'><b>" + feature + ": <font color='BLUE'>" + i + "</font>"));
				}
			});

        linearLayout.addView(textView);
        linearLayout.addView(seekBar);
        patches5.addView(linearLayout);
    }


    private void addSeekBarSpot(final String feature, final int prog, int max, final InterfaceInt interInt) {
        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        linearLayout.setPadding(10, 5, 0, 5);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.setGravity(17);
        linearLayout.setLayoutParams(layoutParams);
        final TextView textView = new TextView(this);
        textView.setText(Html.fromHtml("<font face='serif'>" + feature + ": <font color='BLUE'>" + "OFF" + "</font>"));
        textView.setTextColor(Color.parseColor("#FFFFFF"));
		textView.setTextSize(12);
        SeekBar seekBar = new SeekBar(this);
        seekBar.setPadding(25, 10, 35, 10);
        seekBar.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        seekBar.setMax(max);
        seekBar.setProgress(prog);
		seekBar.getProgressDrawable().setColorFilter(Color.parseColor("WHITE"), PorterDuff.Mode.MULTIPLY);
        seekBar.getThumb().setColorFilter(Color.parseColor("WHITE"), PorterDuff.Mode.SRC_IN);

        final TextView textView2 = textView;
        final SeekBar seekBar2 = seekBar;
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
				public void onStartTrackingTouch(SeekBar seekBar2) {
				}

				public void onStopTrackingTouch(SeekBar seekBar2) {
				}

				int l;

				public void onProgressChanged(SeekBar seekBar2, int i, boolean z) {
					if (i == 0) {
						seekBar2.setProgress(i);
						interInt.OnWrite(i);
						TextView textView = textView2;
						textView.setText(Html.fromHtml("<font face='serif'><b>" + feature + ": <font color='BLUE'>" + "OFF" + "</b></font>"));
					} else if (i == 1) {
						seekBar2.setProgress(i);
						interInt.OnWrite(i);
						TextView textView = textView2;
						textView.setText(Html.fromHtml("<font face='serif'><b>" + feature + ": <font color='RED'>" + "HEAD" + "</b></font>"));
					} else if (i == 2) {
						seekBar2.setProgress(i);
						interInt.OnWrite(i);
						TextView textView = textView2;
						textView.setText(Html.fromHtml("<font face='serif'><b>" + feature + ": <font color='YELLOW'>" + "CHEST" + "</b></font>"));
					} else if (i == 3) {
						seekBar2.setProgress(i);
						interInt.OnWrite(i);
						TextView textView = textView2;
						textView.setText(Html.fromHtml("<font face='serif'><b>" + feature + ": <font color='WHITE'>" + "LEG" + "</b></font>"));
					}
					interInt.OnWrite(i);
				}
			});

        linearLayout.addView(textView);
        linearLayout.addView(seekBar);
        patches.addView(linearLayout);
    }

	private void addESPSeekBarSpot(final String feature, final int prog, int max, final InterfaceInt interInt) {
        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        linearLayout.setPadding(10, 5, 0, 5);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.setGravity(17);
        linearLayout.setLayoutParams(layoutParams);
        final TextView textView = new TextView(this);
        textView.setText(Html.fromHtml("<font face='serif'>" + feature + ": <font color='RED'>" + "Red" + "</font>"));
        textView.setTextColor(Color.parseColor("#FFFFFF"));
		textView.setTextSize(12);
        SeekBar seekBar = new SeekBar(this);
        seekBar.setPadding(25, 10, 35, 10);
        seekBar.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        seekBar.setMax(max);
        seekBar.setProgress(prog);
		seekBar.getProgressDrawable().setColorFilter(Color.parseColor("WHITE"), PorterDuff.Mode.MULTIPLY);
        seekBar.getThumb().setColorFilter(Color.parseColor("WHITE"), PorterDuff.Mode.SRC_IN);

        final TextView textView2 = textView;
        final SeekBar seekBar2 = seekBar;
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
				public void onStartTrackingTouch(SeekBar seekBar2) {
				}

				public void onStopTrackingTouch(SeekBar seekBar2) {
				}

				int l;

				public void onProgressChanged(SeekBar seekBar2, int i, boolean z) {
					if (i == 0) {
						seekBar2.setProgress(i);
						interInt.OnWrite(i);
						TextView textView = textView2;
						textView.setText(Html.fromHtml("<font face='serif'><b>" + feature + ": <font color='RED'>" + "Red" + "</b></font>"));
					} else if (i == 1) {
						seekBar2.setProgress(i);
						interInt.OnWrite(i);
						TextView textView = textView2;
						textView.setText(Html.fromHtml("<font face='serif'><b>" + feature + ": <font color='GREEN'>" + "Green" + "</b></font>"));
					} else if (i == 2) {
						seekBar2.setProgress(i);
						interInt.OnWrite(i);
						TextView textView = textView2;
						textView.setText(Html.fromHtml("<font face='serif'><b>" + feature + ": <font color='GRAY'>" + "Black" + "</b></font>"));
					} else if (i == 3) {
							seekBar2.setProgress(i);
							interInt.OnWrite(i);
							TextView textView = textView2;
						textView.setText(Html.fromHtml("<font face='serif'><b>" + feature + ": <font color='BLUE'>" + "Blue" + "</b></font>"));
					} else if (i == 4) {
							seekBar2.setProgress(i);
							interInt.OnWrite(i);
							TextView textView = textView2;
						textView.setText(Html.fromHtml("<font face='serif'><b>" + feature + ": <font color='CYAN'>" + "Cyan" + "</b></font>"));
					} else if (i == 5) {
							seekBar2.setProgress(i);
							interInt.OnWrite(i);
							TextView textView = textView2;
						textView.setText(Html.fromHtml("<font face='serif'><b>" + feature + ": <font color='PURPLE'>" + "Purple" + "</b></font>"));
					} else if (i == 6) {
							seekBar2.setProgress(i);
							interInt.OnWrite(i);
							TextView textView = textView2;
						textView.setText(Html.fromHtml("<font face='serif'><b>" + feature + ": <font color='YELLOW'>" + "Yellow" + "</b></font>"));
					} else if (i == 7) {
							seekBar2.setProgress(i);
							interInt.OnWrite(i);
							TextView textView = textView2;
						textView.setText(Html.fromHtml("<font face='serif'><b>" + feature + ": <font color='WHITE'>" + "White" + "</b></font>"));
					} else if (i == 8) {
						seekBar2.setProgress(i);
						interInt.OnWrite(i);
						TextView textView = textView2;
						textView.setText(Html.fromHtml("<font face='serif'><b>" + feature + ": <font color='MAGENTA'>" + "Magenta" + "</b></font>"));
					}
					interInt.OnWrite(i);
				}
			});

        linearLayout.addView(textView);
        linearLayout.addView(seekBar);
        patches3.addView(linearLayout);
    }


    boolean delayed;

    public void playSound(Uri uri) {
        if (EnableSounds()) {
            if (!delayed) {
                delayed = true;
                if (FXPlayer != null) {
                    FXPlayer.stop();
                    FXPlayer.release();
                }
                FXPlayer = MediaPlayer.create(this, uri);
                if (FXPlayer != null)
				//Volume reduced so sounds are not too loud
                    FXPlayer.setVolume(0.5f, 0.5f);
                FXPlayer.start();

                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
						@Override
						public void run() {
							delayed = false;
						}
					}, 100);
            }
        }
    }


	public boolean isViewCollapsed() {
        return mFloatingView == null || mCollapsed.getVisibility() == View.VISIBLE;
    }

    //For our image a little converter
    private int convertDipToPixels(int i) {
        return (int) ((((float) i) * getResources().getDisplayMetrics().density) + 0.5f);
    }

    private int dp(int i) {
        return (int) TypedValue.applyDimension(1, (float) i, getResources().getDisplayMetrics());
    }

    //Destroy our View
    public void onDestroy() {
        super.onDestroy();
        View view = mFloatingView;
        if (view != null) {
            mWindowManager.removeView(view);
        }
		ESPView espView = this.overlayView;
        if (espView != null) {
            this.mWindowManager.removeView(espView);
            this.overlayView = null;
        }
    }


	//Check if we are still in the game. If now our Menu and Menu button will dissapear
    private boolean isNotInGame() {
        RunningAppProcessInfo runningAppProcessInfo = new RunningAppProcessInfo();
        ActivityManager.getMyMemoryState(runningAppProcessInfo);
        return runningAppProcessInfo.importance != 100;
    }

    //Same as above so it wont crash in the background and therefore use alot of Battery life
    public void onTaskRemoved(Intent intent) {
        stopSelf();
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        super.onTaskRemoved(intent);
    }

    /* access modifiers changed from: private */
    public void Thread() {
        if (mFloatingView == null) {
            return;
        }
        if (isNotInGame()) {
            mFloatingView.setVisibility(View.INVISIBLE);
        } else {
            mFloatingView.setVisibility(View.VISIBLE);
        }
    }


    private interface InterfaceBtn {
        void OnWrite();
    }

    private interface InterfaceInt {
        void OnWrite(int i);
    }

    private interface InterfaceBool {
        void OnWrite(boolean z);
    }

    private interface InterfaceStr {
        void OnWrite(String s);
    }
}



