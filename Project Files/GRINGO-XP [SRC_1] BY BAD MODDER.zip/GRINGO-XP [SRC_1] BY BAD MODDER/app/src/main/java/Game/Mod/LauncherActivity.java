package Game.Mod;
import android.annotation.TargetApi;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.app.AlertDialog;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.GradientDrawable;
import android.graphics.PixelFormat;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import java.io.IOException;
import android.text.Html;
import android.text.InputFilter;
import android.text.InputType;
import android.text.method.DigitsKeyListener;
import android.util.Base64;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import Game.Mod.ESPView;
import java.io.File;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import java.io.IOException;
import android.content.res.AssetManager;
import static android.widget.RelativeLayout.ALIGN_PARENT_RIGHT;
import static android.view.ViewGroup.LayoutParams.WRAP_CONTENT;
import static android.view.ViewGroup.LayoutParams.MATCH_PARENT;
import static android.widget.RelativeLayout.ALIGN_PARENT_LEFT;
import android.net.ConnectivityManager;
import java.net.HttpURLConnection;
import java.io.BufferedReader;
import java.io.InputStream;
import java.net.URL;
import android.os.AsyncTask;
import android.annotation.SuppressLint;
import java.io.InputStreamReader;

import Game.Mod.BadLauncher.Titanic;
import Game.Mod.BadLauncher.TitanicTextView;
public class LauncherActivity extends Service {
	final int TEXT_COLOR = Color.parseColor("#000000");
    final int TEXT_COLOR_2 = Color.parseColor("#FFFFFF");
    final int BTN_COLOR = Color.parseColor("#000000");
    final int MENU_BG_COLOR = Color.parseColor("#000000"); //#AARRGGBB
    final int MENU_FEATURE_BG_COLOR = Color.parseColor("#000000"); //#AARRGGBB
    final int MENU_WIDTH = 290;
    final int MENU_HEIGHT = 210;
    final float MENU_CORNER = 20f;
    final int ICON_SIZE = 50;
    final float ICON_ALPHA = 0.7f; //Transparent
    public View mFloatingView;
	private Button kill;
    private Button close;
    private LinearLayout mButtonPanel;
    public RelativeLayout mCollapsed;
    public LinearLayout mExpanded;
    private RelativeLayout mRootContainer;
    public WindowManager mWindowManager;
    public WindowManager.LayoutParams params;
    private LinearLayout patches;
    private FrameLayout rootFrame;
    private ImageView startimage;
    private LinearLayout view1;
    private LinearLayout view2;
	private LinearLayout Btns;
    private LinearLayout Btns2;
    private AlertDialog alert;
    private EditText edittextvalue;
    private LinearLayout mLinearLayout2;
    private ImageView ffid;
    private ImageView ffidXX;
    private ImageView phs;
    private LinearLayout patches2;
	private ESPView overlayView;
	public static native void DrawOn(ESPView espView, Canvas canvas);
	private WindowManager.LayoutParams espParams;
    private static final String TAG = "Mod Menu";
    public static native String Toast();
    private native String Icon();
    private native String Title();
    private native String Heading();
    private native boolean EnableSounds();
    private native String Iconps();
    private native int IconSize();
    public native void Changes(int feature, int value);
    private native String[] getFeatureList();
    private TextView addText(String string) {
        TextView textView = new TextView(this);
        textView.setText((CharSequence)string);
        textView.setTextColor(Color.WHITE);
        textView.setTextSize(13.0f);
        textView.setTypeface(null, Typeface.BOLD);
        textView.setPadding(5, 0, 0, 5);
        textView.setGravity(Gravity.LEFT);
        return textView;
	}
    private static String getArch(String string) {
        if (string.contains((CharSequence)"lib/arm64")) {
            return "arm64";
        }
        if (string.contains((CharSequence)"lib/arm")) {
            return "armv7";
        }
        if (string.contains((CharSequence)"lib/x86")) {
            return "x86";
        }
        return "";
    }
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    public int onStartCommand(Intent intent, int i, int i2) {
        return Service.START_NOT_STICKY;
    }
	private int getLayoutType() {
        if (Build.VERSION.SDK_INT >= 26) {
            return 2038;
        }
        if (Build.VERSION.SDK_INT >= 24) {
            return 2002;
        }
        if (Build.VERSION.SDK_INT >= 23) {
            return 2005;
        }
        return 2003;
    }
	private void DrawCanvas() {
        WindowManager.LayoutParams layoutParams;
        this.espParams = layoutParams = new WindowManager.LayoutParams(-1, -1, this.getLayoutType(), 56, -3);
        layoutParams.gravity = 8388659;
        this.espParams.x = 0;
        this.espParams.y = 0;
        this.mWindowManager.addView((View)this.overlayView, (ViewGroup.LayoutParams)this.espParams);
    }

	//When this Class is called the code in this function will be executed
	@Override
    public void onCreate() {
		super.onCreate();
        //A little message for the user when he opens the app
        //Toast.makeText(this, Toast(), Toast.LENGTH_LONG).show();
        //Init Lib

        // When you change the lib name, change also on Android.mk file
        // Both must have same name
        System.loadLibrary("hook");
		this.overlayView = new ESPView((Context)this);
        try {
            this.initFloating();
		} catch (IOException e) {}
        DrawCanvas();
		CreateMenuList();
        final Handler handler = new Handler();
        handler.post(new Runnable() {
                public void run() {
                    handler.postDelayed(this, 1000);
                }
            });
    }

    //Here we write the code for our Menu

    private void initFloating() throws IOException {
        ImageView imageView;
        rootFrame = new FrameLayout(getBaseContext()); // Global markup
        mRootContainer = new RelativeLayout(getBaseContext()); // Markup on which two markups of the icon and the menu itself will be placed
        mCollapsed = new RelativeLayout(getBaseContext()); // Markup of the icon (when the menu is minimized)
        mExpanded = new LinearLayout(getBaseContext()); // Menu markup (when the menu is expanded)
        view1 = new LinearLayout(getBaseContext());
        patches = new LinearLayout(getBaseContext());
        view2 = new LinearLayout(getBaseContext());
		Btns = new LinearLayout(getBaseContext());
        Btns2 = new LinearLayout(getBaseContext());
		mButtonPanel = new LinearLayout(getBaseContext()); // Layout of option buttons (when the menu is expanded)
		AssetManager assetManager = getAssets();
        patches2 = new LinearLayout(getBaseContext());
		
		rootFrame.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        mCollapsed.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        mCollapsed.setVisibility(View.VISIBLE);
        rootFrame.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        mRootContainer.setLayoutParams(new FrameLayout.LayoutParams(-2, -2));
        mCollapsed.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        mCollapsed.setVisibility(View.VISIBLE);
		
		view1.setLayoutParams(new LinearLayout.LayoutParams(-1, 2));
		view1.setBackgroundColor(Color.rgb(0,116,186));
		
		view2.setLayoutParams(new LinearLayout.LayoutParams(-1, 2));
		view2.setBackgroundColor(Color.rgb(0,116,186));
		
        startimage = new ImageView(getBaseContext());
        startimage.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        int applyDimension = (int) TypedValue.applyDimension(1, (float) IconSize(), getResources().getDisplayMetrics());
        startimage.getLayoutParams().height = applyDimension;
        startimage.getLayoutParams().width = applyDimension;
        startimage.requestLayout();
        startimage.setScaleType(ImageView.ScaleType.FIT_XY);
        byte[] decode = Base64.decode(Icon(), 0);
        startimage.setImageBitmap(BitmapFactory.decodeByteArray(decode, 0, decode.length));
        ((ViewGroup.MarginLayoutParams) startimage.getLayoutParams()).topMargin = convertDipToPixels(10);
		
        
        
        this.ffid = new ImageView(getBaseContext());
        RelativeLayout.LayoutParams ffid_LayoutParams = new RelativeLayout.LayoutParams(-0, -2);
        this.ffid.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        ffid_LayoutParams.addRule(0, -0);
        ffid_LayoutParams.setMarginEnd((int) ((0.0f) + 0.0f));
        this.ffid.getLayoutParams().height = dp(55);
        this.ffid.getLayoutParams().width = dp(55);
        this.ffid.requestLayout();
        this.ffid.setPadding(0, 0, 0, 0);
        this.ffid.setTranslationX(0);
        this.ffid.setTranslationY(0);
        InputStream inputStream_close2 = null;
        try {
            inputStream_close2 = assetManager.open("icon.png");
        } catch (IOException e) {
            e.printStackTrace();
        }
        Drawable ic_close2 = Drawable.createFromStream(inputStream_close2, null);
        ffid.setImageDrawable(ic_close2);
        ((ViewGroup.MarginLayoutParams) this.ffid.getLayoutParams()).leftMargin = convertDipToPixels(0);
        
        this.ffidXX = new ImageView(getBaseContext());
        RelativeLayout.LayoutParams ffidXX_LayoutParams = new RelativeLayout.LayoutParams(-0, -2);
        this.ffidXX.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        ffidXX_LayoutParams.addRule(0, -0);
        ffidXX_LayoutParams.setMarginEnd((int) ((0.0f) + 0.0f));
        this.ffidXX.getLayoutParams().height = dp(40);
        this.ffidXX.getLayoutParams().width = dp(40);
        this.ffidXX.requestLayout();
        this.ffidXX.setPadding(0, 0, 0, 0);
        this.ffidXX.setTranslationX(0);
        this.ffidXX.setTranslationY(0);
        InputStream inputStream_close20 = null;
        try {
            inputStream_close20 = assetManager.open("icon.png");
        } catch (IOException e) {
            e.printStackTrace();
        }
        Drawable ic_close20 = Drawable.createFromStream(inputStream_close20, null);
        ffidXX.setImageDrawable(ic_close20);
        ((ViewGroup.MarginLayoutParams) this.ffidXX.getLayoutParams()).leftMargin = convertDipToPixels(0);
        
	//_____Main Layout	
        mExpanded.setVisibility(View.GONE); 
        mExpanded.setGravity(17);
        mExpanded.setOrientation(LinearLayout.VERTICAL);
        android.graphics.drawable.GradientDrawable BJGEDBC = new android.graphics.drawable.GradientDrawable();
        int BJGEDBCADD[] = new int[]{ Color.parseColor("#CA000000"), Color.parseColor("#CA000000") };
        BJGEDBC.setColors(BJGEDBCADD);
		mExpanded.setAlpha(0.99f);
        BJGEDBC.setOrientation(android.graphics.drawable.GradientDrawable.Orientation.RIGHT_LEFT);
        BJGEDBC.setCornerRadii(new float[] { 10, 10, 10, 10, 10, 10, 10, 10 });
		BJGEDBC.setStroke(2,Color.rgb(0,116,186));
        mExpanded.setBackground(BJGEDBC);	
        mExpanded.setPadding(3, 3, 3, 0);
        mExpanded.setLayoutParams(new LinearLayout.LayoutParams(dp(220), -2));
   
//______Scroll layout
        final ScrollView scrollView = new ScrollView(getBaseContext());
        scrollView.setPadding(0, 0, 0, 0);
        scrollView.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(190)));
     
        patches.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        patches.setOrientation(LinearLayout.VERTICAL);
        patches2 = new LinearLayout(this);
        patches2.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        patches2.setOrientation(1);
		patches2.setVisibility(View.GONE);
        mButtonPanel.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));

        
        RelativeLayout relativeLayout = new RelativeLayout(this);
		relativeLayout.setPadding(0,5,3,5);
		
        
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, dp(40));
        layoutParams.addRule(11);
		
        close = new Button(this);
        close.setBackgroundColor(Color.parseColor("#FF0000"));
		close.setTextSize(15.0f);
		close.setTypeface((Typeface) null, 1);
        close.setText("CLOSE");
        close.setTextColor(Color.rgb(0,116,186));
        close.setLayoutParams(layoutParams);
		android.graphics.drawable.GradientDrawable 
		CDGAEAHH = new android.graphics.drawable.GradientDrawable();
		CDGAEAHH.setColor(Color.rgb(0,116,186));
        CDGAEAHH.setCornerRadii(new float[] { 15, 15, 15, 15, 15, 15, 45, 45 });
		CDGAEAHH.setColor(Color.TRANSPARENT);
		CDGAEAHH.setStroke(2,Color.rgb(0,116,186));
		close.setBackground(CDGAEAHH);
		
        relativeLayout.addView(close);
		//relativeLayout.addView(kill);
        
        phs = new ImageView(this);
        RelativeLayout.LayoutParams phs_LayoutParams = new RelativeLayout.LayoutParams(-2, -2);
        phs.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        phs_LayoutParams.addRule(21, -1);
        phs_LayoutParams.setMarginEnd((int) ((275.0f) + 0.0f));
        phs.getLayoutParams().height = dp(48);
        phs.getLayoutParams().width = dp(48);
        phs.requestLayout();
        phs.setScaleType(ImageView.ScaleType.FIT_START);
        byte[] decode3 = Base64.decode(Iconps(), 4);
        phs.setImageBitmap(BitmapFactory.decodeByteArray(decode3, 0, decode3.length));
        ((ViewGroup.MarginLayoutParams) this.phs.getLayoutParams()).leftMargin = convertDipToPixels(5);
		
//______TITLE [BY BAD MODDER]/[MGA-ZG]______\\
		
        RelativeLayout titleText = new RelativeLayout(this);
		titleText.setVerticalGravity(16);
		
        TitanicTextView badmod = new TitanicTextView(this);
		badmod.setText("GRINGO XP");
        badmod.setTextColor(Color.rgb(0,116,186));
		badmod.setTextSize(20.0f);
		badmod.setTypeface((Typeface) null, 1);
		badmod.setGravity(Gravity.CENTER);
        badmod.setPadding(0,5,0,0);
		
		RelativeLayout.LayoutParams rl = new RelativeLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT);
        rl.addRule(RelativeLayout.CENTER_HORIZONTAL);
        badmod.setLayoutParams(rl);	
		new Titanic().start(badmod);
		
		TitanicTextView badmod2 = new TitanicTextView(this);
		badmod2.setText("Version: V15 Layout Bad Src");
		badmod2.setShadowLayer(2.0f,0.0f,0.0f,Color.RED);
        badmod2.setTextColor(-1);
		badmod2.setTextSize(12.0f);
		badmod2.setTypeface((Typeface) null, 1);
		badmod2.setGravity(Gravity.CENTER);
        badmod2.setPadding(0,0,0,2);
		
		
        rootFrame.addView(mRootContainer);
        mRootContainer.addView(mCollapsed);
        mRootContainer.addView(mExpanded);
        mCollapsed.addView(ffid);
        mExpanded.addView(titleText);
     
        titleText.addView(badmod);
		mExpanded.addView(badmod2);
        mExpanded.addView(view1);
        mExpanded.addView(scrollView);
        scrollView.addView(patches);
		mExpanded.addView(view2);
        mExpanded.addView(relativeLayout);
        mFloatingView = rootFrame;
		
		if (Build.VERSION.SDK_INT >= 26) {
            params = new WindowManager.LayoutParams(-2, -2, 2038, 8, -3);
        } else {
            params = new WindowManager.LayoutParams(-2, -2, 2002, 8, -3);
        }
        WindowManager.LayoutParams layoutParams4 = params;
        layoutParams4.gravity = 51;
        layoutParams4.x = 0;
        layoutParams4.y = 100;
        mWindowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        mWindowManager.addView(mFloatingView, params);

        RelativeLayout relativeLayout2 = mCollapsed;
        LinearLayout linearLayout = mExpanded;
        mFloatingView.setOnTouchListener(onTouchListener());
        startimage.setOnTouchListener(onTouchListener());
        initMenuButton(relativeLayout2, linearLayout);

    }

    private View.OnTouchListener onTouchListener() {
        return new View.OnTouchListener() {
            final View collapsedView = mCollapsed;
            final View expandedView = mExpanded;
            private float initialTouchX;
            private float initialTouchY;
            private int initialX;
            private int initialY;

            public boolean onTouch(View view, MotionEvent motionEvent) {
                switch (motionEvent.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = motionEvent.getRawX();
                        initialTouchY = motionEvent.getRawY();
                        return true;
                    case MotionEvent.ACTION_UP:
                        int rawX = (int) (motionEvent.getRawX() - initialTouchX);
                        int rawY = (int) (motionEvent.getRawY() - initialTouchY);

                        //The check for Xdiff <10 && YDiff< 10 because sometime elements moves a little while clicking.
                        //So that is click event.
                        if (rawX < 10 && rawY < 10 && isViewCollapsed()) {                     
                            collapsedView.setVisibility(View.GONE);
                            expandedView.setVisibility(View.VISIBLE);

                            //Toast.makeText(FloatingModMenuService.this, Html.fromHtml(Toast()), Toast.LENGTH_SHORT).show();
                        }
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        //Calculate the X and Y coordinates of the view.
                        params.x = initialX + ((int) (motionEvent.getRawX() - initialTouchX));
                        params.y = initialY + ((int) (motionEvent.getRawY() - initialTouchY));

                        //Update the layout with new X & Y coordinate
                        mWindowManager.updateViewLayout(mFloatingView, params);
                        return true;
                    default:
                        return false;
                }
            }
        };
    }


	private boolean hide = false;

	//Initialize event handlers for buttons, etc.
    private void initMenuButton(final View view2, final View view3) {
        startimage.setOnClickListener(new View.OnClickListener() {
				public void onClick(View view) {
					view2.setVisibility(View.GONE);
					view3.setVisibility(View.VISIBLE);
				}
			});
		close.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {

                    mCollapsed.setVisibility(0);
                    mCollapsed.setAlpha(0.95f);
                    mExpanded.setVisibility(8);
                }
            });
    }


    private void CreateMenuList() {
        String[] listFT = getFeatureList();
        for (int i = 0; i < listFT.length; i++) {
            final int feature = i;
            String str = listFT[i];
            if (str.contains("TG_")) {

                addSwitch(str.replace("TG_", ""), new InterfaceBool() {
                        public void OnWrite(boolean z) {
                            Changes(feature, 0);
                        }
                    });
            } else if (str.contains("SeekBar_")) {
                String[] split = str.split("_");
                addSeekBar(split[1], Integer.parseInt(split[2]), Integer.parseInt(split[3]), new InterfaceInt() {
                        public void OnWrite(int i) {
                            Changes(feature, i);
                        }
                    });
    
			} else if (str.contains("Category_")) {
                addCategory(str.replace("Category_", ""));
                  }
                }
              }
    private TextView textView2;
    private String featureNameExt;
    private int featureNum;
    private EditTextValue txtValue;

    public class EditTextValue {
        private int val;

        public void setValue(int i) {
            val = i;
        }

        public int getValue() {
            return val;
        }
    }
	private void addCategory(String text) {
        TextView textView = new TextView(this);
        LinearLayout.LayoutParams layoutParams7 = new LinearLayout.LayoutParams(-1, -2);
        textView.setText(text);
        textView.setGravity(17);
        layoutParams7.bottomMargin = 10;
        textView.setLayoutParams(layoutParams7);
        textView.setTextSize(13.0f); 
        textView.setTextColor(-1);
        textView.setTypeface(null, Typeface.BOLD);
        textView.setPadding(10, 5, 0, 5);
		textView.setBackgroundColor(Color.rgb(0,116,186));
        patches.addView(textView);
    }
    

    private void addSwitch(String feature, final InterfaceBool sw) {
        Switch switchR = new Switch(this);
        switchR.setBackgroundColor(Color.TRANSPARENT);
        switchR.setText(Html.fromHtml("<font face='roboto'>" + feature + "</font>"));
        switchR.setTextColor(Color.parseColor("WHITE"));
		GradientDrawable g= new  GradientDrawable();
        g.setSize(37,37);
        g.setShape(1);
		g.setStroke(2, Color.argb(255,224,224,224));
        g.setColor(Color.WHITE);
        final GradientDrawable gd = new GradientDrawable();
        gd.setColor(Color.WHITE);
        gd.setSize(15,24);
		gd.setStroke(1,-1);
        gd.setCornerRadius(80);
        switchR.setTextColor(Color.parseColor("WHITE"));
		switchR.setTypeface(Typeface.DEFAULT_BOLD);
        switchR.setPadding(10, 3, 3, 3);
        switchR.setTextSize(14.0f);
		switchR.setBackgroundColor(Color.TRANSPARENT);
        switchR.setThumbDrawable(g);
        switchR.setTrackDrawable(gd);
		switchR.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(35)));
        switchR.setTypeface(switchR.getTypeface(), Typeface.NORMAL);
        switchR.setPadding(10, 5, 5, 5);
		if(Build.VERSION.SDK_INT >= 21) { switchR.setElevation(100f); }
        switchR.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
				public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
					if (z) {
						gd.setColor(Color.rgb(0,116,186));
						gd.setStroke(1,Color.rgb(0,116,186));

					} else {
						gd.setColor(Color.argb(255,255,255,255));
						gd.setStroke(1,-1);
					}
					sw.OnWrite(z);
				}
			});
        patches.addView(switchR);
    }
	
	private void addSeekBar(final String feature, final int prog, int max, final InterfaceInt interInt) {
        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        linearLayout.setPadding(5, 5, 0, 5);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.setGravity(Gravity.CENTER_HORIZONTAL);
        linearLayout.setLayoutParams(layoutParams);
        final TextView textView = new TextView(this);
        textView.setText(Html.fromHtml(feature + " : <font color='RED'>" + " OFF" + "</font>"));
        textView.setTextColor(Color.WHITE);
        textView.setTypeface(Typeface.DEFAULT_BOLD);
        SeekBar seekBar = new SeekBar(this);
        seekBar.setPadding(25, 10, 35, 10);
        seekBar.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        seekBar.setMax(max);
        seekBar.setProgress(prog);
		seekBar.getProgressDrawable().setColorFilter(Color.rgb(0,116,186), PorterDuff.Mode.SRC_IN);
		seekBar.getThumb().setColorFilter(Color.LTGRAY, PorterDuff.Mode.SRC_ATOP);
		final TextView textView2 = textView;
		seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                public void onStartTrackingTouch(SeekBar seekBar) {
				}
				public void onStopTrackingTouch(SeekBar seekBar) {
				}

                int l;

                public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                    if (i == 0) {
                        seekBar.setProgress(i);
                        interInt.OnWrite(i);
                        TextView textView = textView2;
						textView.setText(Html.fromHtml("<font face=>" + feature + " : <font color='RED'>" + "OFF" + "</font>"));

                        return;
                    }
                    interInt.OnWrite(i);
					textView.setText(Html.fromHtml("<font face=>" + feature + " : <font color='LTGRAY'>" + i + "</font>"));

                }
            });

        linearLayout.addView(textView);
        linearLayout.addView(seekBar);
        patches.addView(linearLayout);
    }

	
		
	
    boolean delayed;



    public boolean isViewCollapsed() {
        return mFloatingView == null || mCollapsed.getVisibility() == View.VISIBLE;
    }

    //For our image a little converter
    private int convertDipToPixels(int i) {
        return (int) ((((float) i) * getResources().getDisplayMetrics().density) + 0.5f);
    }

    private int dp(int i) {
        return (int) TypedValue.applyDimension(1, (float) i, getResources().getDisplayMetrics());
    }

    //Destroy our View
    public void onDestroy() {
        super.onDestroy();

        if (view2 != null) {
            this.mWindowManager.removeView(view2);
        }
        View view = mFloatingView;
        if (view != null) {
            mWindowManager.removeView(view);
        }
    }

    // checking if any network connection / internet available

    // calling our AsyncTask Function that will do thee thing on fetching data from out host file

    // this is the checking one, this will draw our menu if it's license still valid or active

    //Check if we are still in the game. If now our Menu and Menu button will dissapear
    private boolean isNotInGame() {
        RunningAppProcessInfo runningAppProcessInfo = new RunningAppProcessInfo();
        ActivityManager.getMyMemoryState(runningAppProcessInfo);
        return runningAppProcessInfo.importance != 100;
    }

    //Same as above so it wont crash in the background and therefore use alot of Battery life


    private interface InterfaceBtn {
        void OnWrite();
    }

    private interface InterfaceInt {
        void OnWrite(int i);
    }

    private interface InterfaceBool {
        void OnWrite(boolean z);
    }

    private interface InterfaceStr {
        void OnWrite(String s);
    }
}
