#ifndef ESPFIRE_H
#define ESPFIRE_H
#include "Unity/Global.h"

void EspFiire(void *local_player, void *enemy_player) {
	int pose = GetPhysXPose(enemy_player);
	bool alive = get_isAlive(enemy_player);
	bool visible = get_isVisible(enemy_player);
	bool sameteam = get_isLocalTeam(enemy_player);
	void *Main_Camera = *(void **)((uintptr_t)local_player + Global.Camera_main);
	void *HeadTF = *(void **)((uintptr_t)enemy_player + Global.Get_PosisiKepala);
	void *HeadTF2 = *(void **)((uintptr_t)local_player + Global.Get_PosisiKepala);
	void *HipTF = *(void **)((uintptr_t)enemy_player + Global.Get_PosisiBadan);
	void *imo = get_imo(local_player);
	void *ui = CurrentUIScene();
	
	if (alive &&  pose != 8 && visible && !sameteam) {
		Vector3 EnemyLocation = Transform_INTERNAL_GetPosition(HipTF);
		Vector3 CenterWS = GetAttackableCenterWS(local_player);
		float distance = Vector3::Distance(CenterWS, EnemyLocation);
		if (Material) {
			if (imo != NULL && distance < 250.0f) {
                set_esp(imo, CenterWS, EnemyLocation);
            }
        }
		if (LineMaterial) {
			Vector3 From = Transform_INTERNAL_GetPosition(Component_GetTransform(Camera_main()));
			Vector3 EnemyLocationn = Transform_INTERNAL_GetPosition(Component_GetTransform(HipTF));
			Vector3 BodyZPos = GetPosisiBadan(local_player);
			Vector3 From2 = From + Vector3(2.3,8,(BodyZPos.Z - From.Z));
			Vector3 To = GetPosisiKepala(enemy_player);
			set_esp(get_imo(local_player),From2,To);
		}
		if (EspNameV2) {
			if (ui != NULL) {
			    monoString *nick = get_NickName(enemy_player);
			    monoString *distances = U3DStrFormatBot(distance);
			    monoString *distances2 = U3DStrFormatPlayer(distance);
			    bool isPlayerBot = *(bool *) ((uintptr_t) enemy_player + Global.IsClientBot);
				if (isPlayerBot) {
					AddTeammateHud(ui, nick, distances);
				} else {
					AddTeammateHud(ui, nick, distances2);
				}
			}
		}
		if (FakeName) {
            spofNick(local_player);
        }
	}
}

#endif
