package Game.Mod;


import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Process;
import android.provider.Settings;


import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class StaticActivity {

    public static String cacheDir;

	public static void Start(final Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) {
            AlertDialog alertDialog = new AlertDialog.Builder(context, 1)
				.setTitle("Sem permissão de sobreposição!")
				.setMessage("A permissão de sobreposição é necessaria para o funcionamento do mod. Gostaria de concedê-las na proxima tela?")
				.setPositiveButton("Sim", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						context.startActivity(new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION",
														 Uri.parse("package:" + context.getPackageName())));
						Process.killProcess(Process.myPid());
					}
				})
				.setNegativeButton("Não", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {

					}
				}).setCancelable(false)
				.create();
            alertDialog.show();
        } else {
            Handler handler = new Handler();
            final String string = "Game.Mod.FloatingModMenuService";
            handler.postDelayed(new Runnable() {

					@Override
					public void run() {
						try {
							context.startService(new Intent(context, Class.forName(string)));
						} catch (ClassNotFoundException e) {
							e.printStackTrace();
						}
						}
					
				}, 500);
        }
    }
}

