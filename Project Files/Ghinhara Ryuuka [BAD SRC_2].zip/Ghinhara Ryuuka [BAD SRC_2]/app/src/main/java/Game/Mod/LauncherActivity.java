/*
 * Credit:
 *
 * Octowolve - Mod menu: https://github.com/z3r0Sec/Substrate-Template-With-Mod-Menu
 * And hooking: https://github.com/z3r0Sec/Substrate-Hooking-Example
 * VanHoevenTR A.K.A Nixi: https://github.com/LGLTeam/VanHoevenTR_Android_Mod_Menu
 * MrIkso - Mod menu: https://github.com/MrIkso/FloatingModMenu
 * Rprop - https://github.com/Rprop/And64InlineHook
 * MJx0 A.K.A Ruit - KittyMemory: https://github.com/MJx0/KittyMemory
 * */

package Game.Mod;

import android.annotation.TargetApi;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.app.AlertDialog;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.GradientDrawable;
import android.graphics.PixelFormat;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import java.text.SimpleDateFormat;
import android.text.Html;
import android.text.InputFilter;
import android.text.InputType;
import android.text.method.DigitsKeyListener;
import android.util.Base64;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import java.util.Calendar;
import java.util.GregorianCalendar;

import static Game.Mod.MgaZg.cacheDir;
import android.net.ConnectivityManager;
import java.net.HttpURLConnection;
import java.io.BufferedReader;
import java.io.InputStream;
import java.net.URL;
import android.os.AsyncTask;
import android.annotation.SuppressLint;
import java.io.InputStreamReader;

//________
import android.graphics.drawable.Drawable;
import java.io.IOException;
import android.content.res.AssetManager;
import static android.view.ViewGroup.LayoutParams.WRAP_CONTENT;
import static android.view.ViewGroup.LayoutParams.MATCH_PARENT;
import static android.widget.RelativeLayout.ALIGN_PARENT_RIGHT;

public class LauncherActivity extends Service {
    private MediaPlayer FXPlayer;
	final int MENU_BG_COLOR = Color.parseColor("#ff000000"); //#AARRGGBB
    public View mFloatingView;
    private Button close,logs;
    private LinearLayout mButtonPanel;
    public RelativeLayout mCollapsed;
    public LinearLayout mExpanded;
    private RelativeLayout mRootContainer;
    public WindowManager mWindowManager;
    public WindowManager.LayoutParams params;
    private LinearLayout scrollView1;//___aim
	private LinearLayout scrollView2;//____esp + Other
	private LinearLayout scrollView3;//____sub
	private LinearLayout scrollView4;
	private FrameLayout rootFrame;
    private ImageView startimage;
    private LinearLayout view1;
    private LinearLayout view2;
	private LinearLayout view3;//____TG
    private LinearLayout view4;//____TG
    private AlertDialog alert;
    private EditText edittextvalue;
	private LinearLayout patches;
	private Drawable img;
//_________String Auto Back________\\

	
	
    private static final String TAG = "Mod Menu";
    public static native String Toast();
    private native String Icon();
    private native boolean EnableSounds();
    private native int IconSize();
    public native void Changes(int feature, int value);
    private native String[] getFeatureListttttttttt();

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    //Override our Start Command so the Service doesnt try to recreate itself when the App is closed
    public int onStartCommand(Intent intent, int i, int i2) {
        return Service.START_NOT_STICKY;
    }

    //When this Class is called the code in this function will be executed
    @Override
    public void onCreate() {
        super.onCreate();
        //A little message for the user when he opens the app
        //Toast.makeText(this, Toast(), Toast.LENGTH_LONG).show();
        //Init Lib

        // When you change the lib name, change also on Android.mk file
        // Both must have same name
        System.loadLibrary("CnusTech");
        Toast.makeText(LauncherActivity.this, Html.fromHtml("MGA - ZG"), Toast.LENGTH_SHORT).show();
        initFloating();
        CreateMenuList();
        initAlertDiag();
        final Handler handler = new Handler();
        handler.post(new Runnable() {
				public void run() {
					handler.postDelayed(this, 1000);
				}
			});
    }



    //Here we write the code for our Menu

    private void initFloating() {
        rootFrame = new FrameLayout(getBaseContext()); // Global markup
        mRootContainer = new RelativeLayout(getBaseContext()); // Markup on which two markups of the icon and the menu itself will be placed
        mCollapsed = new RelativeLayout(getBaseContext()); // Markup of the icon (when the menu is minimized)
        mExpanded = new LinearLayout(getBaseContext()); // Menu markup (when the menu is expanded)
        view1 = new LinearLayout(getBaseContext());
		scrollView1 = new LinearLayout(this);//____aim 
        patches = new LinearLayout(getBaseContext());
        view2 = new LinearLayout(getBaseContext());
        mButtonPanel = new LinearLayout(getBaseContext()); // Layout of option buttons (when the menu is expanded)
		float scale = getBaseContext().getResources().getDisplayMetrics().density;		
		view3 = new LinearLayout(getBaseContext());
		view4 = new LinearLayout(getBaseContext());
		AssetManager assetManager = getAssets();
//_____Expire
		
      
		scrollView2 = new LinearLayout(this);//____ stok
        RelativeLayout relativeLayout = new RelativeLayout(this);
        relativeLayout.setLayoutParams(new RelativeLayout.LayoutParams(-2,dp(40)));
        relativeLayout.setPadding(0, 4, 2, 4);
        relativeLayout.setVerticalGravity(16);
		android.graphics.drawable.GradientDrawable GIDDGID = new android.graphics.drawable.GradientDrawable();
        int GIDDGIDADD[] = new int[]{ Color.parseColor("#ff000000"),Color.BLUE};
        GIDDGID.setColors(GIDDGIDADD);
        GIDDGID.setOrientation(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM);
        GIDDGID.setCornerRadii(new float[] { 5, 5, 5, 5, 5, 5, 5, 5 });
        android.graphics.drawable.RippleDrawable GIDDGID_RE = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{ Color.argb(84,0,255,255)}), GIDDGID, null);
        relativeLayout.setBackground(GIDDGID_RE);
	
		RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams.addRule(11);
		close = new Button(this);
		//close.setLayoutParams(new LinearLayout.LayoutParams(-2, dp(36)));
        close.setTextSize(15.0f);
        close.setTypeface((Typeface) null, 1);
        close.setBackgroundColor(0);  
		close.setTextColor(Color.WHITE);
		// close.setText("Oculter");
		close.setAllCaps(false);

        RelativeLayout.LayoutParams layoutParams1 = new RelativeLayout.LayoutParams(-2, dp(38));
        layoutParams1.addRule(11);

		logs = new Button(this);
        logs.setTextSize(15.0f);
        logs.setTypeface((Typeface) null, 1);
        logs.setBackgroundColor(0);
        logs.setTextColor(-1);
        logs.setText("CLOSE");
		logs.setLayoutParams(layoutParams1);
		logs.setShadowLayer((float)14, (float)0, (float)0, Color.RED);
		android.graphics.drawable.GradientDrawable IECGCAA = new android.graphics.drawable.GradientDrawable();
        IECGCAA.setColor(Color.parseColor("#00000000"));
		IECGCAA.setCornerRadii(new float[] { 5, 5, 5, 5, 5, 5, 5, 5 });
		IECGCAA.setStroke(2, Color.parseColor("#FFFFFFFF"));
		logs.setBackground(IECGCAA);
		logs.setAllCaps(false);
		android.graphics.drawable.GradientDrawable BGCCDGE = new android.graphics.drawable.GradientDrawable();
		int BGCCDGEADD[] = new int[]{ Color.argb(225,49,49,50), Color.argb(225,49,49,50) };
		BGCCDGE.setColors(BGCCDGEADD);
		BGCCDGE.setOrientation(android.graphics.drawable.GradientDrawable.Orientation.BOTTOM_TOP);
		BGCCDGE.setCornerRadii(new float[] { 30, 30, 5, 5, 5, 5, 5, 5 });
		BGCCDGE.setColor(Color.parseColor("#00000000"));
		BGCCDGE.setStroke(2, Color.parseColor("#FFFFFF"));
		android.graphics.drawable.RippleDrawable BGCCDGE_RE = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{ Color.argb(255,15,15,15)}), BGCCDGE, null);
		logs.setBackground(BGCCDGE_RE);
        relativeLayout.addView(close);
		relativeLayout.addView(logs);
		
		
		
		
		
		
		scrollView3 = new LinearLayout(this);//____esp + other
        
		
        rootFrame.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        mRootContainer.setLayoutParams(new FrameLayout.LayoutParams(-2, -2));
        mCollapsed.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        mCollapsed.setVisibility(View.VISIBLE);
        startimage = new ImageView(getBaseContext());
        startimage.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        int applyDimension = (int) TypedValue.applyDimension(1, (float) IconSize(), getResources().getDisplayMetrics());
        startimage.getLayoutParams().height = applyDimension;
        startimage.getLayoutParams().width = applyDimension;
        startimage.requestLayout();
        startimage.setScaleType(ImageView.ScaleType.FIT_XY);
        byte[] decode = Base64.decode(Icon(), 0);
        startimage.setImageBitmap(BitmapFactory.decodeByteArray(decode, 0, decode.length));
        ((ViewGroup.MarginLayoutParams) startimage.getLayoutParams()).topMargin = convertDipToPixels(10);
                
		ImageView BadLogo = new ImageView(this);
        RelativeLayout.LayoutParams BadLogo_LayoutParams = new RelativeLayout.LayoutParams(-0, -2);
        BadLogo.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        BadLogo_LayoutParams.addRule(ALIGN_PARENT_RIGHT);
        BadLogo_LayoutParams.setMarginEnd((int) ((0.0f) + 0.0f));
        BadLogo.getLayoutParams().height = dp(50);
        BadLogo.getLayoutParams().width = dp(50);
        BadLogo.requestLayout();
        InputStream inputStream_icone = null;
        try {
            inputStream_icone = assetManager.open("icon.png");
        } catch (IOException e) {
            e.printStackTrace();
        }
        Drawable icone = Drawable.createFromStream(inputStream_icone, null);
        BadLogo.setImageDrawable(icone);
        ((ViewGroup.MarginLayoutParams) 
			BadLogo.getLayoutParams()).leftMargin = convertDipToPixels(0);
		mExpanded.setVisibility(View.GONE);
        mExpanded.setBackgroundColor(0);
        mExpanded.setAlpha(0.75f);
        mExpanded.setGravity(17);
        mExpanded.setOrientation(LinearLayout.VERTICAL);
        if(Build.VERSION.SDK_INT >= 21) { mExpanded.setElevation(21f); }
		mExpanded.setLayoutParams(new LinearLayout.LayoutParams(dp(255), -2));
		GradientDrawable gdMenuBody = new GradientDrawable();
        gdMenuBody.setCornerRadius(10.0f); //Set corner
        gdMenuBody.setColor(MENU_BG_COLOR);
		mExpanded.setBackground(gdMenuBody);
		
        ScrollView scrollView = new ScrollView(this);
		scrollView4 = new LinearLayout(this);//____sub + join
		scrollView.setPadding(3, 3, 3, 3);
        scrollView.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(186)));

        scrollView1.setOrientation(LinearLayout.VERTICAL);
        scrollView2.setOrientation(LinearLayout.VERTICAL);
        scrollView3.setOrientation(LinearLayout.VERTICAL);
		scrollView4.setOrientation(LinearLayout.VERTICAL);
		
        view1.setLayoutParams(new LinearLayout.LayoutParams(-1, 3));
        view1.setBackgroundColor(Color.parseColor("#ffffff"));
        patches.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        patches.setOrientation(LinearLayout.VERTICAL);
        view2.setLayoutParams(new LinearLayout.LayoutParams(-1, 3));
        view2.setBackgroundColor(Color.parseColor("#ffffff"));
        view2.setPadding(0, 10, 0, 10);
        mButtonPanel.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));
		
		LinearLayout titleText = new LinearLayout(this);
        titleText.setPadding(0, 0, 0, 0);
        titleText.setGravity(Gravity.CENTER);
		titleText.setOrientation(LinearLayout.VERTICAL);
		
		android.graphics.drawable.GradientDrawable GIDDGIDX = new android.graphics.drawable.GradientDrawable();
        int GIDDGIDADDX[] = new int[]{ Color.BLACK,Color.BLUE};
        GIDDGIDX.setColors(GIDDGIDADDX);
        GIDDGIDX.setOrientation(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM);
        GIDDGIDX.setCornerRadii(new float[] { 5, 5, 5, 5, 0, 0, 0, 0 });
        android.graphics.drawable.RippleDrawable GIDDGIDX_RE = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{ Color.parseColor("#000000")}), GIDDGIDX, null);
        titleText.setBackground(GIDDGIDX_RE);

		TextView textView4 = new TextView(this);
		textView4.setText(Html.fromHtml("<font face=\'serif\'><b>Ghinhara Ryuuka</b></font>"));
		textView4.setTextSize(18.0f);
		textView4.setShadowLayer((float)14, (float)0, (float)0, -1);
        textView4.setTextColor(-1);
		textView4.setGravity(Gravity.CENTER);
		
		TextView textView2 = new TextView(this);
		textView2.setText(Html.fromHtml("<font face=> Layout by Bad modder [BAD SRC] </font>"));
		textView2.setTextSize(10.0f);
        textView2.setTextColor(-1);
		textView2.setGravity(Gravity.CENTER);
		
	
        rootFrame.addView(mRootContainer);
        mRootContainer.addView(mCollapsed);
        mRootContainer.addView(mExpanded);
        mCollapsed.addView(BadLogo);
		mExpanded.addView(titleText);
        titleText.addView(textView4);
		titleText.addView(textView2);	
        mExpanded.addView(scrollView);    
		scrollView.addView(patches);
        mExpanded.addView(relativeLayout);
        mFloatingView = rootFrame;
		
        if (Build.VERSION.SDK_INT >= 26) {
            params = new WindowManager.LayoutParams(-2, -2, 2038, 8, -3);
        } else {
            params = new WindowManager.LayoutParams(-2, -2, 2002, 8, -3);
        }
        WindowManager.LayoutParams layoutParams4 = params;
        layoutParams4.gravity = 51;
        layoutParams4.x = 0;
        layoutParams4.y = 100;
        mWindowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        mWindowManager.addView(mFloatingView, params);

        RelativeLayout relativeLayout2 = mCollapsed;
        LinearLayout linearLayout = mExpanded;
        mFloatingView.setOnTouchListener(onTouchListener());
        startimage.setOnTouchListener(onTouchListener());
        initMenuButton(relativeLayout2, linearLayout);

    }

    private View.OnTouchListener onTouchListener() {
        return new View.OnTouchListener() {
            final View collapsedView = mCollapsed;
            final View expandedView = mExpanded;
            private float initialTouchX;
            private float initialTouchY;
            private int initialX;
            private int initialY;

            public boolean onTouch(View view, MotionEvent motionEvent) {
                switch (motionEvent.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = motionEvent.getRawX();
                        initialTouchY = motionEvent.getRawY();
                        return true;
                    case MotionEvent.ACTION_UP:
                        int rawX = (int) (motionEvent.getRawX() - initialTouchX);
                        int rawY = (int) (motionEvent.getRawY() - initialTouchY);

                        //The check for Xdiff <10 && YDiff< 10 because sometime elements moves a little while clicking.
                        //So that is click event.
                        if (rawX < 10 && rawY < 10 && isViewCollapsed()) {
                            //When user clicks on the image view of the collapsed layout,
                            //visibility of the collapsed layout will be changed to "View.GONE"
                            //and expanded view will become visible.
                            collapsedView.setVisibility(View.GONE);
                            expandedView.setVisibility(View.VISIBLE);
                            
//Toast.makeText(FloatingModMenuService.this, Html.fromHtml(Toast()), Toast.LENGTH_SHORT).show();
                            Toast.makeText(LauncherActivity.this, Html.fromHtml("MGA - ZG"), Toast.LENGTH_SHORT).show();
                        }
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        //Calculate the X and Y coordinates of the view.
                        params.x = initialX + ((int) (motionEvent.getRawX() - initialTouchX));
                        params.y = initialY + ((int) (motionEvent.getRawY() - initialTouchY));

                        //Update the layout with new X & Y coordinate
                        mWindowManager.updateViewLayout(mFloatingView, params);
                        return true;
                    default:
                        return false;
                }
            }
        };
    }

	private boolean hide = false;

	//Initialize event handlers for buttons, etc.
    private void initMenuButton(final View view2, final View view3) {
        startimage.setOnClickListener(new View.OnClickListener() {
				public void onClick(View view) {
					view2.setVisibility(View.GONE);
					view3.setVisibility(View.VISIBLE);
				}
			});
        logs.setOnClickListener(new View.OnClickListener() {
				public void onClick(View view) {
					if (hide) {
						view2.setVisibility(View.VISIBLE);
						view2.setAlpha(0);
						view3.setVisibility(View.GONE);

					} else {
						view2.setVisibility(View.VISIBLE);
						view2.setAlpha(0.95f);
						view3.setVisibility(View.GONE);
					}
				}
			});
    }

    private void CreateMenuList() {
        String[] listFT = getFeatureListttttttttt();
        for (int i = 0; i < listFT.length; i++) {
            final int feature = i;
            String str = listFT[i];
            if (str.contains("TG_")) {//____aim

                addSwitchX(str.replace("TG_", ""), new InterfaceBool() {
						public void OnWrite(boolean z) {
							Changes(feature, 0);
						}
					});
		
			} else if (str.contains("SBP_")) {//_______All
                String[] split = str.split("_");
                addSeekBar(split[1], Integer.parseInt(split[2]), Integer.parseInt(split[3]), new InterfaceInt() {
						public void OnWrite(int i) {
							Changes(feature, i);
						}
					});
            } else if (str.contains("SB_")) {
                String[] split = str.split("_");
                addSeekBarSpot(split[1], Integer.parseInt(split[2]), Integer.parseInt(split[3]), new InterfaceInt() {
						public void OnWrite(int i) {
							Changes(feature, i);
						}
					});
            
			} else if (str.contains("CT_")) {
                addCategory(str.replace("CT_", ""));     
          
			}
		}
	}

    private TextView textView2;
    private String featureNameExt;
    private int featureNum;
    private EditTextValue txtValue;

    public class EditTextValue {
        private int val;

        public void setValue(int i) {
            val = i;
        }

        public int getValue() {
            return val;
        }
    }

    private void addTextField(final String featureName, final int feature, final InterfaceInt interInt) {
        RelativeLayout relativeLayout2 = new RelativeLayout(this);
        relativeLayout2.setLayoutParams(new RelativeLayout.LayoutParams(-2, -1));
        relativeLayout2.setPadding(10, 5, 10, 5);
        relativeLayout2.setVerticalGravity(16);

        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams.topMargin = 10;

        final TextView textView = new TextView(this);
        textView.setText(Html.fromHtml("<font face='roboto'>" + featureName + ": <font color='#0000FF'>Not set</font></font>"));
        textView.setTextColor(Color.parseColor("#0000FF"));
        textView.setLayoutParams(layoutParams);

        final TextView textViewRem = new TextView(this);
        textViewRem.setText("");

        final EditTextValue edittextval = new EditTextValue();

        RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams2.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);

        Button button2 = new Button(this);
        button2.setLayoutParams(layoutParams2);
        button2.setBackgroundColor(Color.parseColor("#000FFF"));
        button2.setText("SET");
        button2.setTextColor(Color.parseColor("#000FFF"));
        button2.setGravity(17);
        button2.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					alert.show();
					textView2 = textView;
					featureNum = feature;
					featureNameExt = featureName;
					txtValue = edittextval;

					edittextvalue.setText(String.valueOf(edittextval.getValue()));
				}
			});

        relativeLayout2.addView(textView);
        relativeLayout2.addView(button2);
        patches.addView(relativeLayout2);
    }

    private void initAlertDiag() {
        LinearLayout linearLayout1 = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        linearLayout1.setPadding(10, 5, 0, 5);
        linearLayout1.setOrientation(LinearLayout.VERTICAL);
        linearLayout1.setGravity(17);
        linearLayout1.setLayoutParams(layoutParams);
        linearLayout1.setBackgroundColor(Color.parseColor("BLACK"));

        int i = Build.VERSION.SDK_INT >= 26 ? 2038 : 2002;
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        linearLayout.setBackgroundColor(Color.parseColor("BLACK"));
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        FrameLayout frameLayout = new FrameLayout(this);
        frameLayout.setLayoutParams(new FrameLayout.LayoutParams(-2, -2));
        frameLayout.addView(linearLayout);

        final TextView textView = new TextView(this);
        textView.setText(Html.fromHtml("<font face='roboto'>Tap OK to apply changes. Tap outside to cancel</font>"));
        textView.setTextColor(Color.parseColor("#000FFF"));
        textView.setLayoutParams(layoutParams);

        edittextvalue = new EditText(this);
        edittextvalue.setLayoutParams(layoutParams);
        edittextvalue.setMaxLines(1);
        edittextvalue.setWidth(convertDipToPixels(300));
        edittextvalue.setTextColor(Color.parseColor("BLACK"));
        edittextvalue.setTextSize(13.0f);
        edittextvalue.setHintTextColor(Color.parseColor("BLACK"));
        edittextvalue.setInputType(InputType.TYPE_CLASS_NUMBER);
        edittextvalue.setKeyListener(DigitsKeyListener.getInstance("0123456789-"));

        InputFilter[] FilterArray = new InputFilter[1];
        FilterArray[0] = new InputFilter.LengthFilter(10);
        edittextvalue.setFilters(FilterArray);

        Button button = new Button(this);
        button.setBackgroundColor(Color.parseColor("BLACK"));
        button.setTextColor(Color.parseColor("BLACK"));
        button.setText("OK");
        button.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					Changes(featureNum, Integer.parseInt(edittextvalue.getText().toString()));
					txtValue.setValue(Integer.parseInt(edittextvalue.getText().toString()));
					textView2.setText(Html.fromHtml("<font face='roboto'>" + featureNameExt + ": <font color='BLACK'>" + edittextvalue.getText().toString() + "</font></font>"));
					alert.dismiss();
					playSound(Uri.fromFile(new File(cacheDir + "Select.ogg")));
					//interStr.OnWrite(editText.getText().toString());
				}
			});

        alert = new AlertDialog.Builder(this, 2).create();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            Objects.requireNonNull(alert.getWindow()).setType(i);
        }
        linearLayout1.addView(textView);
        linearLayout1.addView(edittextvalue);
        linearLayout1.addView(button);
        alert.setView(linearLayout1);
    }

    
    private void addCategory(String text) {
        TextView textView = new TextView(this);
        textView.setBackgroundColor(0);
        textView.setText(text);
        textView.setGravity(17);
        textView.setTextSize(14.0f);
        textView.setTextColor(-1);
        textView.setTypeface(null, Typeface.BOLD);
        textView.setPadding(10, 5, 0, 5);
        patches.addView(textView);
    }

    
    private void addSwitchX(String str, final InterfaceBool sw) {
        final Switch switchX = new Switch(this);
        switchX.setText(Html.fromHtml("<font face=><b>" + str + "</b></font>"));
        switchX.setTextColor(Color.parseColor("#FFFFFFFF"));
        switchX.setPadding(10, 8, 0, 8);
		switchX.getTrackDrawable().setColorFilter(Color.parseColor("#FFFFFF"), PorterDuff.Mode.SRC_IN);
        switchX.getThumbDrawable().setColorFilter(Color.parseColor("WHITE"), PorterDuff.Mode.SRC_IN);

        switchX.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                    if (z) {
                        switchX.setBackgroundColor(Color.parseColor("#00000000"));

                        switchX.getTrackDrawable().setColorFilter(Color.BLUE, PorterDuff.Mode.SRC_IN);
                        switchX.getThumbDrawable().setColorFilter(Color.BLUE, PorterDuff.Mode.SRC_IN);
						
                    } else {
                        switchX.setBackgroundColor(Color.parseColor("#00000000"));

                        switchX.getTrackDrawable().setColorFilter(Color.parseColor("#FFFFFF"), PorterDuff.Mode.SRC_IN);
                        switchX.getThumbDrawable().setColorFilter(Color.parseColor("WHITE"), PorterDuff.Mode.SRC_IN);
                    }
                    sw.OnWrite(z);
                }
            });

        this.patches.addView(switchX);
    }
	
    
    private void addSeekBarSpot(final String feature, final int prog, int max, final InterfaceInt interInt) {
        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        linearLayout.setPadding(10, 5, 0, 5);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.setGravity(17);
		linearLayout.setBackgroundColor(Color.parseColor("#000000"));
		linearLayout.getBackground().setAlpha(1);
        linearLayout.setLayoutParams(layoutParams);
        final TextView textView = new TextView(this);
        textView.setText(Html.fromHtml("<font face=>" + "Aim Target" + ": " + "DEACTIVATED" + "</font>"));
        textView.setTextColor(Color.parseColor("#ffffff"));
        SeekBar seekBar = new SeekBar(this);
        seekBar.setPadding(20, 10, 35, 10);
        seekBar.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        seekBar.setMax(max);
        seekBar.setProgress(prog);
		seekBar.getProgressDrawable().setColorFilter(Color.parseColor("WHITE"), PorterDuff.Mode.MULTIPLY);
        seekBar.getThumb().setColorFilter(Color.parseColor("#FFFFFF"), PorterDuff.Mode.SRC_IN);
        final TextView textView2 = textView;
        final SeekBar seekBar2 = seekBar;
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
				public void onStartTrackingTouch(SeekBar seekBar2) {
				}

				public void onStopTrackingTouch(SeekBar seekBar2) {
				}

				int l;

				public void onProgressChanged(SeekBar seekBar2, int i, boolean z) {
					if (i == 0) {
						seekBar2.setProgress(i);
						interInt.OnWrite(i);
						TextView textView = textView2;
						textView.setText(Html.fromHtml("<font face=>" +  "Aim Target"  + ": " + "DEACTIVATED" + "</font>"));
					} else if (i == 1) {
						seekBar2.setProgress(i);
						interInt.OnWrite(i);
						TextView textView = textView2;
						textView.setText(Html.fromHtml("<font face=>" +  "Aim Target"  + ": " + "Cabeça" + "</font>"));
					} else if (i == 2) {
						seekBar2.setProgress(i);
						interInt.OnWrite(i);
						TextView textView = textView2;
						textView.setText(Html.fromHtml("<font face=>" +  "Aim Target"  + ": " + "Corpo" + "</font>"));
					} else if (i == 3) {
						seekBar2.setProgress(i);
						interInt.OnWrite(i);
						TextView textView = textView2;
						textView.setText(Html.fromHtml("<font face=>" +  "Aim Target"  + ": " + "Pé" + "</font>"));
					}
					interInt.OnWrite(i);
				}
			});

        linearLayout.addView(textView);
        linearLayout.addView(seekBar);
        patches.addView(linearLayout);
    }

	private void addSwitch(String str, final InterfaceBool sw) {
        final Switch switchR = new Switch(this);
        switchR.setText(Html.fromHtml("<font face=><b>" + str + "</b></font>"));
        switchR.setTextColor(Color.parseColor("#FFFFFFFF"));
        switchR.setPadding(10, 8, 0, 8);
		switchR.getTrackDrawable().setColorFilter(Color.parseColor("#FFFFFF"), PorterDuff.Mode.SRC_IN);
        switchR.getThumbDrawable().setColorFilter(Color.parseColor("WHITE"), PorterDuff.Mode.SRC_IN);

        switchR.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                    if (z) {
                        switchR.setBackgroundColor(Color.parseColor("#00000000"));

                        switchR.getTrackDrawable().setColorFilter(Color.parseColor("#ff0000"), PorterDuff.Mode.SRC_IN);
                        switchR.getThumbDrawable().setColorFilter(Color.parseColor("#FF0000"), PorterDuff.Mode.SRC_IN);

                    } else {
                        switchR.setBackgroundColor(Color.parseColor("#00000000"));

                        switchR.getTrackDrawable().setColorFilter(Color.parseColor("#FFFFFF"), PorterDuff.Mode.SRC_IN);
                        switchR.getThumbDrawable().setColorFilter(Color.parseColor("WHITE"), PorterDuff.Mode.SRC_IN);
                    }
                    sw.OnWrite(z);
                }
            });

        scrollView3.addView(switchR);
    }
	
	private void addSeekBar(final String feature, final int prog, int max, final InterfaceInt interInt) {
        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        linearLayout.setPadding(10, 5, 0, 5);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.setGravity(17);
		linearLayout.setBackgroundColor(Color.parseColor("#000000"));
		linearLayout.getBackground().setAlpha(1);
        linearLayout.setLayoutParams(layoutParams);
        final TextView textView = new TextView(this);
        textView.setText(Html.fromHtml("<font face=><b>" + feature + ": <font color='#FFFFFF'>" + "DEACTIVATED" + "</font>"));
        textView.setTextColor(Color.parseColor("#ffffff"));
        SeekBar seekBar = new SeekBar(this);
        seekBar.setPadding(20, 10, 35, 10);
        seekBar.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        seekBar.setMax(max);
        seekBar.setProgress(prog);
		seekBar.getProgressDrawable().setColorFilter(Color.parseColor("WHITE"), PorterDuff.Mode.MULTIPLY);
        seekBar.getThumb().setColorFilter(Color.parseColor("#FFFFFF"), PorterDuff.Mode.SRC_IN);
        final TextView textView2 = textView;
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
				public void onStartTrackingTouch(SeekBar seekBar) {
				}

				public void onStopTrackingTouch(SeekBar seekBar) {
				}

				int l;

				public void onProgressChanged(SeekBar seekBar, int i, boolean z) {


					if (i == 0) {
						seekBar.setProgress(i);
						interInt.OnWrite(i);
						TextView textView = textView2;
						textView.setText(Html.fromHtml("<font face=><b>" + feature + ": <font color='#FFFFFF'>" + "DEACTIVATED" + "</font>"));
						return;
					}
					interInt.OnWrite(i);
					textView.setText(Html.fromHtml("<font face=><b>" + feature + ": <font color='#FFFFFF'>" + i + "</font>"));
				}
			});

        linearLayout.addView(textView);
        linearLayout.addView(seekBar);
        patches.addView(linearLayout);
    }
	
    boolean delayed;

    public void playSound(Uri uri) {
        if (EnableSounds()) {
            if (!delayed) {
                delayed = true;
                if (FXPlayer != null) {
                    FXPlayer.stop();
                    FXPlayer.release();
                }
                FXPlayer = MediaPlayer.create(this, uri);
                if (FXPlayer != null)
				//Volume reduced so sounds are not too loud
                    FXPlayer.setVolume(0.5f, 0.5f);
                FXPlayer.start();

                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
						@Override
						public void run() {
							delayed = false;
						}
					}, 100);
            }
        }
    }

    public boolean isViewCollapsed() {
        return mFloatingView == null || mCollapsed.getVisibility() == View.VISIBLE;
    }

    //For our image a little converter
    private int convertDipToPixels(int i) {
        return (int) ((((float) i) * getResources().getDisplayMetrics().density) + 0.5f);
    }

    private int dp(int i) {
        return (int) TypedValue.applyDimension(1, (float) i, getResources().getDisplayMetrics());
    }

    //Destroy our View
    public void onDestroy() {
        super.onDestroy();

        if (view2 != null) {
            this.mWindowManager.removeView(view2);
        }
        View view = mFloatingView;
        if (view != null) {
            mWindowManager.removeView(view);
        }
    }

    // checking if any network connection / internet available

    // calling our AsyncTask Function that will do thee thing on fetching data from out host file

    // this is the checking one, this will draw our menu if it's license still valid or active

    //Check if we are still in the game. If now our Menu and Menu button will dissapear
    private boolean isNotInGame() {
        RunningAppProcessInfo runningAppProcessInfo = new RunningAppProcessInfo();
        ActivityManager.getMyMemoryState(runningAppProcessInfo);
        return runningAppProcessInfo.importance != 100;
    }

    //Same as above so it wont crash in the background and therefore use alot of Battery life


    private interface InterfaceBtn {
        void OnWrite();
    }

    private interface InterfaceInt {
        void OnWrite(int i);
    }

    private interface InterfaceBool {
        void OnWrite(boolean z);
    }

    private interface InterfaceStr {
        void OnWrite(String s);
    }
}

