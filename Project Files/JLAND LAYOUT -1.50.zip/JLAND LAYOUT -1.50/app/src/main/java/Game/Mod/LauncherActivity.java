/*THIS SOURCE BY [BAD SOURCE✓]_______["BAD MODDER:MGA-ZG"]*/
package Game.Mod;
import android.annotation.TargetApi;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.app.AlertDialog;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.GradientDrawable;
import android.graphics.PixelFormat;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import java.io.IOException;
import android.text.Html;
import android.text.InputFilter;
import android.text.InputType;
import android.text.method.DigitsKeyListener;
import android.util.Base64;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import Game.Mod.ESPView;
import java.io.File;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import java.io.IOException;
import android.content.res.AssetManager;
import static android.widget.RelativeLayout.ALIGN_PARENT_RIGHT;
import static android.view.ViewGroup.LayoutParams.WRAP_CONTENT;
import static android.view.ViewGroup.LayoutParams.MATCH_PARENT;
import static android.widget.RelativeLayout.ALIGN_PARENT_LEFT;
import android.net.ConnectivityManager;
import java.net.HttpURLConnection;
import java.io.BufferedReader;
import java.io.InputStream;
import java.net.URL;
import android.os.AsyncTask;
import android.annotation.SuppressLint;
import java.io.InputStreamReader;
import android.text.TextUtils;

public class LauncherActivity extends Service {
	final int TEXT_COLOR = Color.parseColor("#000000");
    final int TEXT_COLOR_2 = Color.parseColor("#FFFFFF");
    final int BTN_COLOR = Color.parseColor("#000000");
    final int MENU_BG_COLOR = Color.parseColor("#000000"); //#AARRGGBB
    final int MENU_FEATURE_BG_COLOR = Color.parseColor("#000000"); //#AARRGGBB
    final int MENU_WIDTH = 220;
    final int MENU_HEIGHT = 190;
    final float MENU_CORNER = 20f;
    final int ICON_SIZE = 50;
    final float ICON_ALPHA = 0.7f; //Transparent
    public View mFloatingView;
	private Button youtube;
    private Button close;
    private LinearLayout mButtonPanel;
    public RelativeLayout mCollapsed;
    public LinearLayout mExpanded;
    private RelativeLayout mRootContainer;
    public WindowManager mWindowManager;
    public WindowManager.LayoutParams params;
    private LinearLayout patches;
    private FrameLayout rootFrame;
    private ImageView startimage;
    private LinearLayout view1;
    private LinearLayout view2;
	private LinearLayout Btns;
    private LinearLayout Btns2;
    LinearLayout.LayoutParams scrlLLExpanded, scrlLL;
	ScrollView scrollView;
    private ImageView ffid;
    private ImageView ffidXX;
    private ImageView phs;
    private LinearLayout patches2;
	private ESPView overlayView;
	public static native void DrawOn(ESPView espView, Canvas canvas);
	private WindowManager.LayoutParams espParams;
    private static final String TAG = "Mod Menu";
    public static native String Toast();
    private native String Icon();
    private native String Title();
    private native String Heading();
    private native boolean EnableSounds();
    private native String Iconps();
    private native int IconSize();
    public native void Changes(int feature, int value);
    private native String[] getFeatureList();
	private boolean Launcheractivity = true;
    private TextView addText(String string) {
        TextView textView = new TextView(this);
        textView.setText((CharSequence)string);
        textView.setTextColor(Color.WHITE);
        textView.setTextSize(13.0f);
        textView.setTypeface(null, Typeface.BOLD);
        textView.setPadding(5, 0, 0, 5);
        textView.setGravity(Gravity.LEFT);
        return textView;
	}
    private static String getArch(String string) {
        if (string.contains((CharSequence)"lib/arm64")) {
            return "arm64";
        }
        if (string.contains((CharSequence)"lib/arm")) {
            return "armv7";
        }
        if (string.contains((CharSequence)"lib/x86")) {
            return "x86";
        }
        return "";
    }
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    public int onStartCommand(Intent intent, int i, int i2) {
        return Service.START_NOT_STICKY;
    }
	private int getLayoutType() {
        if (Build.VERSION.SDK_INT >= 26) {
            return 2038;
        }
        if (Build.VERSION.SDK_INT >= 24) {
            return 2002;
        }
        if (Build.VERSION.SDK_INT >= 23) {
            return 2005;
        }
        return 2003;
    }
	private void DrawCanvas() {
        WindowManager.LayoutParams layoutParams;
        this.espParams = layoutParams = new WindowManager.LayoutParams(-1, -1, this.getLayoutType(), 56, -3);
        layoutParams.gravity = 8388659;
        this.espParams.x = 0;
        this.espParams.y = 0;
        this.mWindowManager.addView((View)this.overlayView, (ViewGroup.LayoutParams)this.espParams);
    }

	//When this Class is called the code in this function will be executed
	@Override
    public void onCreate() {
		super.onCreate();
        //A little message for the user when he opens the app
        //Toast.makeText(this, Toast(), Toast.LENGTH_LONG).show();
        //Init Lib

        // When you change the lib name, change also on Android.mk file
        // Both must have same name
        System.loadLibrary("hook");
		this.overlayView = new ESPView((Context)this);
        try {
            this.initFloating();
		} catch (IOException e) {}
        DrawCanvas();
		CreateMenuList();
        final Handler handler = new Handler();
        handler.post(new Runnable() {
                public void run() {
                    handler.postDelayed(this, 1000);
                }
            });
    }

    //Here we write the code for our Menu

    private void initFloating() throws IOException {
        ImageView imageView;
        rootFrame = new FrameLayout(getBaseContext()); // Global markup
        mRootContainer = new RelativeLayout(getBaseContext()); // Markup on which two markups of the icon and the menu itself will be placed
        mCollapsed = new RelativeLayout(getBaseContext()); // Markup of the icon (when the menu is minimized)
        mExpanded = new LinearLayout(getBaseContext()); // Menu markup (when the menu is expanded)
        view1 = new LinearLayout(getBaseContext());
        patches = new LinearLayout(getBaseContext());
        view2 = new LinearLayout(getBaseContext());
		Btns = new LinearLayout(getBaseContext());
        Btns2 = new LinearLayout(getBaseContext());
		mButtonPanel = new LinearLayout(getBaseContext()); // Layout of option buttons (when the menu is expanded)
		AssetManager assetManager = getAssets();
        patches2 = new LinearLayout(getBaseContext());
		
		rootFrame.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        mCollapsed.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        mCollapsed.setVisibility(View.VISIBLE);
        rootFrame.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        mRootContainer.setLayoutParams(new FrameLayout.LayoutParams(-2, -2));
        mCollapsed.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        mCollapsed.setVisibility(View.VISIBLE);
		
		view1.setLayoutParams(new LinearLayout.LayoutParams(-1, 1));
		view1.setBackgroundColor(-1);
		
		view2.setLayoutParams(new LinearLayout.LayoutParams(-1, 1));
		view2.setBackgroundColor(-1);
		
        startimage = new ImageView(getBaseContext());
        startimage.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        int applyDimension = (int) TypedValue.applyDimension(1, (float) IconSize(), getResources().getDisplayMetrics());
        startimage.getLayoutParams().height = applyDimension;
        startimage.getLayoutParams().width = applyDimension;
        startimage.requestLayout();
        startimage.setScaleType(ImageView.ScaleType.FIT_XY);
        byte[] decode = Base64.decode(Icon(), 0);
        startimage.setImageBitmap(BitmapFactory.decodeByteArray(decode, 0, decode.length));
        ((ViewGroup.MarginLayoutParams) startimage.getLayoutParams()).topMargin = convertDipToPixels(10);
		
        
        
        this.ffid = new ImageView(getBaseContext());
        RelativeLayout.LayoutParams ffid_LayoutParams = new RelativeLayout.LayoutParams(-0, -2);
        this.ffid.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        ffid_LayoutParams.addRule(0, -0);
        ffid_LayoutParams.setMarginEnd((int) ((0.0f) + 0.0f));
        this.ffid.getLayoutParams().height = dp(65);
        this.ffid.getLayoutParams().width = dp(65);
        this.ffid.requestLayout();
        this.ffid.setPadding(0, 0, 0, 0);
        this.ffid.setTranslationX(0);
        this.ffid.setTranslationY(0);
        InputStream inputStream_close2 = null;
        try {
            inputStream_close2 = assetManager.open("icon.png");
        } catch (IOException e) {
            e.printStackTrace();
        }
        Drawable ic_close2 = Drawable.createFromStream(inputStream_close2, null);
        ffid.setImageDrawable(ic_close2);
        ((ViewGroup.MarginLayoutParams) this.ffid.getLayoutParams()).leftMargin = convertDipToPixels(0);
        
  
        mExpanded.setVisibility(View.GONE); 
        mExpanded.setGravity(17);
        mExpanded.setOrientation(LinearLayout.VERTICAL);
		mExpanded.setBackgroundColor(Color.parseColor("#86000000"));
		mExpanded.setLayoutParams(new LinearLayout.LayoutParams(dp(MENU_WIDTH), WRAP_CONTENT));
        
		scrollView = new ScrollView(getBaseContext());
        scrlLL = new LinearLayout.LayoutParams(MATCH_PARENT, dp(MENU_HEIGHT));
        scrlLLExpanded = new LinearLayout.LayoutParams(mExpanded.getLayoutParams());
        scrlLLExpanded.weight = 1.0f;
		scrollView.setPadding(1,0,1,0);
		scrollView.setLayoutParams(Launcheractivity ? scrlLLExpanded : scrlLL);
		
        patches.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        patches.setOrientation(LinearLayout.VERTICAL);
        patches2 = new LinearLayout(this);
        patches2.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        patches2.setOrientation(1);
		patches2.setVisibility(View.GONE);
        mButtonPanel.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));

        
        
        phs = new ImageView(this);
        RelativeLayout.LayoutParams phs_LayoutParams = new RelativeLayout.LayoutParams(-2, -2);
        phs.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        phs_LayoutParams.addRule(21, -1);
        phs_LayoutParams.setMarginEnd((int) ((275.0f) + 0.0f));
        phs.getLayoutParams().height = dp(48);
        phs.getLayoutParams().width = dp(48);
        phs.requestLayout();
        phs.setScaleType(ImageView.ScaleType.FIT_START);
        byte[] decode3 = Base64.decode(Iconps(), 4);
        phs.setImageBitmap(BitmapFactory.decodeByteArray(decode3, 0, decode3.length));
        ((ViewGroup.MarginLayoutParams) this.phs.getLayoutParams()).leftMargin = convertDipToPixels(5);
		
//______TITLE [BY BAD MODDER]/[MGA-ZG]______\\
		
        RelativeLayout titleText = new RelativeLayout(this);
		titleText.setVerticalGravity(16);
		
        TextView textTitle = new TextView(this);
		textTitle.setText("JLAND");
		textTitle.setShadowLayer(10.0f,0.0f,0.0f,Color.BLUE);
        textTitle.setTextColor(-1);
		textTitle.setTextSize(30.0f);
		textTitle.setGravity(Gravity.CENTER);
		
		RelativeLayout.LayoutParams rl = new RelativeLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT);
        rl.addRule(RelativeLayout.CENTER_HORIZONTAL);
        textTitle.setLayoutParams(rl);	
		
		TextView textView2 = new TextView(this);
		textView2.setText("🔐 Bad Modder[1.50.LayOut]");
		textView2.setTextSize(13.0f);
        textView2.setTextColor(-1);
		textView2.setGravity(Gravity.CENTER);
		
		TextView heading = new TextView(this);
        heading.setEllipsize(TextUtils.TruncateAt.MARQUEE);
        heading.setMarqueeRepeatLimit(-1);
        heading.setSingleLine(true);
        heading.setSelected(true);
        heading.setTextColor(-256);
        heading.setTextSize(10.0f);
        heading.setGravity(Gravity.CENTER);
        heading.setPadding(5, 0, 5, 5);	
		heading.setText(Html.fromHtml("<b><marquee><p style=\"font-size:20\"><p style=\"-256;\">Modded by MGA-ZG/BAD MODDER</p> | Telegram : https://t.me/MGA_ZGYT| ModMenu Free Fire World Series V.0.00.X<p style=\"-65536;\">© BAD SOURCE</p></marquee></b>"));
		
		textTitle.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {

                    mCollapsed.setVisibility(0);
                    mCollapsed.setAlpha(0.95f);
                    mExpanded.setVisibility(8);
                }
            });
        rootFrame.addView(mRootContainer);
        mRootContainer.addView(mCollapsed);
        mRootContainer.addView(mExpanded);
        mCollapsed.addView(ffid);
        mExpanded.addView(titleText);
        titleText.addView(textTitle);
		mExpanded.addView(textView2);
		mExpanded.addView(heading);
        mExpanded.addView(scrollView);
        scrollView.addView(patches);
        mFloatingView = rootFrame;
		

		if (Build.VERSION.SDK_INT >= 26) {
            params = new WindowManager.LayoutParams(-2, -2, 2038, 8, -3);
        } else {
            params = new WindowManager.LayoutParams(-2, -2, 2002, 8, -3);
        }
        WindowManager.LayoutParams layoutParams4 = params;
        layoutParams4.gravity = 51;
        layoutParams4.x = 0;
        layoutParams4.y = 100;
        mWindowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        mWindowManager.addView(mFloatingView, params);

        RelativeLayout relativeLayout2 = mCollapsed;
        LinearLayout linearLayout = mExpanded;
        mFloatingView.setOnTouchListener(onTouchListener());
        startimage.setOnTouchListener(onTouchListener());
        initMenuButton(relativeLayout2, linearLayout);

    }

    private View.OnTouchListener onTouchListener() {
        return new View.OnTouchListener() {
            final View collapsedView = mCollapsed;
            final View expandedView = mExpanded;
            private float initialTouchX;
            private float initialTouchY;
            private int initialX;
            private int initialY;

            public boolean onTouch(View view, MotionEvent motionEvent) {
                switch (motionEvent.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = motionEvent.getRawX();
                        initialTouchY = motionEvent.getRawY();
                        return true;
                    case MotionEvent.ACTION_UP:
                        int rawX = (int) (motionEvent.getRawX() - initialTouchX);
                        int rawY = (int) (motionEvent.getRawY() - initialTouchY);

                        //The check for Xdiff <10 && YDiff< 10 because sometime elements moves a little while clicking.
                        //So that is click event.
                        if (rawX < 10 && rawY < 10 && isViewCollapsed()) {
                            //When user clicks on the image view of the collapsed layout,
                            //visibility of the collapsed layout will be changed to "View.GONE"
                            //and expanded view will become visible.
                            collapsedView.setVisibility(View.GONE);
                            expandedView.setVisibility(View.VISIBLE);

                            //Toast.makeText(FloatingModMenuService.this, Html.fromHtml(Toast()), Toast.LENGTH_SHORT).show();
                        }
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        //Calculate the X and Y coordinates of the view.
                        params.x = initialX + ((int) (motionEvent.getRawX() - initialTouchX));
                        params.y = initialY + ((int) (motionEvent.getRawY() - initialTouchY));

                        //Update the layout with new X & Y coordinate
                        mWindowManager.updateViewLayout(mFloatingView, params);
                        return true;
                    default:
                        return false;
                }
            }
        };
    }


	private boolean hide = false;

	//Initialize event handlers for buttons, etc.
    private void initMenuButton(final View view2, final View view3) {
        startimage.setOnClickListener(new View.OnClickListener() {
				public void onClick(View view) {
					view2.setVisibility(View.GONE);
					view3.setVisibility(View.VISIBLE);
				}
			});
		
    }


    private void CreateMenuList() {
        String[] listFT = getFeatureList();
        for (int i = 0; i < listFT.length; i++) {
            final int feature = i;
            String str = listFT[i];
            if (str.contains("TG_")) {
				addButton(((str.replace("TG_", ""))), new InterfaceBtn() {
						public void OnWrite() {
							Changes(feature, 0);
						}
                    });
            } else if (str.contains("SeekBar_")) {
                String[] split = str.split("_");
                addSeekBar(split[1], Integer.parseInt(split[2]), Integer.parseInt(split[3]), new InterfaceInt() {
                        public void OnWrite(int i) {
                            Changes(feature, i);
                        }
                    });
            } else if (str.contains("SeekBarSpot_")) {
                String[] split = str.split("_");
                addSeekBarSpot(split[1], Integer.parseInt(split[2]), Integer.parseInt(split[3]), new InterfaceInt() {
                        public void OnWrite(int i) {
                            Changes(feature, i);
                        }
                    });
			} else if (str.contains("Color_")) {
                String[] split = str.split("_");
                addEsp(split[1], Integer.parseInt(split[2]), Integer.parseInt(split[3]), new InterfaceInt() {
                        public void OnWrite(int i) {
                            Changes(feature, i);
                        }
                    });
                  }
                }
              }
    private TextView textView2;
    private String featureNameExt;
    private int featureNum;
    private EditTextValue txtValue;

    public class EditTextValue {
        private int val;

        public void setValue(int i) {
            val = i;
        }

        public int getValue() {
            return val;
        }
    }

    
	public void addButton(String feature, final InterfaceBtn interfaceBtn) {
        final Button button = new Button(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(dp(205), dp(38));
        layoutParams.setMargins(dp(5), dp(1), dp(5), dp(1));
        button.setLayoutParams(layoutParams);
        button.setTextSize(16.0f);
        button.setTextColor(-1);
        button.setGravity(17);
		button.setShadowLayer(10.0f,0.0f,0.0f,Color.RED);
        GradientDrawable gradienteOff = new GradientDrawable();
        gradienteOff.setColor(Color.parseColor("#00000000"));
        gradienteOff.setCornerRadii(new float[]{(float) dp(3), (float) dp(3), (float) dp(3), (float) dp(3), (float) dp(3), (float) dp(3), (float) dp(3), (float) dp(3)});
        gradienteOff.setStroke(dp(3), Color.parseColor("#00000000"));
        if (Build.VERSION.SDK_INT >= 21) {
            button.setElevation(90.0f);
        }
        final GradientDrawable gradientDrawable = gradienteOff;
        button.setBackground(gradienteOff);
        button.setTypeface((Typeface) null, 1);
        if (feature.contains("")) {
            feature = feature.replace("", "");
            button.setText(feature + ": OFF");
            final String feature2 = feature;

            button.setOnClickListener(new View.OnClickListener() {
                    private boolean isActive = true;

                    public void onClick(View v) {
                        interfaceBtn.OnWrite();
                        if (isActive) {
                            button.setText(feature2 + ": ON");
                            isActive = false;
							button.setShadowLayer(10.0f,0.0f,0.0f,Color.BLUE);
                            GradientDrawable gradienteOn = new GradientDrawable();
                            gradienteOn.setColor(Color.parseColor("#00000000"));
                            gradienteOn.setCornerRadii(new float[]{(float) dp(3), (float) dp(3), (float) dp(3), (float) dp(3), (float) dp(3), (float) dp(3), (float) dp(3), (float) dp(3)});
                            gradienteOn.setStroke(dp(3), Color.parseColor("#00000000"));
                            if (Build.VERSION.SDK_INT >= 21) {
                                button.setElevation(90.0f);
                            }
                            button.setBackground(gradienteOn);
                            return;
                        }
                        button.setText(feature2 + ": OFF");
                        isActive = true;
                        button.setBackground(gradientDrawable);
						button.setShadowLayer(10.0f,0.0f,0.0f,Color.RED);
                    }
                });
        } else {
            button.setText(feature);

            final String feature2 = feature;
            button.setBackground(gradientDrawable);
            button.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        interfaceBtn.OnWrite();

                    }
                });
        }
        patches.addView(button);
    }
	
	
	private void addSeekBar(final String feature, final int prog, int max, final InterfaceInt interInt) {
        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        linearLayout.setPadding(5, 0, 0, 0);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.setGravity(Gravity.CENTER_HORIZONTAL);
        linearLayout.setLayoutParams(layoutParams);
        final TextView textView = new TextView(this);
        textView.setText(Html.fromHtml(feature + " : <font color='RED'>" + " OFF" + "</font>"));
        textView.setTextSize(16.0f);
		textView.setPadding(10, 0, 0, 0);
        textView.setTextColor(Color.WHITE);
		textView.setTypeface(null, Typeface.BOLD);
		textView.setShadowLayer(10.0f,0.0f,0.0f,Color.RED);
        SeekBar seekBar = new SeekBar(this);
		
		GradientDrawable seekbar = new GradientDrawable();
        seekbar.setShape(0);
        seekbar.setColor(Color.WHITE);
        seekBar.setPadding(25, 10, 35, 10);
        seekBar.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        seekBar.setMax(max);
        seekBar.setProgress(prog);
		seekBar.getProgressDrawable().setColorFilter(Color.LTGRAY, PorterDuff.Mode.SRC_IN);
		seekBar.getThumb().setColorFilter(Color.LTGRAY, PorterDuff.Mode.SRC_ATOP);
		final TextView textView2 = textView;
		seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                public void onStartTrackingTouch(SeekBar seekBar) {
				}
				public void onStopTrackingTouch(SeekBar seekBar) {
				}

                int l;

                public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                    if (i == 0) {
                        seekBar.setProgress(i);
                        interInt.OnWrite(i);
                        TextView textView = textView2;
						textView.setText(Html.fromHtml("<font face=>" + feature + " : <font color='RED'>" + "OFF" + "</font>"));
						textView.setShadowLayer(10.0f,0.0f,0.0f,Color.RED);
                        return;
                    }
                    interInt.OnWrite(i);
					textView.setText(Html.fromHtml("<font face=>" + feature + " : <font color='LTGRAY'>" + i + "</font>"));
					textView.setShadowLayer(10.0f,0.0f,0.0f,-16776961);
                }
            });

        linearLayout.addView(textView);
        linearLayout.addView(seekBar);     
        patches.addView(linearLayout);
    }

	
		
	private void addEsp(final String feature, final int prog, int max, final InterfaceInt interInt) {
        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        linearLayout.setPadding(5, 0, 0, 0);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.setGravity(Gravity.CENTER_HORIZONTAL);
        linearLayout.setLayoutParams(layoutParams);
        final TextView textView = new TextView(this);
        textView.setText(Html.fromHtml(feature + " : <font color='RED'>" + " OFF" + "</font>"));
        textView.setTextSize(16.0f);
		textView.setPadding(10, 0, 0, 0);
        textView.setTextColor(Color.WHITE);
		textView.setTypeface(null, Typeface.BOLD);
		textView.setShadowLayer(10.0f,0.0f,0.0f,Color.RED);
        SeekBar seekBar = new SeekBar(this);
		GradientDrawable seekbar = new GradientDrawable();
        seekbar.setShape(0);
        seekbar.setColor(Color.WHITE);
        seekbar.setColor(Color.parseColor("#ff0000"));
        seekBar.setPadding(25, 10, 35, 10);
        seekBar.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
		seekBar.getProgressDrawable().setColorFilter(Color.LTGRAY, PorterDuff.Mode.SRC_IN);
		seekBar.getThumb().setColorFilter(Color.LTGRAY, PorterDuff.Mode.SRC_ATOP);
		seekBar.setMax(max);
		seekBar.setProgress(prog);
		final TextView textView4 = textView;
		seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                public void onStartTrackingTouch(SeekBar seekBar) {
				}
				public void onStopTrackingTouch(SeekBar seekBar) {
				}

                int l;
                public void onProgressChanged(SeekBar seekBar2, int i, boolean z) {
                    if (i == 0) {
                        seekBar2.setProgress(i);
                        interInt.OnWrite(i);
                        TextView textView = textView4;
						textView.setShadowLayer(10.0f,0.0f,0.0f,Color.BLUE);
						textView.setText(Html.fromHtml("<font face=>" + feature + " : <font color='WHITE'>" + "Branco" + "</font>"));
                    } else if (i == 1) {
                        seekBar2.setProgress(i);
                        interInt.OnWrite(i);
                        TextView textView = textView4;
						textView.setShadowLayer(10.0f,0.0f,0.0f,Color.BLUE);
						textView.setText(Html.fromHtml("<font face=>" + feature + " : <font color='GREEN'>" + "Verde" + "</font>"));
                    } else if (i == 2) {
                        seekBar2.setProgress(i);
                        interInt.OnWrite(i);
                        TextView textView = textView4;
						textView.setShadowLayer(10.0f,0.0f,0.0f,Color.BLUE);
                        textView.setText(Html.fromHtml("<font face=>" + feature + ": <font color='Blue'>" + "Azul" + "</b></font>"));
                    } else if (i == 3) {
                        seekBar2.setProgress(i);
                        interInt.OnWrite(i);
                        TextView textView = textView4;
						textView.setShadowLayer(10.0f,0.0f,0.0f,Color.BLUE);
                        textView.setText(Html.fromHtml("<font face=>" + feature + ": <font color='Red'>" + "Vermelho" + "</b></font>"));
                        //(Html.fromHtml("<font face='monospace'><b>" + feature + ": <font color='#ffffff15'>" + "6m (Ghost)" + "</b></font>"));
					} else if (i == 4) {
                        seekBar2.setProgress(i);
                        interInt.OnWrite(i);
                        TextView textView = textView4;
                        textView.setText(Html.fromHtml("<font face=>" + feature + ": <font color='Yellow'>" + "Amarelo" + "</b></font>"));
						textView.setShadowLayer(10.0f,0.0f,0.0f,Color.BLUE);
					} else if (i == 5) {
                        seekBar2.setProgress(i);
                        interInt.OnWrite(i);
                        TextView textView = textView4;
                        textView.setText(Html.fromHtml("<font face=>" + feature + ": <font color='Cyan'>" + "Ciano" + "</b></font>"));
						textView.setShadowLayer(10.0f,0.0f,0.0f,Color.BLUE);
					} else if (i == 6) {
                        seekBar2.setProgress(i);
                        interInt.OnWrite(i);
                        TextView textView = textView4;
                        textView.setText(Html.fromHtml("<font face=>" + feature + ": <font color='Magenta'>" + "Rosa" + "</b></font>"));

						textView.setShadowLayer(10.0f,0.0f,0.0f,Color.BLUE);
                    }
                    interInt.OnWrite(i);
                }
            });

        this.patches.addView(textView);
        this.patches.addView(seekBar);
    }
	
	private void addSeekBarSpot(final String feature, final int prog, int max, final InterfaceInt interInt) {
        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        linearLayout.setPadding(5, 0, 0, 0);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.setGravity(Gravity.CENTER_HORIZONTAL);
        linearLayout.setLayoutParams(layoutParams);
        final TextView textView = new TextView(this);
        textView.setText(Html.fromHtml(feature + " : <font color='RED'>" + " OFF" + "</font>"));
        textView.setTextSize(16.0f);
        textView.setTextColor(Color.WHITE);
		textView.setPadding(10, 0, 0, 0);
		textView.setTypeface(null, Typeface.BOLD);
		textView.setShadowLayer(10.0f,0.0f,0.0f,Color.RED);
        SeekBar seekBar = new SeekBar(this);
		GradientDrawable seekbar = new GradientDrawable();
        seekbar.setShape(0);
        seekbar.setColor(Color.WHITE);
        seekbar.setColor(Color.parseColor("#ff0000"));
        seekbar.setStroke(dp(2), Color.parseColor("#ffffff"));
        seekbar.setCornerRadius(300.0f);
        seekbar.setSize(dp(17), dp(17));
       //seekBar.setThumb(seekbar);
        seekBar.setPadding(25, 10, 35, 10);
        seekBar.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        seekBar.setMax(max);
        seekBar.setProgress(prog);
		seekBar.getProgressDrawable().setColorFilter(Color.LTGRAY, PorterDuff.Mode.SRC_IN);
		seekBar.getThumb().setColorFilter(Color.LTGRAY, PorterDuff.Mode.SRC_ATOP);
		final TextView textView2 = textView;
		seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                public void onStartTrackingTouch(SeekBar seekBar) {
				}
				public void onStopTrackingTouch(SeekBar seekBar) {
				}

                int l;

                public void onProgressChanged(SeekBar seekBar2, int i, boolean z) {
                    if (i == 0) {
                        seekBar2.setProgress(i);
                        interInt.OnWrite(i);
                        TextView textView = textView2;
						textView.setShadowLayer(10.0f,0.0f,0.0f,Color.RED);
						textView.setText(Html.fromHtml("<font face=>" + feature + " : <font color='WHITE'>" + "Off" + "</font>"));
                    } else if (i == 1) {
                        seekBar2.setProgress(i);
                        interInt.OnWrite(i);
						textView.setShadowLayer(10.0f,0.0f,0.0f,Color.BLUE);
                        TextView textView = textView2;
						textView.setText(Html.fromHtml("<font face=>" + feature + " : <font color='#FF0000'>" + "Cabeça" + "</font>"));
                    } else if (i == 2) {
                        seekBar2.setProgress(i);
                        interInt.OnWrite(i);
						textView.setShadowLayer(10.0f,0.0f,0.0f,Color.BLUE);
                        TextView textView = textView2;
						textView.setText(Html.fromHtml("<font face=>" + feature + " : <font color='WHITE'>" + "Quadril" + "</b></font>"));
                    } else if (i == 3) {
                        seekBar2.setProgress(i);
                        interInt.OnWrite(i);
						textView.setShadowLayer(10.0f,0.0f,0.0f,Color.BLUE);
                        TextView textView = textView2;
                        textView.setText(Html.fromHtml("<font face=>" + feature + " : <font color='WHITE'>" + "Pé" + "</b></font>"));
                    }
                    interInt.OnWrite(i);
                }
            });

        linearLayout.addView(textView);
        linearLayout.addView(seekBar);
        patches.addView(linearLayout);
    }
    boolean delayed;



    public boolean isViewCollapsed() {
        return mFloatingView == null || mCollapsed.getVisibility() == View.VISIBLE;
    }

    //For our image a little converter
    private int convertDipToPixels(int i) {
        return (int) ((((float) i) * getResources().getDisplayMetrics().density) + 0.5f);
    }

    private int dp(int i) {
        return (int) TypedValue.applyDimension(1, (float) i, getResources().getDisplayMetrics());
    }

    //Destroy our View
    public void onDestroy() {
        super.onDestroy();

        if (view2 != null) {
            this.mWindowManager.removeView(view2);
        }
        View view = mFloatingView;
        if (view != null) {
            mWindowManager.removeView(view);
        }
    }

    // checking if any network connection / internet available

    // calling our AsyncTask Function that will do thee thing on fetching data from out host file

    // this is the checking one, this will draw our menu if it's license still valid or active

    //Check if we are still in the game. If now our Menu and Menu button will dissapear
    private boolean isNotInGame() {
        RunningAppProcessInfo runningAppProcessInfo = new RunningAppProcessInfo();
        ActivityManager.getMyMemoryState(runningAppProcessInfo);
        return runningAppProcessInfo.importance != 100;
    }

    //Same as above so it wont crash in the background and therefore use alot of Battery life


    private interface InterfaceBtn {
        void OnWrite();
    }

    private interface InterfaceInt {
        void OnWrite(int i);
    }

    private interface InterfaceBool {
        void OnWrite(boolean z);
    }

    private interface InterfaceStr {
        void OnWrite(String s);
    }
}
