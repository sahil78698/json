package Antenna;

import uk.lgl.modmenu.FloatingModMenuService;

public class Antenna.OnClickListener implements FloatingModMenuService.InterfaceBtn {
}
