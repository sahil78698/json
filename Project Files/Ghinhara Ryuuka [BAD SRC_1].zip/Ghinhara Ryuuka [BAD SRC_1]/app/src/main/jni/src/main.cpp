#include <src/Includes/Utils.h>


#include "Includes/Esp.h"
#include "Hook.h"
#include "Includes/Logger.h"
#include "Includes/obfuscator.hpp"
#define HOOK(offset, ptr, orig) MSHookFunction((void *)getRealOffset(offset), (void *)ptr, (void **)&orig)


extern "C" {
JNIEXPORT jboolean JNICALL
Java_Game_Mod_LauncherActivity_EnableSounds(
        JNIEnv *env,
        jobject activityObject) {
    return true;
}

JNIEXPORT jstring JNICALL
Java_Game_Mod_LauncherActivity_Title(
        JNIEnv *env,
        jobject activityObject) {
        	
    jstring str = env->NewStringUTF("CNUS TECH");
    return str;
}

JNIEXPORT jstring JNICALL
Java_Game_Mod_LauncherActivity_Heading(
        JNIEnv *env,
        jobject activityObject) {
        	
    return env->NewStringUTF("");
}


JNIEXPORT jstring JNICALL
Java_Game_Mod_LauncherActivity_Icon(
        JNIEnv *env,
        jobject activityObject) {

    //Use https://www.base64encode.org/ to encode your image to base64

    return env->NewStringUTF(
            "");
            }

JNIEXPORT jint JNICALL
Java_Game_Mod_LauncherActivity_IconSize(
        JNIEnv *env,
        jobject activityObject) {
    return 65;
}

JNIEXPORT jstring JNICALL
Java_Game_Mod_LauncherActivity_Toast(
        JNIEnv *env,
        jclass clazz) {
    return env->NewStringUTF("The toast");
}


JNIEXPORT jobjectArray  JNICALL
Java_Game_Mod_LauncherActivity_getFeatureListttttttttt(
        JNIEnv *env,
        jobject activityObject) {
    jobjectArray ret;

    const char *features[] = {
            
            "CT_AIM MENU",
		    "TG_Aim Bot",//0
            "TG_AIM TIRO",//1
            "TG_AIM MIRA",//2
			"TG_AIM AGACHADO",//3
			"SB_AutoSkills_0_3",//4
            "SBP_AIM FOV_0_360",//5
			"SBP_AIM DISTANCIA_0_100",//6
			"TG_ESP FIRE",//7
			"CT_ESP NOME",//8
			"TG_GHOST HACK",//9
			"TG_TELEKILL",//10
			"TG_RECARGA FAST",//11
			"TG_MODO NIGHT",//12
			"TG_MedKitRunning",//13
			"TG_SPEED HACK (Elimina)_0_5",//14
			"TG_Auto Skill (Visual)",//15
			"TG_TELEPORT CARRO",//16
			"TG_ZÉ PEDRINHA",//17
			"TG_Modo HD",//18
			"SBP_Sensibilidade_0_3",//19
			"SBP_Visão Hacker_0_6",//20
			"TG_Antena Pró",//21
			"TG_Ghost Hacker V2",//22
			"TG_No Parachute",//23
			"Spinner_CREATOR_UNUS",
			"SBP_Speed Carro_0_5",//24
			//"ButtonHide_HIDE ICON",
			//"Butt_UHD)",//25
           };

    int Total_Feature = (sizeof features /
                         sizeof features[0]); //Now you dont have to manually update the number everytime;

    ret = (jobjectArray) env->NewObjectArray(Total_Feature, env->FindClass("java/lang/String"),
                                             env->NewStringUTF(""));
    int i;
    for (i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));
    return (ret);
}


struct My_Patches {

    MemoryPatch Teletransport;
    MemoryPatch MedKitRunning;
    MemoryPatch MedKitRunning2;
    MemoryPatch WallPedra;
	MemoryPatch Speed;
    MemoryPatch Speed2x;
	MemoryPatch Speed3x;
	MemoryPatch Speed4x;
	MemoryPatch Speed5x;
	MemoryPatch NightMode;
	MemoryPatch FreeKills;
	MemoryPatch Recarga1;
	MemoryPatch TeleDrive;
	MemoryPatch ModoHd;
	MemoryPatch Sensibilidade1;
	MemoryPatch Sensibilidade2;
	MemoryPatch Sensibilidade3;
	MemoryPatch Visao;
	MemoryPatch Visao2x;
	MemoryPatch Visao3x;
	MemoryPatch Visao4x;
	MemoryPatch Visao5x;
	MemoryPatch Visao6x;
	MemoryPatch Antena;
	MemoryPatch ModoFantasma;
	MemoryPatch Parachute;
	MemoryPatch Speedcarro;
	MemoryPatch Speedcarro2x;
	MemoryPatch Speedcarro3x;
	MemoryPatch Speedcarro4x;
	MemoryPatch Speedcarro5x;
	MemoryPatch Ponto;
	
} hexlibPatches;

bool KMHack1 = false, KMHack2 = false, KMHack3 = false, KMHack4 = false, KMHack5 = false, KMHack6 = false, KMHack7 = false, KMHack8 = false, KMHack9 = false, KMHack10 = false, KMHack11 = false, KMHack12 = false, KMHack13 = false, KMHack14 = false, KMHack15 = false, KMHack16 = false, KMHack17 = false, KMHack18 = false, KMHack19 = false, KMHack20 = false;

int Desativer = 0;

struct {

    float Fov_Aim = 0.998f;
    int semihs = 0;
    bool aimBotFov = false;
    bool aimScope = false;
    bool aimTiro = false;
    bool hs100 = false;
    bool ghost = false;
    bool hs70 = false;
    bool aimAgachado = false;
    bool aimBody = false;
    bool aimbotauto = true;
    bool teleKill = false;
    bool Paraquedas = false;
    bool aimVisibilidade = false;

   
    bool aimFire = false;
	bool espNames = false;
    bool espFire = false;

    bool medKit = false;
	bool NightMode = false;
    
	bool FreeKills = false;
	
	bool TeleDrive = false;
	
	bool Antena = false;
	
	bool ModoFantasma = false;
	
	bool Parachute = false;
	
	bool Ponto = false;

    int enemyCountAround = 0;
    int botCountAround = 0;
    int enemyCountWorld = 0;
    int botCountWorld = 0;

} MT;

bool active = true;
bool launched = false;

JNIEXPORT void JNICALL
Java_Game_Mod_LauncherActivity_Changes(
        JNIEnv *env,
        jobject activityObject,
        jint feature,
        jint Value) {

    __android_log_print(ANDROID_LOG_VERBOSE, "Mod Menu", "Feature: = %d", feature);
    __android_log_print(ANDROID_LOG_VERBOSE, "Mod Menu", "Value: = %d", Value);

    switch (feature) {
    	
       case 0:
        MT.hs100 = !MT.hs100;
        break;
        
      case 1:
        MT.aimFire= !MT.aimFire;
        break;
        
      case 2:
        MT.aimScope= !MT.aimScope;
        break;
     
	  case 3:
            MT.aimAgachado = !MT.aimAgachado;	
        break;
		
	  case 4:
        if (Value == 0) {
            MT.hs100 = false;
			MT.hs70 = false;
			MT.aimBody = false;
		    } else if (Value == 1) {
				MT.hs70 = false;
                MT.aimBody = false;
                MT.hs100 = !MT.hs100;
				MT.hs100 = true;
            } else if (Value == 2) {
				MT.hs100 = false;
                MT.aimBody = false;
                MT.hs70 = !MT.hs70;
                MT.hs70 = true;
            } else if (Value == 3) {
				MT.hs100 = false;
                MT.hs70 = false;
                MT.aimBody = !MT.aimBody;
				MT.aimBody = true;
            }
        break;
		
      case 5:
        if (Value > 0) {
            MT.Fov_Aim = 1.0f - (0.0099f * (float)Value);
        }
        break;

	  case 6:
        if (Value > 0) {
            MT.aimBotFov = 1.0f - (0.0099f * (float)Value);
        }
        break;
		
	  case 7:
         MT.espFire = !MT.espFire;
         break;
    
      case 8:
         MT.espNames = !MT.espNames;
         break;
		
	  case 9:
            MT.ghost = !MT.ghost;
		break;
		 
	  case 10:
            MT.teleKill = !MT.teleKill;
            MT.ghost = !MT.ghost;
            break;
			
	  case 11:
			KMHack8 = !KMHack8;
			if (KMHack8) {
				hexlibPatches.Recarga1.Modify();
			} else {
				hexlibPatches.Recarga1.Restore();
			}
			break;
			
	   case 12:
			KMHack8 = !KMHack8;
			if (KMHack8) {
				hexlibPatches.NightMode.Modify();
			} else {
				hexlibPatches.NightMode.Restore();
			}
			break;
			
		case 13:
            KMHack4 = !KMHack4;
            if (KMHack4) {
                hexlibPatches.MedKitRunning.Modify();
                hexlibPatches.MedKitRunning2.Modify();
            } else {
                hexlibPatches.MedKitRunning.Restore();
                hexlibPatches.MedKitRunning2.Restore();
            }
            break;
		
            break;
       
		 case 14:
        if (Value == 0) {
				hexlibPatches.Speed.Restore();
			} else if (Value == 1) {
				hexlibPatches.Speed.Modify();
			} else if (Value == 2) {
				hexlibPatches.Speed2x.Modify();
		    } else if (Value == 3) {
				hexlibPatches.Speed3x.Modify();
            } else if (Value == 4) {
				hexlibPatches.Speed4x.Modify();
            } else if (Value == 5) {
				hexlibPatches.Speed5x.Modify();
            }
        break;
		 
		case 15:
            KMHack15 = !KMHack15;
            if (KMHack15) {
                hexlibPatches.FreeKills.Modify();
            } else {
                hexlibPatches.FreeKills.Restore();
            }
            break;
			
		case 16:
            KMHack15 = !KMHack15;
            if (KMHack15) {
                hexlibPatches.TeleDrive.Modify();
            } else {
                hexlibPatches.TeleDrive.Restore();
            }
            break;
		
        case 17:
            KMHack15 = !KMHack15;
            if (KMHack15) {
                hexlibPatches.WallPedra.Modify();
            } else {
                hexlibPatches.WallPedra.Restore();
            }
            break;
			
		case 18:
            KMHack16 = !KMHack16;
            if (KMHack16) {
                hexlibPatches.ModoHd.Modify();
            } else {
                hexlibPatches.ModoHd.Restore();
            }
            break;
			
		 case 19:
        if (Value == 0) {
				hexlibPatches.Sensibilidade1.Restore();
			} else if (Value == 1) {
				hexlibPatches.Sensibilidade1.Modify();
			} else if (Value == 2) {
				hexlibPatches.Sensibilidade2.Modify();
		    } else if (Value == 3) {
				hexlibPatches.Sensibilidade3.Modify();
            }
        break;
		
	case 20:
        if (Value == 0) {
				hexlibPatches.Visao.Restore();
			} else if (Value == 1) {
				hexlibPatches.Visao.Modify();
			} else if (Value == 2) {
				hexlibPatches.Visao2x.Modify();
		    } else if (Value == 3) {
				hexlibPatches.Visao3x.Modify();
            } else if (Value == 4) {
				hexlibPatches.Visao4x.Modify();
            } else if (Value == 5) {
				hexlibPatches.Visao5x.Modify();
			} else if (Value == 6) {
				hexlibPatches.Visao6x.Modify();
            }
        break;
		
	case 21:
            KMHack17 = !KMHack17;
            if (KMHack17) {
                hexlibPatches.Antena.Modify();
            } else {
                hexlibPatches.Antena.Restore();
            }
            break;
			
	case 22:
            KMHack18 = !KMHack18;
            if (KMHack18) {
                hexlibPatches.ModoFantasma.Modify();
            } else {
                hexlibPatches.ModoFantasma.Restore();
            }
            break;
			
		case 23:
            KMHack19 = !KMHack19;
            if (KMHack19) {
                hexlibPatches.Parachute.Modify();
            } else {
                hexlibPatches.Parachute.Restore();
            }
            break;
			
		case 24:
        if (Value == 0) {
				hexlibPatches.Speedcarro.Restore();
			} else if (Value == 1) {
				hexlibPatches.Speedcarro.Modify();
			} else if (Value == 2) {
				hexlibPatches.Speedcarro2x.Modify();
		    } else if (Value == 3) {
				hexlibPatches.Speedcarro3x.Modify();
            } else if (Value == 4) {
				hexlibPatches.Speedcarro4x.Modify();
            } else if (Value == 5) {
				hexlibPatches.Speedcarro5x.Modify();
            }
        break;
		
		case 25:
            KMHack20 = !KMHack20;
            if (KMHack20) {
                hexlibPatches.Ponto.Modify();
            } else {
                hexlibPatches.Ponto.Restore();
            }
            break;

			
		case 90:
            Desativer = Value;
            break;



    }

}
}

void (*LateUpdate)(void *componentPlayer);
void AimBot(void *local_player, void *enemy_player) {

    int pose = GetPhysXPose(enemy_player);
    bool alive = get_isAlive(enemy_player);
    bool visible = get_isVisible(enemy_player);
    bool visi = get_AttackableEntity_IsVisible(enemy_player);
    bool visir = get_AttackableEntity_GetIsDead(enemy_player);

    bool sameteam = get_isLocalTeam(enemy_player);
    void *HeadTF = *(void **)((uintptr_t)enemy_player + Global.HeadTF);
    void *HipTF = *(void **)((uintptr_t)enemy_player + Global.HipTF);
    void *Main_Camera = *(void **)((uintptr_t)local_player + Global.MainCameraTransform);

    if (alive && pose != 8  && visible && !sameteam && HeadTF != NULL && Main_Camera != NULL && HipTF != NULL) {
        Vector3 EnemyLocation = Transform_INTERNAL_GetPosition(HeadTF);
        Vector3 CenterWS = GetAttackableCenterWS(local_player);
        bool scope = get_IsSighting(local_player);
        bool agachado = get_IsCrouching(local_player);
        float distance = Vector3::Distance(CenterWS, EnemyLocation);

        Vector3 PlayerLocation = Transform_INTERNAL_GetPosition(Main_Camera);
        Quaternion PlayerLook = GetRotationToLocation(EnemyLocation, 0.1f, PlayerLocation);
        Quaternion PlayerLook2 = GetRotationToLocation(Transform_INTERNAL_GetPosition(HipTF), 0.1f, PlayerLocation);
                Vector3 fwd = GetForward(Main_Camera);
                
        Vector3 nrml = Vector3::Normalized(EnemyLocation - PlayerLocation);
        float PlayerDot = Vector3::Dot(fwd, nrml);
		



        if (MT.espFire) {
            void *imo = get_imo(local_player);
            if (imo != NULL && distance > 1.0f) {
                set_esp(imo, CenterWS, EnemyLocation);
            }
        }
        

           if (MT.espNames) {
            void *ui = CurrentUIScene();
            if (ui != NULL) {
                monoString *nick = get_NickName(enemy_player);
                monoString *distances = U3DStrFormat(distance);
                AddTeammateHud(ui, nick, distances);
            }
        }
            

if (MT.teleKill) {
                       set_aim(local_player, PlayerLook);
            void *_MountTF = Component_GetTransform(enemy_player);
            if (_MountTF != NULL) {
                Vector3 MountTF =
                        Transform_INTERNAL_GetPosition(_MountTF) - (GetForward(_MountTF) * 1.6f);
                Transform_INTERNAL_SetPosition(Component_GetTransform(local_player), Vvector3(MountTF.X, MountTF.Y, MountTF.Z));
            }
        }
	   

        if ((agachado && MT.aimAgachado) && ((PlayerDot > 0.998f && !MT.aimBotFov) || (PlayerDot > MT.Fov_Aim && MT.aimBotFov))) {
        	            
            set_aim(local_player, PlayerLook);
        }
        

        if ((scope && MT.aimScope) && ((PlayerDot > 0.998f && !MT.aimBotFov) || (PlayerDot > MT.Fov_Aim && MT.aimBotFov))) {
            set_aim(local_player, PlayerLook);

        }
        

                bool firing = IsFiring(local_player);
        if ((firing && MT.aimFire) && ((PlayerDot > 0.998f && !MT.aimBotFov) || (PlayerDot > MT.Fov_Aim && MT.aimBotFov))) {
        	            

            if (MT.aimBody) {
                set_aim(local_player, PlayerLook2);
            }
            if (MT.hs100) {
                set_aim(local_player, PlayerLook);
            }
            if (MT.hs70) {
                if (MT.aimbotauto)
                {
                    set_aim(local_player, PlayerLook);
                    ++MT.semihs;
                } else {
                    set_aim(local_player, PlayerLook2);
                    --MT.semihs;
                }

                if (MT.semihs == 6)
                {
                    MT.aimbotauto = false;
                } else if (MT.semihs == 0) {
                    MT.aimbotauto = true;
                }
                if (MT.semihs > 6 || MT.semihs < 0)
                {
                    MT.semihs = 3;
                    MT.aimbotauto = true;
                }
            }
        }
		}
		}
    


bool isEspReady = false;

void *fakeEnemy;
void _LateUpdate(void *player){
    if (player != NULL) {
        void *local_player = Current_Local_Player();
        if (local_player == NULL){
            local_player = GetLocalPlayerOrObServer();
        }
        if (local_player != NULL){
            void *current_match = Curent_Match();
            if (current_match != NULL) {
                void *fakeCamPlayer = get_MyFollowCamera(local_player);
                void *fakeCamEnemy = get_MyFollowCamera(player);
                if (fakeCamPlayer != NULL && fakeCamEnemy != NULL){
                    void *fakeCamPlayerTF = Component_GetTransform(fakeCamPlayer);
                    void *fakeCamEnemyTF = Component_GetTransform(player);
                    if (fakeCamPlayerTF != NULL && fakeCamEnemyTF != NULL){
                        Vector3 fakeCamPlayerPos = Transform_INTERNAL_GetPosition(fakeCamPlayerTF);
                        Vector3 fakeCamEnemyPos = Transform_INTERNAL_GetPosition(fakeCamEnemyTF);
                        float distance = Vector3::Distance(fakeCamPlayerPos, fakeCamEnemyPos);
                        if (player != local_player){
                            if (distance > 1.6f) {
                                bool sameteams = get_isLocalTeam(player);
                                int pose = GetPhysXPose(player);
                                bool alive = get_isAlive(player);
                                bool visible = get_isVisible(player);
                                bool visir = get_AttackableEntity_GetIsDead(player);
                                       
                                if (!sameteams && pose != 8 && alive && visible){
                                    AimBot(local_player, player);
                                }
                            } else {
                                fakeEnemy = player;
                            }
                        }
                    }
					    
                }
            }
        }
    }
    LateUpdate(player);
}

bool (*orig_ghost)(void* _this, int value);
bool _ghost(void* _this, int value){
    if (_this != NULL){
        if (MT.ghost || MT.teleKill){
            return false;
        }
    }
    return orig_ghost(_this, value);
}

void *hack_thread(void *) {
    LOGI("Loading...");

    ProcMap il2cppMap;
    do {
        il2cppMap = KittyMemory::getLibraryMap("libil2cpp.so");
        sleep(1);
    } while (!il2cppMap.isValid());

    hexlibPatches.Teletransport = MemoryPatch("libil2cpp.so", 0x1C06E7C, "\x00\x00\xA0\xE3\x1E\xFF\x2F\xE1", 8);
    hexlibPatches.MedKitRunning = MemoryPatch("libil2cpp.so", 0x22F55A8, "\x00\x00\xA0\xE3\x1E\xFF\x2F\xE1", 8);
    hexlibPatches.MedKitRunning = MemoryPatch("libil2cpp.so", 0xB8929C, "\x00\x00\xA0\xE3\x1E\xFF\x2F\xE1", 8);
    hexlibPatches.Speed = MemoryPatch("libil2cpp.so", 0x179ED24 , "\x82\x0F\x43\xE3\x1E\xFF\x2F\xE1", 8); 
    hexlibPatches.Speed2x = MemoryPatch("libil2cpp.so", 0x179ED24 , "\x83\x0F\x43\xE3\x1E\xFF\x2F\xE1", 8);
    hexlibPatches.Speed3x = MemoryPatch("libil2cpp.so", 0x179ED24 , "\x84\x0F\x43\xE3\x1E\xFF\x2F\xE1", 8); 
    hexlibPatches.Speed4x = MemoryPatch("libil2cpp.so", 0x179ED24 , "\x85\x0F\x43\xE3\x1E\xFF\x2F\xE1", 8);
    hexlibPatches.Speed5x = MemoryPatch("libil2cpp.so", 0x179ED24 , "\xD2\x0F\x43\xE3\x1E\xFF\x2F\xE1", 8);
    hexlibPatches.FreeKills = MemoryPatch("libil2cpp.so", 0xC700D0, "\x32\x00\x44\xE3\x1E\xFF\x2F\xE1", 8);
	hexlibPatches.TeleDrive = MemoryPatch("libil2cpp.so", 0x29F4204, "\x00\x00\xA0\xE3\x1E\xFF\x2F\xE1", 8);
	hexlibPatches.Recarga1 = MemoryPatch("libil2cpp.so", 0xDC7EBC, "\x12\x03\xA0\xE3\x1E\xFF\x2F\xE1", 8);//1.59
	hexlibPatches.ModoHd = MemoryPatch("libil2cpp.so", 0x2AAFBE8, "\x00\x00\xA0\xE3\x1E\xFF\x2F\xE1", 8);
	hexlibPatches.Sensibilidade1 = MemoryPatch("libil2cpp.so", 0xB8EB28, "\x00\x00\x48\x43", 4);
    hexlibPatches.Sensibilidade2 = MemoryPatch("libil2cpp.so", 0xB8EB28, "\x00\x00\x32\x43", 4);
    hexlibPatches.Sensibilidade3 = MemoryPatch("libil2cpp.so", 0xB8EB28, "\x00\x00\x16\x43", 4);
	hexlibPatches.Visao = MemoryPatch("libil2cpp.so", 0xC700D0, "\x32\x00\x44\xE3\x1E\xFF\x2F\xE1", 8);
    hexlibPatches.Visao2x = MemoryPatch("libil2cpp.so", 0xC700D0, "\x64\x00\x44\xE3\x1E\xFF\x2F\xE1", 8);
    hexlibPatches.Visao3x = MemoryPatch("libil2cpp.so", 0xC700D0, "\x7F\x00\x44\xE3\x1E\xFF\x2F\xE1", 8);
    hexlibPatches.Visao4x = MemoryPatch("libil2cpp.so", 0xC700D0, "\xC8\x00\x44\xE3\x1E\xFF\x2F\xE1", 8);
    hexlibPatches.Visao5x = MemoryPatch("libil2cpp.so", 0xC700D0, "\xFA\x00\x44\xE3\x1E\xFF\x2F\xE1", 8);
    hexlibPatches.Visao6x = MemoryPatch("libil2cpp.so", 0xC700D0, "\x2C\x01\x44\xE3\x1E\xFF\x2F\xE1", 8);
	hexlibPatches.Antena = MemoryPatch("libunity.so", 0x2A3464, "\x10\x40\x1C\x46", 4);
	hexlibPatches.ModoFantasma = MemoryPatch("libil2cpp.so", 0x1B8ACCC, "\x00\x00\xA0\xE3\x1E\xFF\x2F\xE1", 8);
	hexlibPatches.Parachute = MemoryPatch("libil2cpp.so", 0xB6C3DC, "\x00\x00\xA0\xE3\x1E\xFF\x2F\xE1", 8);
	hexlibPatches.Speedcarro = MemoryPatch("libil2cpp.so", 0x179EE0C , "\x82\x0F\x43\xE3\x1E\xFF\x2F\xE1", 8); 
    hexlibPatches.Speedcarro2x = MemoryPatch("libil2cpp.so", 0x179EE0C , "\x83\x0F\x43\xE3\x1E\xFF\x2F\xE1", 8);
    hexlibPatches.Speedcarro3x = MemoryPatch("libil2cpp.so", 0x179EE0C , "\x84\x0F\x43\xE3\x1E\xFF\x2F\xE1", 8); 
    hexlibPatches.Speedcarro4x = MemoryPatch("libil2cpp.so", 0x179EE0C , "\x85\x0F\x43\xE3\x1E\xFF\x2F\xE1", 8);
    hexlibPatches.Speedcarro5x = MemoryPatch("libil2cpp.so", 0x179EE0C , "\xD2\x0F\x43\xE3\x1E\xFF\x2F\xE1", 8);
	hexlibPatches.Ponto = MemoryPatch("libil2cpp.so", 0x29A4794, "\x13\x00\xA0\xE3\x1E\xFF\x2F\xE1", 8);
	
MSHookFunction((void*)getRealOffset(0xB89958), (void*)_LateUpdate, (void**)&LateUpdate);

HOOK(0x1C06E7C, _ghost, orig_ghost);
    return NULL;

}

void *Super_thread(void *) {
    LOGD("Carregando...");

    ProcMap unityMap;
    do {
        unityMap = KittyMemory::getLibraryMap("libunity.so");
        sleep(1);
    } while (!unityMap.isValid());

    hexlibPatches.WallPedra = MemoryPatch("libunity.so", 0xEF37E0, "\xC9\x3C\x8E\xBF\xC9\x3C\x8E\xBF\xC9\x3C\x8E\xBF\xC9\x3C\x8E\xBF", 16);//1.56
	hexlibPatches.NightMode = MemoryPatch("libunity.so", 0x1A2290, "\x00\x00\x80\xBF", 4);


    return NULL;
}

JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *globalEnv;
    vm->GetEnv((void **) &globalEnv, JNI_VERSION_1_6);

    pthread_t ptid;
    pthread_create(&ptid, NULL, hack_thread, NULL);

    return JNI_VERSION_1_6;
}

JNIEXPORT void JNICALL
JNI_OnUnload(JavaVM *vm, void *reserved) {}


__attribute__((constructor))
void initializer() {
    pthread_t ptid;
    pthread_create(&ptid, NULL, Super_thread, NULL);
}

