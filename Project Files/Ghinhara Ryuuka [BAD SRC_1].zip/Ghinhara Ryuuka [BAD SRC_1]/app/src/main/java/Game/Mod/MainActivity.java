package Game.Mod;

import android.app.Activity;
import android.os.Bundle;

import Game.Mod.R;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        MgaZg.Start(this);
    }
}
