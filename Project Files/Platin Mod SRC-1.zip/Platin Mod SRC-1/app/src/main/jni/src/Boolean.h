#ifndef BOOLEAN_H
#define BOOLEAN_H

#include "Unity/Hook.h"

  struct {
    
    bool aimAuto = false;
    bool aimScope = false;
    bool aimFire = false;
    bool aimSquat = false;
    bool aimLegit = false;
    bool aimCaido = false;
    bool FOV = true;
    bool aimbotauto = true;
    bool EspVidav2 = false;
    bool TpAliado = false;
    bool AlertAround = false;
    bool espIndetificar = false;
    bool espFPS = false;
    bool configLine = false;
    bool espDistance = false;
    bool espNames = false;
    bool espBox = false;
    bool espSkeleton = false;
    bool espFire = false;
    bool espGranada = false;
    bool aimVisible = false;
    bool espName = false;
    bool EspBox = false;
    bool aimCabeca = true;
    bool aimPeito = false;
    bool aimPe = false;
    bool MoveOnAir = false;
    bool EspHp = false;
    bool EspWeapon = false;
    bool EspNameDraw = false;
    bool espNewConfig = false;
    bool isPlayerName = false;
    bool espNew1 = false;
    bool espNew2 = false;
    bool espNew3 = false;
    bool EspVida = false;
    bool SkilCris =false;
    bool EspAlvo = false;
    bool isPlayerLife = false;
    bool MoveBoard = false;
    bool UnlockerBoard = false;
    
    bool espLineEncima = false;
    bool espLineEmbaixo = false;
    bool espLineMeio = false;
    bool Dano = false;
    
    bool espFireCeu = false;
    bool espFireConfig = false;
    bool espAlert = false;
    
    bool trandom = false;
    bool random = false;
    bool Teleport = false;
    bool isPlayerIdent = false;
    
    
    
    bool ghost = false;
    bool WallStone = false;
    bool UnderCar = false;
    bool aimlock = false;
    bool Chams = false;
    bool AntenaCorpo = false;
    bool SpeedTime50X = false;
    bool EspAlvoUnico = false;
    bool TesteSla = false;
    bool Remivermira = false;
    
    bool FlyArmar = false;
    bool AntiTelamento = false;
    bool espIdentificador = false;
    bool AntiTelamento2 = false;
    bool AutoLike = false;
    bool AutoKitar = false;
    bool FlyHack = false;
    bool DriverSkill = false;
    bool Telekill = false;
    bool UpdateFly = false;
    bool FlySpeed = false;
    bool espNames2 = false;
    bool espNames3 = false;
    bool drawFov = false;
    bool Gravity = false;
    bool drawCross = false;
    
    
int SpeedInt = 0;
bool FlyAltura = false; 
bool Gravidade = false;
bool verificacao = false; 

float TFPosX = 0.0f; 
float TFPosY = 0.0f; 
float TFPosZ = 0.0f; 
void *TFPos = nullptr;
    
    int semihs = 0;
    int AlturaInt = 2500;
    int enemyCountAround = 0;
    int botCountAround = 0;
    int conttelekill = 1; 
    int velocidade = 0;
    int FramePerS;
    int HpS;
    
    
    Color LineColor = Color::White();
    Color GrenadeColor = Color::White();
    Color GrenadeColorEnd = Color::Yellow();
    Color CaidosColor = Color::Red();
    float HP2;
    float Fov_Aim = 9.0f;
    float TextSize = 21.0f;
    float LineSize = 1.0f;
    float CrossSize = 12.0f;
    float LineGrenadeSize = 0.1f;
    float LineEndGrenadeSize = 0.1f;

} ALFA;


bool SkilCris = false;
bool flymover = false;


enum FireMode {
    MANUL,  // 0
    AUTO    // 1
};

enum FireStatus {
    NONE,   //0
    FIRING, //1
    CANCEL //2
};


enum Hit
{
    Head,  //0
    Neck,  //1
    Chest, //2
    Hips,  //3
    LeftArm, //4
    LeftForeArm, //5
    RightArm, //6
    RightForeArm, //7
    LeftUpLeg, //8
    LeftLeg, //9
    RightUpLeg, //10
    RightLeg, //11
    LeftFoot, //12
    RightFoot, //13
    LeftHand, //14
    RightHand, //15
    LeftClav, //16
    RightClav, //17
    NoFlag, //18
    WeakPoint, //19
    None //20
};

enum Check
{
    Chests, //0
    Heads, //1
    Necks, //2
    Arm, //3
    ForeArm, //4
    UpLeg, //5
    Leg, //6
    Foot //7
};


bool Material = false;
bool LineMaterial = false;
bool EspNameV2 = false;
bool FakeName = false;


#endif

